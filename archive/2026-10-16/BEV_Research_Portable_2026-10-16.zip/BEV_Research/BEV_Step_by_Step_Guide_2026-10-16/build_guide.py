from pathlib import Path
import json
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
WALK = ROOT / 'BEV_HAULSIM_Walkthrough_2026-10-16'
doc = Document()
sec = doc.sections[0]
sec.page_width, sec.page_height = Inches(8.5), Inches(11)
sec.top_margin = sec.bottom_margin = Inches(.65)
sec.left_margin = sec.right_margin = Inches(.75)
sec.header_distance = sec.footer_distance = Inches(.3)
for name in ['Normal', 'Body Text', 'List Bullet', 'List Number']:
    st = doc.styles[name]
    st.font.name = 'Calibri'; st.font.size = Pt(11)
    st.font.color.rgb = RGBColor(0, 0, 0)
    st.paragraph_format.space_after = Pt(7)
    st.paragraph_format.line_spacing = 1.08
for name, size in [('Title', 25), ('Subtitle', 12), ('Heading 1', 19), ('Heading 2', 13), ('Heading 3', 11)]:
    st = doc.styles[name]
    st.font.name = 'Calibri'; st.font.size = Pt(size)
    st.font.color.rgb = RGBColor(0, 0, 0)
    st.paragraph_format.space_before = Pt(9)
    st.paragraph_format.space_after = Pt(8)
    st.paragraph_format.keep_with_next = True
    if name != 'Subtitle': st.font.bold = True
for name in ['Caption', 'Header', 'Footer']:
    doc.styles[name].font.name = 'Calibri'
    doc.styles[name].font.size = Pt(9)
    doc.styles[name].font.color.rgb = RGBColor(0, 0, 0)
for style in doc.styles:
    for border in list(style.element.iter(qn('w:pBdr'))):
        border.getparent().remove(border)
doc.styles['Caption'].paragraph_format.space_after = Pt(8)
doc.styles['Caption'].font.italic = False
sec.header.paragraphs[0].text = 'Underground BEV research    |    Follow along guide    |    16 October 2026'
footer = sec.footer.paragraphs[0]
footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
footer.add_run('Page ')
fld = OxmlElement('w:fldSimple'); fld.set(qn('w:instr'), 'PAGE'); footer._p.append(fld)
doc.core_properties.title = 'Underground BEV Research and HAULSIM Step by Step Guide'
doc.core_properties.subject = 'Plain language guide to completed work and reproducible next steps'
doc.core_properties.author = 'Athif Shaffy research project'

def p(text='', bold=False, style=None):
    par = doc.add_paragraph(style=style)
    r=par.add_run(text); r.bold=bold
    return par
def h(text, level=2): return doc.add_heading(text, level)
def page(title):
    par=h(title, 1);par.paragraph_format.page_break_before=True
def step(n, title, text):
    par=doc.add_paragraph(); par.paragraph_format.keep_with_next=True
    par.add_run(f'{n}  {title}').bold=True
    p(text)
def bullet(text): return p(text, style='List Bullet')
def evidence(text):
    par=p('Evidence: '+text); par.runs[0].font.size=Pt(9)
def picture(path, caption, width=6.65):
    par=p(); par.paragraph_format.keep_with_next=True
    par.alignment=WD_ALIGN_PARAGRAPH.CENTER
    inline=par.add_run().add_picture(str(path),width=Inches(width))
    inline._inline.docPr.set('descr',caption)
    p(caption,style='Caption')
def table(headers, rows, widths):
    t=doc.add_table(rows=1, cols=len(headers)); t.autofit=False
    for i,w in enumerate(widths): t.columns[i].width=Inches(w)
    props=t._tbl.tblPr
    borders=OxmlElement('w:tblBorders')
    for edge in ['top','left','bottom','right','insideH','insideV']:
        e=OxmlElement('w:'+edge); e.set(qn('w:val'),'single'); e.set(qn('w:sz'),'4'); e.set(qn('w:color'),'D9D9D9'); borders.append(e)
    props.append(borders)
    margin=OxmlElement('w:tblCellMar')
    for edge in ['top','left','bottom','right']:
        e=OxmlElement('w:'+edge);e.set(qn('w:w'),'85');e.set(qn('w:type'),'dxa');margin.append(e)
    props.append(margin)
    for i,x in enumerate(headers): t.rows[0].cells[i].text=x
    repeat=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(repeat)
    for row in rows:
        cells=t.add_row().cells
        for i,x in enumerate(row): cells[i].text=str(x)
    for ri,row in enumerate(t.rows):
        nosplit=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(nosplit)
        for i,c in enumerate(row.cells):
            c.width=Inches(widths[i])
            for par in c.paragraphs:
                par.paragraph_format.space_after=Pt(2)
                par.paragraph_format.line_spacing=1.02
                for r in par.runs: r.font.size=Pt(10.5);r.bold=(ri==0)
            if ri==0:
                sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'F0F2F4');c._tc.get_or_add_tcPr().append(sh)
    p().paragraph_format.space_after=Pt(0)
    return t
def link(label, url):
    par=doc.add_paragraph()
    rid=par.part.relate_to(url,RT.HYPERLINK,is_external=True)
    hyp=OxmlElement('w:hyperlink');hyp.set(qn('r:id'),rid)
    run=OxmlElement('w:r');pr=OxmlElement('w:rPr')
    color=OxmlElement('w:color');color.set(qn('w:val'),'0563C1');pr.append(color)
    un=OxmlElement('w:u');un.set(qn('w:val'),'single');pr.append(un)
    run.append(pr);txt=OxmlElement('w:t');txt.text=label;run.append(txt);hyp.append(run);par._p.append(hyp)
def math(xml):
    par=p();par.alignment=WD_ALIGN_PARAGRAPH.CENTER
    par._p.append(parse_xml('<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math">'+xml+'</m:oMath>'))
def mr(text):
    import html
    return '<m:r><m:t>'+html.escape(text)+'</m:t></m:r>'
def sub(a,b): return '<m:sSub><m:e>'+mr(a)+'</m:e><m:sub>'+mr(b)+'</m:sub></m:sSub>'
def sup(a,b): return '<m:sSup><m:e>'+mr(a)+'</m:e><m:sup>'+mr(b)+'</m:sup></m:sSup>'
def frac(a,b): return '<m:f><m:num>'+mr(a)+'</m:num><m:den>'+mr(b)+'</m:den></m:f>'

doc.add_heading('Underground BEV Research and HAULSIM Step by Step Guide',0)
p('A practical guide for Athif and supervisor discussions',style='Subtitle')
p('You are studying how underground truck operation affects battery temperature, and whether a simple temperature model can be trusted. We have completed haulage simulations and laboratory battery tests. We have not validated the temperature of a real mine truck or an early fire warning system.',bold=True)
p('This guide explains the work in everyday language, then shows how to open the prepared HAULSIM projects, check their settings, run a demonstration and read its results. The screenshots are actual HAULSIM 3.8 screens from the saved walkthrough. This is a guide to the prepared projects, not a complete build from an empty project.')
h('The whole process in six steps')
table(['Step','What happens','Where we are'],[
('1','Choose an underground mine and truck as a reference.','New Afton and historical Z50 information selected; many inputs remain assumed.'),
('2','Build a road network and simulate truck trips.','Native HAULSIM runs completed.'),
('3','Read the time spent driving, loading and waiting.','Saved event records checked.'),
('4','Estimate electrical load and temperature outside HAULSIM.','An illustrative connection has been built.'),
('5','Test the temperature formula against measured battery data.','Laboratory tests completed; results are mixed.'),
('6','Use reliable results in a paper and seek supervisor approval.','Draft and evidence prepared; latest results still need integration and approval.')
],[.5,3.0,3.5])
h('How to use this guide')
p('Read pages 1–2 for the research story. Follow pages 3–7 to use the charging demonstration. Use pages 8–9 for the New Afton road experiment. Pages 10–12 explain temperature modelling and the paper. Pages 13–15 help you find files, repeat the analysis and continue on another laptop.')
evidence('Saved project walkthrough, native run summaries, research register and thermal experiment reports. Status checked against the files available on 16 October 2026.')

page('1  What has actually been completed')
h('The mine in the research')
p('New Afton is the British Columbia underground mine used to inform the case. Public information supplies context and selected route and equipment values. The detailed alignment, road resistance and several operating parameters are assumptions. This is a New Afton informed scenario model, not a surveyed replica of the mine.')
h('There are two different HAULSIM projects')
table(['Setting','Charging demonstration','New Afton road experiment'],[
('Purpose','Learn hauling, traffic and charging','Isolate the effect of road resistance'),
('Fleet and payload','Four generic trucks, 42 t each','One historical Z50 inspired truck, 45 t'),
('Route lift','300 m','135 m over a 1500 m road network'),
('Battery settings','Assumed 400 kWh; charging enabled','Native battery energy and charging disabled'),
('Experiment','Two hour demonstration','Two hours each at 2%, 3% and 4% resistance'),
('Use of results','Operational demonstration; energy accounting unresolved','Comparison of complete cycle and loaded travel times')
],[1.35,2.8,2.85])
p('Do not copy the 400 kWh demonstration battery into the New Afton study. The historical Z50 reference used in the external calculation is 354 kWh. A visually similar truck icon does not prove which equipment or battery parameters are configured.',bold=True)
h('Other completed work')
bullet('Literature review and source checking: a 25 row evidence matrix, an input register, reported incident cases and a research plan. The paper draft has 18 cited references.')
bullet('A road resistance experiment, an initial temperature sensitivity calculation, and an external link from a HAULSIM duty cycle to a battery temperature surrogate.')
bullet('A measured 228 Ah battery dataset was downloaded and selected records were tested against constant temperature and cooling only baselines.')
bullet('A visual overview and a detailed handoff summary were prepared. The paper draft predates the latest experiments; they have not yet been merged into it.')
evidence('APCOM_Research_2026-10-15; HAULSIM_Road_Surface_2026-10-15; APCOM_228Ah_Thermal_Test_2026-10-16.')

page('2  Open the prepared charging demonstration')
step('1','Find the project folder','Open BEV_HAULSIM_Walkthrough_2026-10-16 inside your BEV research folder. Make a practice copy of the whole walkthrough folder before changing settings. Keep the original evidence files as your reference.')
step('2','Open the correct file','Start HAULSIM. Select Open Local Project using the folder icon. Choose BEV_Walkthrough.hsm. Keep BEV_Walkthrough.hsmdb beside it. The .hsm is the project entry file; the .hsmdb is its database. Do not open the database directly.')
step('3','Check the underground network','Select Build, then Isometric and Zoom Out. Find LP1 and LP2 at −600 m, the crusher at −300 m, and the charging bay near the upper level. Those elevations create a 300 m lift in this generic demonstration.')
picture(WALK/'Run_Setup.png','Actual HAULSIM view of the generic demonstration. The ramp spiral is an assumed network layout. It is not a surveyed New Afton mine map.')
h('What you are looking at')
p('LP means loading point. Trucks collect broken ore at LP1 or LP2, travel uphill, dump at the crusher and return. Seven single lane traffic control sections represent constrained movement, with passing spaces between them. Rolling resistance is assumed to be 3%.')
p('The battery shaped object marks a charging location. The moving articulated truck graphic is a generic HAULSIM vehicle. It is not a manufacturer accurate Z50 model, and this view is not footage from a real underground mine.')
evidence('Walkthrough.txt and Run_Setup.png in the walkthrough folder.')

page('3  Check the truck fleet')
step('4','Open the fleet configuration','In Navigator, expand Equipment. Right click Haulers and select Configure. The upper grid defines the truck type. The lower grid lists individual trucks.')
picture(WALK/'Fleet_Settings.png','Actual fleet configuration. All four trucks are active, carry 42 t and start at the charging bay.')
step('5','Confirm the four trucks','Check BEV-01, BEV-02, BEV-03 and BEV-04. Each should use APCOM Study - Generic underground BEV 42t, have a 42 t payload and start at Charge Bay - 2 x 300 kW.')
step('6','Inspect the truck type','Click the gear at the right of the upper truck type row. On Operational Data, check Study 42 t tray, 400 kW Engine Net Power and 1 minute dump time. The assumed empty mass is 37.7 t and the loaded mass is 79.7 t.')
h('How to interpret those fields')
p('Payload is the ore carried, not the weight of the whole truck. The nominal 30 km/h maximum does not guarantee that speed: road limits, grade, power and traffic also constrain movement. Engine Net Power is the software field name; Powered By on the Energy tab determines that this demonstration uses a battery.')
p('The animation is set to Articulated Truck. Changing the icon would change presentation, not establish that its physical parameters match a real vehicle.')
evidence('Fleet_Settings.png and the saved walkthrough project. All listed values are demonstration assumptions.')

page('4  Check the battery configuration')
step('7','Open the Energy tab','Within the truck type settings, select Energy. Check the values below against the practice copy. These values reproduce the generic demonstration and must not be described as measured Z50 data.')
picture(WALK/'Battery_Settings.png','Actual battery settings. The software displays kWh/h for charge rate; 600 kWh/h equals 600 kW.',width=5.25)
table(['Setting','Value'],[
('Powered By and capacity','Battery; 400 kWh'),
('Maximum Charge Rate','600 kWh/h'),
('Initial Battery Level','90–90%'),
('Minimum Battery Threshold','50%'),
('Recharging and regenerative braking','Both enabled'),
('Efficiency Factor shown in Energy','60%')
],[3.5,3.5])
p('The consumption curve uses 20 kW at zero load and about 490.59 kW at full load. It was constructed from assumed wheel power, drivetrain efficiency and auxiliaries. The 50% threshold requests a charging trip; it is not a hard minimum SOC. A truck can consume energy while travelling to the bay.')
p('Native energy and SOC accounting remain unreconciled. Use this configuration to demonstrate scheduling and charging behaviour, not to claim validated battery endurance or a guaranteed remaining charge.',bold=True)

page('5  Check the charger and loading tasks')
step('8','Inspect the charging bay','In Navigator, open Locations, or select the charging bay in the Build scene. It is an ancillary Battery Recharge location with a 300 kW rate, two charging points and four waiting bays. Two trucks can charge at once. The truck acceptance limit does not increase the bay supply.')
step('9','Check loading equipment','Under Navigator > Equipment > Loaders, find Loader-LP1 and Loader-LP2. The loading time matrix assigns four minutes per 42 t load. These are separate loaders; the truck Self Loader Loading Time field is not the relevant loading setting. The broken ore loose density is assumed to be 2.2 t/m³.')
step('10','Open Tasks','Double click Tasks in Navigator. Check the source, destination, loader and assigned trucks for each Load & Haul task.')
picture(WALK/'Task_Assignments.png','Actual task screen. Task target rates are configured inputs, not achieved throughput.',width=6.05)
table(['Loader','Route','Trucks'],[
('Loader-LP1','LP1 to Crusher','BEV-01 and BEV-02'),
('Loader-LP2','LP2 to Crusher','BEV-03 and BEV-04')
],[1.6,2.65,2.75])
p('The large task quantities and repeating cycles keep work available until the simulation ends. The displayed 630 t/h dispatcher target is an input. The observed delivery rate must come from the completed run report. Charging is simplified: taper and connection delays are not represented.')
evidence('Task_Assignments.png and Walkthrough.txt.')

page('6  Run the demonstration and read the results')
step('11','Set the duration','Select the Run tab. In the bottom status bar, set Duration to 2 h and press Tab to commit it. Keep Run Speed at 1.00. Run Speed means simulated minutes per real second; it does not change truck driving speed.')
step('12','Start the run','Click Run. Watch the bottom Status and Elapsed Time. Allow it to reach 0d 02h:00min. This should take roughly two real minutes plus preparation and rendering time. Task Tracker shows assigned work. A stopped or interrupted run must not be compared with a complete two hour run.')
step('13','Read delivered material','After completion, select Run > Reports > Material Movement Summary. Read completed tonnes delivered to the crusher. Then use Haul Unit State for travel, loading, waiting and Recharging.')
picture(WALK/'Material_Movement_Result.png','Saved reference run: 168 t from each loading point, totalling 336 t delivered. A run with different inputs may produce different values.')
h('Check your reference result')
bullet('Eight completed deliveries × 42 t = 336 t. Over two hours, that is 168 t/h for this short demonstration.')
bullet('Four trucks × two hours = eight truck hours in the state records. Total recharging time was 1.480 truck hours; peak simultaneous charging was two.')
bullet('Export the reports and use Export Raw Data to Excel for event records. Save new exports in a separate folder with the run date and settings.')
p('Passing time, mass balance and charger capacity checks proves that these recorded quantities reconcile. It does not prove that the battery energy model is calibrated. Do not apply the older long run study’s two hour warmup exclusion to this two hour demonstration.')

page('7  Configure the New Afton road experiment')
p('For the paper’s road question, use the three prepared New Afton models. These differ from the charging demonstration. The single feature varied is rolling resistance: the resistance a tyre experiences as it rolls along the road. It is a simplified way to test road condition, not a measurement of mine roughness or vibration.')
step('1','Open a practice copy of the road study','Copy HAULSIM_Road_Surface_2026-10-15 to a practice folder. In HAULSIM, open models/RR02/New_Afton_A_RR02.hsm. Keep its matching .hsmdb file in the same folder.')
step('2','Use the prepared cases','Run RR02, RR03 and RR04 separately. Their rolling resistances are already configured as 2%, 3% and 4%. Open the matching .hsm in each case folder rather than guessing which road segments to edit. This guide does not prescribe an unverified menu path for changing all network resistance values.')
table(['Input held the same','Value in the road experiment'],[
('Road network length and rise','1500 m and 135 m'),
('Grade','16% on steep ramp segments, not the whole route average'),
('Truck and payload','One truck; 48,148 kg empty; 45 t payload'),
('Loaded and empty speed caps','10 km/h and 14 km/h'),
('Loading and dumping','4 minutes loading; 1 minute dump, plus modelled manoeuvring'),
('Traction and retarding assumptions','391 kW wheel ceiling; 300 kN force cap; 440 kW retarder'),
('Other road factors','Traction coefficient 0.6; ground structure class 0'),
('Run duration and replications','120 minutes; one replication per case'),
('Native battery functions','Energy, charging and regenerative braking disabled')
],[2.35,4.65])
step('3','Run each case for two hours','Use the same Run procedure as the demonstration. Save each case’s reports and raw event exports in its own folder. Record which project was opened, the duration and any changes. For a faithful comparison, change nothing else.')
p('Ground structure is held fixed to isolate rolling resistance. This experiment does not simulate impact, chassis vibration, water ingress, dust damage, cell abuse or battery fire.')
evidence('study_manifest.json in HAULSIM_Road_Surface_2026-10-15. The 391 kW wheel ceiling is an assumption derived from battery power, auxiliaries and drivetrain efficiency.')

page('8  Understand the road experiment result')
h('What the completed native runs showed')
table(['Road case','Mean complete cycle','Loaded travel','Delivered in 2 h'],[
('2% resistance','23.967 min','10.975 min','180 t'),
('3% resistance','24.308 min','11.316 min','180 t'),
('4% resistance','24.631 min','11.639 min','180 t')
],[1.4,1.9,1.7,2.0])
p('From 2% to 4% resistance, the complete cycle became about 40 seconds longer, a 2.77% increase. Loaded travel increased by about 6.04%. All three runs still delivered four loads of 45 t because the two hour cutoff falls between delivery events. Identical short window tonnes do not mean identical travel performance.',bold=True)
h('Why resistance can affect the truck')
p('The truck needs force to climb the road and overcome rolling resistance. A standard steady speed force relation is shown below. It is a physical relation used to explain the mechanism, not a newly invented research formula.')
math(mr('F = mg(sin θ + ')+sub('C','r')+mr(' cos θ)'))
p('F is wheel force, m is total vehicle mass, g is gravity, θ is road angle, and Cr is the rolling resistance coefficient. A 2% resistance setting means Cr = 0.02. On a grade G, θ = arctan(G); a 16% segment has G = 0.16. At a given speed, more force means more mechanical power. A power limited truck can slow down.')
h('How to audit the result')
bullet('Use equipment state records for complete cycle and loaded travel timing. Material movement records are useful for quantities, but their time and distance fields were zero in these exports.')
bullet('Count deliveries that actually completed. Each run had another 45 t load still undelivered at cutoff. A partly completed unloading event must not be counted as a fifth full delivery.')
bullet('Use the saved comparison CSV and native result audits. One two hour run per case is a sensitivity demonstration, not an annual production estimate or a statistical confidence interval.')
h('What you can tell your professor')
p('“Keeping the same underground route and truck assumptions, I increased road rolling resistance from 2% to 4%. HAULSIM predicted a modest increase in cycle time. These are assumed conditions on a New Afton informed model, and I have not measured the mine road or validated truck battery temperature.”')
evidence('results/scenario_comparison.csv and the three audit summaries in HAULSIM_Road_Surface_2026-10-15.')

page('9  How temperature connects to a truck cycle')
p('HAULSIM gives us the sequence of truck activities and their durations. In this project, the fitted temperature calculation runs in separate Python analysis. There is no validated battery temperature output inside the native HAULSIM project.')
h('The physical idea')
p('A battery warms when it produces more heat than its surroundings can remove. The simple heat balance is:')
math(mr('C ')+frac('dT','dt')+mr(' = Q − UA(T − ')+sub('T','air')+mr(')'))
table(['Term','Meaning'],[
('T and Tair','Battery temperature and surrounding air temperature'),
('C','Thermal capacity: how much heat is needed to raise temperature'),
('Q','Heat generated inside the battery'),
('UA','Combined heat transfer strength: how effectively heat leaves'),
('dT/dt','How quickly temperature changes with time')
],[1.45,5.55])
p('For the laboratory tests, we used a fitted current based version:')
math(frac('dT','dt')+mr(' = a')+sup('I','2')+mr(' − b(T − ')+sub('T','air')+mr(')'))
p('I is measured current. The fitted coefficient a converts squared current into a heating rate; b controls cooling toward air temperature. These fitted coefficients are not uniquely identified physical resistance, heat capacity or cooling measurements.')
h('The actual connection we built')
bullet('Read 29 activity states spanning two hours from the 3% road case.')
bullet('Estimate electrical demand using mechanical work, assumed 85% drivetrain efficiency, 20 kW auxiliaries and a nominal 354 kWh reference pack; convert to a surrogate load profile.')
bullet('Apply a temperature response fitted to an A123 laboratory cell. This shows a calculation workflow; it does not transfer laboratory cell validation to a Z50 battery pack.')
p('The illustrative coupled response rose only about 0.07°C above each assumed ambient temperature. That is smaller than the model’s laboratory prediction error, so the result cannot support a meaningful truck temperature or fire risk conclusion. Averaging current over activities also loses short current peaks, which matter because heating depends on current squared.')
evidence('APCOM_Coupled_Thermal_2026-10-16. Native mechanical energy units were inferred and checked against gravitational energy; independent unit confirmation remains pending.')

page('10  Test the formula against real battery data')
p('The latest test used measured current and three temperature channels from six 228 Ah LFP laboratory cells. Seven long pulse test records were selected: one initial record per cell and one later record for cell B1. This is 573,292 observations, but only six physical cells—not hundreds of thousands of independent experiments.')
h('How the comparison worked')
bullet('For the six cell comparison, fit on five cells and test the sixth unseen cell. Repeat so every cell is held out once.')
bullet('For the later test, fit on B1’s initial record and predict its later record. Do not tune the formula on that later result.')
bullet('Compare the formula with holding temperature at its measured starting value. Also test cooling only. Air temperature is assumed to be 25°C because an independent ambient time series is unavailable.')
picture(ROOT/'APCOM_228Ah_Thermal_Test_2026-10-16/figures/01_Held_Out_Comparison.png','Saved whole record prediction errors. Smaller RMSE means predictions are closer to measured temperature.',width=6.55)
table(['Test','Constant temperature','Formula','Meaning'],[
('Six cell pooled RMSE','0.274°C','0.187°C','31.8% lower aggregate error'),
('Later B1 RMSE','0.224°C','0.292°C','30.7% higher error')
],[1.8,1.65,1.4,2.15])
p('Only 5 of 18 initial cell and channel comparisons improved; 4 tied and 9 worsened. The later record was not a successful validation. Sensor locations are not mapped, the ambient condition is assumed, and several fitted parameters lie at zero. We therefore report mixed exploratory evidence, not a generally validated mining battery model.',bold=True)
evidence('APCOM_228Ah_Thermal_Test_2026-10-16, verification.json and metrics.csv. Source DOI 10.17632/dhr726bk6z.2, version 2, CC BY 4.0. Earlier A123 coefficients were not reused.')

page('11  What the APCOM paper can responsibly say')
h('A focused research question')
p('“How do assumed underground haul road conditions change a simulated BEV duty cycle, and what evidence is needed to turn that duty cycle into a reliable temperature estimate?”',bold=True)
p('This is a defensible practical scope to discuss with your professors. It supports the longer term early warning research without claiming that a detector or complete mine battery model already works. Because the accepted abstract promises an AI sensor fusion framework for early thermal runaway detection, your supervisors must decide whether this narrower paper aligns with that abstract or needs an agreed scope or title adjustment.')
table(['Use now with limitations','Still needed before stronger claims'],[
('Documented underground scenario and native road sensitivity results','Measured mine road and operating data for site calibration'),
('An explicit external heat balance workflow','Pack current, voltage, temperatures, ambient and cooling measurements'),
('Transparent laboratory comparison against simple baselines','Reliable unseen vehicle data and physically identifiable parameters'),
('Literature review and evidence requirements','Labelled abnormal events and validation of any warning or AI system')
],[3.5,3.5])
h('Questions to take to your professors')
bullet('Is this practical road to duty cycle to temperature workflow an acceptable conference scope, with core thesis methodology and key findings reserved for a journal?')
bullet('Are the New Afton route and historical Z50 assumptions acceptable as an explicitly illustrative case? Which inputs must be replaced by measured data?')
bullet('Should the mixed 228 Ah results be included as a validation limitation, rather than presenting only the improved aggregate score?')
bullet('Can a mine or equipment partner provide synchronized pack current, voltage, temperature, ambient, SOC, cooling status and duty cycle records?')
h('What remains unfinished')
p('The latest road and 228 Ah results still need to be integrated into the paper draft with supervisor approved scope. No validated AI detector, early warning lead time, battery fire probability or actual New Afton pack temperature has been established. Existing fire incident reports motivate the problem; they do not show that the road resistance tested here caused a fire.')
p('The acceptance email requests an 8–10 page review manuscript by 30 October 2026. The current nine page draft is a working draft, not a ready submission. Nothing has been submitted to the conference or sent to professors in this preparation task.')
evidence('Acceptance email provided by the user; supervisor feedback; APCOM research draft and evidence matrix. Prior work already combines HAULSIM, VentSim and battery fire modelling, so this project must not claim to be the first such combination.')

page('12  Find the files and repeat the analysis')
p('On this laptop, the main folder is C:\\Users\\athif\\Documents\\ChatGPT\\BEV. The names below are relative to that folder. On another laptop, the top level location may change; preserve the folder names and model file pairs.')
table(['Folder','Open first'],[
('BEV_HAULSIM_Walkthrough_2026-10-16','BEV_Walkthrough.hsm and Walkthrough.txt'),
('HAULSIM_Road_Surface_2026-10-15','01_Experiment_Results.txt; models/RR02, RR03 and RR04'),
('APCOM_Research_2026-10-15','01_New_Afton_Research_and_Modelling_Plan.docx; the 02 methods draft; 03 evidence matrix'),
('APCOM_Coupled_Thermal_2026-10-16','01_HAULSIM_Thermal_Methods_Brief.pdf'),
('APCOM_228Ah_Thermal_Test_2026-10-16','01_Thermal_Formula_Results.pdf and 02_APCOM_Text_for_Supervisor_Review.txt'),
('Claude_Handoff_2026-10-16','02_VISUAL_OVERVIEW.html; 01_FULL_HANDOFF_FOR_CLAUDE.txt'),
('BEV_Step_by_Step_Guide_2026-10-16','This guide')
],[3.05,3.95])
h('Repeat the laboratory calculation')
step('1','Keep the source and environment','Read the experiment’s 00_ANALYSIS_PROTOCOL.txt and 00_START_HERE.txt. The scripts need Python and scientific packages; this laptop uses the bundled Codex Python plus task local SciPy and Matplotlib paths. Another laptop must install suitable packages and adjust machine specific paths.')
step('2','Prepare and fit','In the 228 Ah experiment code folder, prepare_records.py verifies the selected raw records and builds aligned arrays. run_comparison.py fits the coefficients on the training splits and predicts the held out records. The full downloaded source archive is separate from the lightweight transfer package.')
step('3','Verify and report','Run verify_results.py to recompute errors and recurrence checks. Then make_figures.py and make_report.py regenerate plots and the briefing. Review the output rather than assuming a successful script means the research claim is validated.')
p('The archive source is https://data.mendeley.com/datasets/dhr726bk6z/2. Retain dataset version, licence, raw file hashes, training splits and coefficients. Copy the existing verified results before rerunning so the reference evidence remains available.')

page('13  Troubleshooting and essential terms')
table(['If you see this','Check this'],[
('The project will not open','Open the .hsm file and keep its same named .hsmdb beside it. Use a licensed compatible HAULSIM installation.'),
('Trucks do not haul','Check active fleet, assigned tasks, connected locations, loaders, available material and run duration.'),
('A report differs from the reference','Confirm model, payload, number of trucks, duration and completed versus partial deliveries. Record changed inputs.'),
('The road model shows no charging','This is expected: battery energy and charging are disabled in RR02, RR03 and RR04.'),
('There is no battery temperature report','The project’s fitted temperature analysis is external Python work. The native simulation does not establish a temperature result.'),
('The charging demo falls below its threshold','The threshold triggers a charging trip, not a guaranteed lower SOC limit. Energy accounting remains unresolved.'),
('A model file timestamp changed after opening','HAULSIM can touch its database on open. A timestamp alone cannot prove a scenario edit or a simulation run.')
],[2.0,5.0])
h('Essential terms')
table(['Term','Plain meaning'],[
('BEV','Battery electric vehicle.'),
('Payload','Ore carried by the truck, excluding the truck’s own mass.'),
('Cycle','A defined sequence of haul activities; compare complete cycles using the same definition.'),
('Grade and resistance','Grade is road steepness. Rolling resistance opposes tyre motion even on level ground.'),
('kW and kWh','kW measures power now; kWh measures energy accumulated over time.'),
('SOC','State of charge: the estimated fraction of battery charge remaining.'),
('Ambient temperature','Temperature of the surroundings; it need not equal battery temperature.'),
('Calibration and validation','Calibration fits model parameters. Validation tests predictions on data withheld from fitting.'),
('RMSE','Root mean square error: a prediction error measure in the same units as temperature. Lower is better.')
],[1.9,5.1])

page('14  Continue on another laptop')
p('GitHub transfers files. It does not recreate this Codex conversation, install HAULSIM or transfer its software licence. The written handoff supplies the project context to a new Codex chat. The repository supplied for this transfer was verified as private on 16 October 2026.')
link('Open the private BEV research repository','https://github.com/athifashaffy/bev-research')
step('1','Get the project package','Sign in to the same GitHub account on the other laptop and open the repository. Follow its README to download the portable research package once uploaded. Extract it into a normal local folder. Avoid running the project from inside a ZIP file.')
step('2','Open the guide and the overview','Read this guide, then open Claude_Handoff_2026-10-16/02_VISUAL_OVERVIEW.html in a browser. The HTML is a self contained explanation. Its local file links may still point to this laptop, so use the preserved folder structure to locate files on the other machine.')
step('3','Give Codex the research context','Open the extracted folder in Codex. Provide 01_FULL_HANDOFF_FOR_CLAUDE.txt as the project summary; its name does not prevent Codex from reading it. Also provide the current README and experiment START_HERE files. Ask it to confirm the saved evidence before extending the work.')
step('4','Open a practice HAULSIM project','If the other laptop has a compatible licensed HAULSIM installation, open a practice copy of the .hsm file. If it does not, you can still read the documents, browse the overview and inspect exported results.')
step('5','Keep changes deliberate','Keep one authoritative working copy at a time. Close HAULSIM before copying a model pair. Do not merge two independently edited .hsmdb databases as text. Record new settings and run results under a new dated folder.')
h('What the lightweight package does not replace')
p('A portable package is a snapshot, not continuous two way synchronization or a full backup. Large raw datasets, installed libraries, original downloaded third party publications and bulky videos may be excluded; the repository README and manifest identify what is included. Keep the full original BEV folder on this laptop. Do not claim a complete reproduction on another machine until its dependencies and source data have been restored and checks have passed.')
h('Your first session checklist')
bullet('I can tell the generic charging demonstration apart from the New Afton road study.')
bullet('I can open a practice model, inspect its settings, run two hours and find delivered tonnes.')
bullet('I understand why the laboratory formula result is mixed and why truck fire detection is still untested.')
bullet('I can show the evidence to my professors and ask for a specific decision on paper scope and missing measurements.')

dest=OUT/'Underground_BEV_Research_and_HAULSIM_Step_by_Step_Guide.docx'
doc.save(dest)
print(json.dumps({'output':str(dest),'paragraphs':len(doc.paragraphs),'tables':len(doc.tables),'pictures':len(doc.inline_shapes)},indent=2))
