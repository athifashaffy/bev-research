$ErrorActionPreference = 'Stop'
$guideRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$guideInput = Join-Path $guideRoot 'Underground_BEV_Research_and_HAULSIM_Step_by_Step_Guide.docx'
$guidePdf = Join-Path $guideRoot 'qa_render/guide.pdf'
$guideWord = $null
$guideDoc = $null
try {
    $guideWord = New-Object -ComObject Word.Application
    $guideWord.Visible = $false
    $guideWord.DisplayAlerts = 0
    $guideDoc = $guideWord.Documents.Open($guideInput,$false,$true,$false)
    $guideDoc.ExportAsFixedFormat($guidePdf,17)
    Write-Output ('Rendered with Microsoft Word; pages=' + $guideDoc.ComputeStatistics(2))
} finally {
    if ($null -ne $guideDoc) { $guideDoc.Close(0); [void][Runtime.InteropServices.Marshal]::ReleaseComObject($guideDoc) }
    if ($null -ne $guideWord) { $guideWord.Quit(); [void][Runtime.InteropServices.Marshal]::ReleaseComObject($guideWord) }
}
