Reproduce only the analytical examples, not HAULSIM simulations.
Requires Python 3 and reportlab. From the extracted package directory run:

python reproduce/analysis_examples.py --output-dir reproduced

Outputs: CSV, JSON audit and vector PDF figures. PNGs in the delivered package were rendered from these PDFs using Poppler. Thermal constants are illustrative, not calibrated vehicle parameters.
