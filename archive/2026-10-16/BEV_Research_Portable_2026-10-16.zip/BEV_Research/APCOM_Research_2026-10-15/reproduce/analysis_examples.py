"""Reproducible arithmetic and illustrative thermal response, not HAULSIM output."""
import math, csv, json, argparse
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-dir',type=Path)
args=parser.parse_args()
OUT=args.output_dir or Path(__file__).resolve().parents[2]/'APCOM_Research_2026-10-15'
(OUT/'calculations').mkdir(parents=True,exist_ok=True)
(OUT/'figures').mkdir(exist_ok=True)
g=9.81; m=48148+45000; theta=math.atan(.16); eta=.85; aux=20.; limit=480.
rows=[]
for rr in [.02,.03,.04]:
    force=m*g*(math.sin(theta)+rr*math.cos(theta))
    wheel10=force*(10/3.6)/1000
    vmax=(limit-aux)*1000*eta/force*3.6
    rows.append({'rolling_resistance_fraction':rr,'wheel_power_at_10_kmh_kW':wheel10,
                 'battery_terminal_demand_at_10_kmh_kW':wheel10/eta+aux,
                 'power_limited_speed_kmh':vmax})
with (OUT/'calculations/traction_check.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
thermal=[]
for ta in [25.,35.]:
    for ua in [400.,200.]:
        for t in range(0,14401,60):
            temp=ta+5000/ua*(1-math.exp(-ua*t/4e6))
            thermal.append({'ambient_C':ta,'UA_W_per_K':ua,'time_s':t,'battery_bulk_C':temp})
with (OUT/'calculations/illustrative_thermal_response.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(thermal[0]));w.writeheader();w.writerows(thermal)
# An independent finite-difference check of the analytical, constant-coefficient response.
errors=[]
for dt in [10.,1.]:
    t=35.
    for _ in range(int(14400/dt)): t += dt*(5000-200*(t-35))/4e6
    exact=35+25*(1-math.exp(-200*14400/4e6))
    errors.append(abs(t-exact))
assert errors[1]<errors[0] and errors[1]<.001
assert rows[0]['power_limited_speed_kmh']>rows[1]['power_limited_speed_kmh']>rows[2]['power_limited_speed_kmh']
thermal_timescales=[{'UA_W_per_K':ua,'time_constant_s':4e6/ua,
 'fraction_of_equilibrium_rise_at_4h':1-math.exp(-14400/(4e6/ua)),
 'equilibrium_rise_K':5000/ua} for ua in [400.,200.]]
report={'classification':'Analytical feasibility and assumed thermal illustration; no new HAULSIM runs',
 'inputs':{'empty_mass_kg':48148,'payload_kg':45000,'payload_status':'inferred scenario, not measured per-trip payload',
 'grade':.16,'grade_definition':'local ramp-segment rise divided by horizontal run; not a complete-route average',
 'gravity_m_per_s2':g,'road_angle_rad':theta,'force_model':'m*g*(sin(theta)+rolling_resistance_fraction*cos(theta)); theta=atan(grade)',
 'eta_drive_assumed':eta,'auxiliary_kW_assumed':aux,'battery_continuous_limit_kW_from_historical_spec':limit,
 'thermal_C_J_per_K_assumed':4e6,'thermal_heat_W_assumed':5000,'initial_temperature':'equal to ambient','active_cooling_W':0},
 'traction':rows,'loaded_gravitational_energy_135m_kWh':m*g*135/3.6e6,
 'empty_gravitational_energy_135m_kWh':48148*g*135/3.6e6,
 'payload_gravitational_energy_135m_kWh':45000*g*135/3.6e6,
 'thermal_endpoints':[r for r in thermal if r['time_s']==14400],
 'thermal_timescales':thermal_timescales,
 'verification':{'euler_10s_error_C':errors[0],'euler_1s_error_C':errors[1],'monotonic_power_check':'pass'}}
(OUT/'calculations/calculation_audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')

def plot(pdf,title,subtitle,series,xmax,ymin,ymax,xlabel,ylabel):
    c=canvas.Canvas(str(pdf),pagesize=(650,365)); c.setFont('Helvetica-Bold',15);c.drawString(62,337,title)
    c.setFont('Helvetica',9);c.drawString(62,320,subtitle)
    x0,y0,w,h=62,68,546,220
    c.setFont('Helvetica',9)
    for i in range(6):
        x=x0+w*i/5; val=xmax*i/5
        c.setStrokeColor(HexColor('#d9dfe3'));c.line(x,y0,x,y0+h);c.setFillColor(HexColor('#222222'));c.drawCentredString(x,y0-14,f'{val:g}')
    for i in range(6):
        y=y0+h*i/5; val=ymin+(ymax-ymin)*i/5
        c.setStrokeColor(HexColor('#d9dfe3'));c.line(x0,y,x0+w,y);c.drawRightString(x0-7,y-3,f'{val:g}')
    palette=['#176d9c','#d77622','#23764c','#b44456']
    for index,(label,points) in enumerate(series):
        color=HexColor(palette[index]);c.setStrokeColor(color);c.setLineWidth(2)
        path=c.beginPath()
        for j,(x,y) in enumerate(points):
            px=x0+x/xmax*w;py=y0+(y-ymin)/(ymax-ymin)*h
            if j==0:path.moveTo(px,py)
            else:path.lineTo(px,py)
        c.drawPath(path)
        c.setFillColor(color);c.setFont('Helvetica',8.5);c.drawString(x0+(index%2)*280,43-(index//2)*14,label)
    c.setFillColor(HexColor('#222222'));c.setFont('Helvetica',10);c.drawCentredString(x0+w/2,11,xlabel)
    c.saveState();c.translate(14,y0+h/2);c.rotate(90);c.drawCentredString(0,0,ylabel);c.restoreState();c.save()

plot(OUT/'figures/traction_check.pdf','Power feasibility on a 16% ramp','45 t payload scenario; efficiency 0.85 and auxiliaries 20 kW are assumptions',
 [(f'Rolling resistance {rr*100:.0f}%',[(v, m*g*(math.sin(theta)+rr*math.cos(theta))*(v/3.6)/1000/eta+aux) for v in range(1,15)]) for rr in [.02,.03,.04]]+
 [('Historical battery continuous limit',[(0,480),(14,480)])],14,0,1000,'Speed (km/h)','Battery terminal power (kW)')
plot(OUT/'figures/thermal_illustration.pdf','Illustrative bulk temperature response','Assumed C = 4 MJ/K, heat = 5 kW, initial T = ambient; not an OEM or mine prediction',
 [(f'Ambient {ta:.0f} C; UA {ua:.0f} W/K',[(r['time_s']/3600,r['battery_bulk_C']) for r in thermal if r['ambient_C']==ta and r['UA_W_per_K']==ua]) for ta in [25.,35.] for ua in [400.,200.]],4,20,50,'Elapsed time (h)','Bulk temperature (C)')
print(json.dumps(report,indent=2))
