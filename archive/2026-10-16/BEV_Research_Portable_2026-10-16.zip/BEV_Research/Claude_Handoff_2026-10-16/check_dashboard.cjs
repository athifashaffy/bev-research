const fs=require('fs');
const path=require('path');
const {pathToFileURL}=require('url');
const {chromium}=require('C:/Users/athif/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async()=>{
 const root=__dirname,qa=path.join(root,'qa');fs.mkdirSync(qa,{recursive:true});
 const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'});
 const page=await browser.newPage({viewport:{width:1440,height:1000}});
 const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 await page.goto(pathToFileURL(path.join(root,'02_VISUAL_OVERVIEW.html')).href);
 await page.getByRole('heading',{name:'Three parts of your research'}).count();
 await page.screenshot({path:path.join(qa,'overview_desktop.png'),fullPage:true});
 for(const name of ['work','results','evidence','next','files','simple']){
  await page.locator(`[data-tab="${name}"]`).click();
  if(!await page.locator(`#p-${name}`).isVisible())throw Error('Tab not visible: '+name);
 }
 await page.locator('[data-tab="results"]').click();
 for(const study of ['228','a123','bulk','generic','road']){
  await page.locator(`[data-study="${study}"]`).click();
  if(await page.locator('#study-output').innerText()==='')throw Error('Empty study');
  const broken=await page.locator('#study-output img').evaluateAll(imgs=>imgs.filter(x=>!x.complete||x.naturalWidth===0).length);
  if(broken)throw Error('Broken study image '+study);
 }
 await page.locator('[data-study="228"]').click();
 if(!(await page.locator('#study-output').innerText()).includes('30.7%'))throw Error('Missing adverse result');
 await page.locator('[data-tab="evidence"]').click();
 await page.locator('#lit-search').fill('Eroglu');
 if(await page.locator('#literature details').count()!==1)throw Error('Literature search failed');
 await page.locator('#lit-search').fill('');
 if(await page.locator('#literature details').count()!==25)throw Error('Literature count mismatch');
 await page.setViewportSize({width:390,height:844});
 for(const tab of ['simple','work','results','evidence','next','files']){
  await page.locator(`[data-tab="${tab}"]`).click();
  const width=await page.evaluate(()=>({body:document.documentElement.scrollWidth,view:innerWidth}));
  if(width.body>width.view+2)throw Error('Mobile overflow '+tab+' '+JSON.stringify(width));
 }
 await page.locator('[data-tab="simple"]').click();
 await page.screenshot({path:path.join(qa,'overview_mobile.png'),fullPage:true});
 await page.goto(pathToFileURL(path.join(root,'qa_inline_preview.html')).href);
 const frame=page.frameLocator('iframe');
 await frame.locator('[data-stage="battery"]').click();
 if(!(await frame.locator('#bev-stage-detail').innerText()).includes('0.292'))throw Error('Inline battery interaction failed');
 await frame.locator('[data-stage="warning"]').click();
 if(!(await frame.locator('#bev-stage-detail').innerText()).includes('Not completed'))throw Error('Inline warning interaction failed');
 await frame.locator('[data-stage="truck"]').click();
 await page.setViewportSize({width:800,height:1000});
 await page.screenshot({path:path.join(qa,'inline_desktop.png'),fullPage:true});
 await page.setViewportSize({width:360,height:950});
 await frame.locator('[data-stage="battery"]').click();
 await page.screenshot({path:path.join(qa,'inline_mobile.png'),fullPage:true});
 const inlineSize=await frame.locator('body').evaluate(x=>({body:x.scrollWidth,view:innerWidth}));
 if(inlineSize.body>inlineSize.view+2)throw Error('Inline mobile overflow '+JSON.stringify(inlineSize));
 if(errors.length)throw Error(errors.join('\n'));
 const result={passed:true,standalone_tabs_checked:6,result_views_checked:5,reference_rows:25,desktop_and_mobile_checked:true,inline_stages_checked:3,script_errors:errors};
 fs.writeFileSync(path.join(root,'06_VISUAL_VERIFICATION.json'),JSON.stringify(result,null,2));
 console.log(JSON.stringify(result,null,2));await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
