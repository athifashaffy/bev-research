# Independent QA — APCOM_Research_2026-10-15

Performed 15 October 2026 by a second agent, independently of the agent that
authored the package. Read-only against the delivered files; nothing in
`APCOM_Research_2026-10-15/` or `research/apcom_2026_10_15/` was modified.

Target: `APCOM_Research_2026-10-15/02_APCOM_Methods_and_Preliminary_Calculations_Draft.docx`
(147 paragraphs and 3,429 words by Word's counter at first pass; 183 paragraphs
and 18 references after the fixes below; 9 pages throughout).

## Verdict

Template conformance, citation integrity, arithmetic and separation from the
earlier HAULSIM work all pass.

Six defects were found and all six are now fixed: D1–D3 (§6), the Onaping
attribution (§4), D4 (§4b) and D5 (§7). All were raised with the authoring
agent, fixed by it, and re-verified here. **None affected any number in the
paper.**

D5 — a wording overclaim in `00_START_HERE.txt` about the HAULSIM demo database
— was the last open item and is now closed. Two independent methods (a physical
SQLite page diff here, per-table logical row digests by the authoring agent,
published as `08_HAULSIM_File_State_Check.json`) agree that no scenario or
result content changed, and the file's wording has been narrowed to a claim the
filesystem supports, with its causation limit stated explicitly.

No open defects remain in the package as of this writing.

Two findings this report originally raised were **withdrawn** as QA tooling
errors after the authoring agent pushed back — see "Withdrawn findings".

The package is 9 pages, within the 8–10 the acceptance email requires for
30 October 2026, and both PDFs are regenerated in step with their DOCX
sources.

## 1. Template contract — PASS

Checked against `research/audit_2026-10-08/APCOM_Paper_Template.docx` by
SHA-256 of every part in the OPC package.

| Contract clause | Observed | |
|---|---|---|
| Preserve-only parts unchanged | 0 unexpected part-hash changes, 0 removed | pass |
| Added parts | `word/media/image1.png`, `image2.png` only | pass |
| Letter portrait, single section | 8.5 × 11.0 in, 1 section | pass |
| Margins top/left/right 1 in, bottom 1.5 in | 1.0 / 1.0 / 1.0 / 1.5 in | pass |
| Single column | no `w:cols` override | pass |
| No headers, footers, page numbers | 0 non-empty header/footer paragraphs | pass |
| Normal = Times New Roman 10 pt | Times New Roman, 10.0 pt | pass |
| Template styles reused, none invented | Paper Title, Author list, Author affiliations, Keywords, LEVEL 1, equation, Figure, Figure caption, Table title, References | pass |
| Tables centred Calibri 9 pt | all runs Calibri, all sizes 9.0 pt | pass |
| Table top/bottom border 1 pt | `w:sz=8` eighths = 1.0 pt | pass |
| Header separator 0.5 pt | `w:sz=4` eighths = 0.5 pt, on header-row cell bottoms | pass |
| No vertical borders | left/right/insideV all `nil` | pass |
| Small tables do not split | `cantSplit` on every row of both tables | pass |
| Figures inline, one image object each | 2 `wp:inline`, 0 `wp:anchor` | pass |
| Equations as Word math objects | 7 `m:oMath` elements | pass |
| References alphabetical with DOI/URL | 16 refs at first pass (18 after the grey-lit additions), alphabetical, all carry DOI or URL | pass |

An earlier draft of this report flagged the reference list as out of
alphabetical order. That was a false positive on the QA side: the only
"offending" pair was `LaMarsh` following `Ladouceur`, which is correct
case-insensitive bibliographic order. The checker was comparing raw ASCII,
where `'M'` (77) sorts before `'d'` (100). The list is correctly ordered.

Page count is 9, inside the 8–10 pages the acceptance email requires for
30 October 2026.

No leftover template boilerplate: zero hits for `Lorem`, `TBD`, `TODO`,
`First A. Author`, `placeholder`, `Insert `, `Click here` and similar.
Character encoding is clean — no replacement characters or mojibake;
`Nylén` and `Acuña` are correctly encoded.

## 2. Citation integrity — PASS, no fabricated references

Every one of the 16 references was resolved against an external registry.
This matters because the template contract says the example references in the
source template were fabricated demonstration slots.

Ten DOIs resolved, and for each the registry title, first author and year match
the cited string (title-word overlap ≥ 0.6, author surname present, year
matches):

- `10.1149/1.2113792` — Bernardi, Pawlikowski, Newman 1985 (Crossref)
- `10.1016/j.ress.2026.112668` — Eroglu et al. 2026 (Crossref)
- `10.1007/s42461-024-01146-4` — Hooli et al. 2024 (Crossref)
- `10.3390/batteries8040034` — Klink et al. 2022 (Crossref)
- `10.36487/ACG_rep/1710_46_Kukkonen` — Kukkonen 2017 (Crossref)
- `10.1080/19236026.2023.2266351` — Le et al. 2024 (Crossref)
- `10.48550/arXiv.2511.22721` — Pareek et al. (Crossref)
- `10.1149/1945-7111/ad2440` — Torres-Castro et al. 2024 (Crossref)
- `10.21949/w5aa-m571` — Torres-Castro et al. 2026, NHTSA (DataCite)

Six URL-only sources: four return HTTP 200 as PDFs or HTML. Two
(`gmggroup.org`, `stacks.cdc.gov`) return 403 to scripted requests — bot
protection, not dead links. Both were confirmed real by other means: the GMG
document is already downloaded at `sources/GMG_BEV_2022.pdf`, and the NIOSH
record resolves to the exact cited title, "Concerns with the Environmental
Susceptibility of Mine Utility Vehicle and Rubber-tired Mantrip LITHIUM-ion
Batteries", published 25 February 2024.

The `Coeur Mining (2026)` citation was checked closely because New Afton has
historically been a New Gold asset. It is correct: Coeur Mining acquired
New Gold in March 2026, and the cited SEC EDGAR exhibit is titled "New Afton
Operations, British Columbia, Technical Report Summary", effective
31 December 2025. Sections 13.4–13.7 exist and cover operations, materials
handling (ore passes, underground crushers, conveyor to surface, truck
haulage), underground infrastructure, and ventilation — matching how the draft
uses the source.

## 3. Arithmetic — PASS, reproduces exactly

`calculations/calculation_audit.json` was re-derived from first principles.
Every published figure matches to floating-point identity (< 1e-6 kW, < 1e-9
for energy and temperature).

Total mass 48,148 + 45,000 = 93,148 kg.

Traction. The audit's force model is
`F = m g (sin θ + C_r cos θ)` with `θ = atan(0.16)` and `g = 9.81`. This was
determined by elimination: treating the grade as `sin θ` directly misses by up
to 6.4 kW, and `g = 9.80665` misses by 0.17 kW; `atan` with 9.81 reproduces all
nine values exactly. Using `atan` is the correct convention if the grade is
rise over run.

| C_r | wheel kW @10 km/h | terminal kW | power-limited km/h |
|---|---|---|---|
| 0.02 | 451.152679 | 550.767857 | 8.666689 |
| 0.03 | 476.216716 | 580.254960 | 8.210548 |
| 0.04 | 501.280754 | 609.742063 | 7.800020 |

Terminal demand is `wheel/0.85 + 20 kW`; the speed limit solves
`(480 − 20) × 0.85` kW at the wheel. Consistent throughout. At C_r = 0.04 the
610 kW demand is 1.27× the 480 kW continuous limit, which is why the speed
derates — the derate is a real consequence of the stated inputs, not an
assumption bolted on.

Gravitational energy is `m g h` with h = 135 m, g = 9.81: loaded 34.2668205,
empty 17.7124455, payload 16.5543750 kWh. All exact.

Lumped thermal model is `T = T_amb + (Q/UA)(1 − exp(−t·UA/C))` with Q = 5 kW,
C = 4 MJ/K, t = 14,400 s. All four endpoints exact: 34.538403016,
37.831193601, 44.538403016, 47.831193601 °C. Steady-state rise is 12.5 K at
UA = 400 and 25 K at UA = 200, with time constants 10,000 s and 20,000 s —
so at four hours the system is at 76% and 51% of its asymptote respectively.
Worth stating in the paper, because it means neither case has settled and the
endpoint temperatures understate the steady state.

The audit's own Euler convergence check (0.0022 °C at 10 s, 0.00022 °C at 1 s,
a clean factor of ten) is consistent with first-order accuracy.

## 4. Grey-literature provenance — one attribution unsupported

Two incident-summary decks were added to the reference list after the first QA
pass. Neither has a DOI, so both were checked by forensic inspection of the
PDFs themselves rather than by registry lookup.

**Macassa — verifies verbatim, no change needed.** Slide 1 reads "Macassa Mine
/ Battery Fires / Summary / February 15, 2024 / Norm Ladouceur". The cited
author and date are taken from the slide itself. Note that the PDF's `/Author`
metadata says "Sonia Cheung" — the on-slide byline is the right choice and the
metadata is almost certainly whoever exported the file.

**Onaping — "Holmik S" has no supporting evidence.** The cited entry is:

> Holmik S, Harris C (2021) Incident Summary: Onaping Depth BEV Fire,
> 2020-07-06. Glencore Sudbury Integrated Nickel Operations; Workplace Safety
> North symposium.

The file is an image-only deck: all 23 pages yield 102 extractable characters
in total, and `Holmik` appears 0 times. Pages 1 and 23 were rendered at 110 dpi
and read visually — the title slide carries only "Incident Summary / Onaping
Depth BEV Fire / 2020-07-06" with the Glencore logo and no byline, and the
closing slide has no credits. The only author evidence anywhere in the file is
its metadata:

- `/Title` — "Incident Summary - Onaping Depth BEV Fire"
- `/Author` — "Harris, Craig (Sudbury - CA)"
- `/CreationDate` — `D:20210117223108-05'00'`

That supports "Harris C (2021)" at best and supports no second author at all.
Under the package's own evidence discipline, recommend a corporate author:

> Glencore Sudbury Integrated Nickel Operations (2021) Incident Summary:
> Onaping Depth BEV Fire, 2020-07-06. Workplace Safety North.

This also keeps alphabetical order valid — `Glencore` sorts before `Hooli`.

**Resolved.** Flagged to the authoring agent, which adopted the corporate-author
form in both documents, their in-text citations and the evidence matrix. The
Macassa/Ladouceur attribution was correctly left alone. Re-checked: the entry
now reads `Glencore Sudbury Integrated Nickel Operations (2021) Incident
Summary: Onaping Depth BEV Fire…`, the list is still alphabetical, and the
paper is still 9 pages.

## 4a. Reference list ↔ evidence matrix — PASS

Cross-checked `03_Literature_Evidence_Matrix.csv` (25 rows) against the paper's
reference list (18 entries) by author-surname and year.

- Every paper reference appears in the matrix. The matrix is a proper superset.
- Every reference entry is actually cited in the body — no orphan entries.
- All 18 entries carry a DOI or URL.
- Case-insensitive alphabetical ordering holds.

The 7 matrix-only rows are surveyed-but-not-cited sources, and each carries an
explicit limitation note rather than being silently dropped:

| Source | Recorded limitation |
|---|---|
| Barrick Gold (2022) | confirms the fire and fleet suspension, not the failure mechanism |
| Gillett / Ontario Mine Rescue (2021) | district names are not exact mine identities |
| MacLean Engineering (n.d.) | incident site and date not established from the inspected slides |
| MacLean Engineering (2021) | aggregate experience, not raw Z50 telemetry |
| New Gold New Afton (2023) | documents four Z50 trucks in 2023; do not infer present fleet |
| RPMGlobal (2021) | confirms electric haulage support, not a cell thermal-runaway solver |
| Sandvik TH550B (2026) | "Successor specification is not interchangeable with historical Z50 inputs" |

That last line is the one `00_START_HERE.txt` demands — current TH550B and
MacLean inputs are held separate from the historical Z50 case rather than
silently mixed. Recorded as a pass.

## 4b. In-text citation resolution — one unresolvable abbreviation

Every author-year citation in the paper body resolves to a reference-list
entry, with one exception.

**D4 — `GMG (2022)` is an undefined abbreviation.** Paragraph 18 reads "…while
GMG (2022) places BEVs within mine ventilation, charging and maintenance
design." The abbreviation is never expanded anywhere in the document, and the
reference list carries the source under `Global Mining Guidelines Group (2022)`.
A reviewer scanning the list for "GMG" will not find it. Either spell the name
out at that point or introduce it on first use as "Global Mining Guidelines
Group (GMG)".

**Resolved.** The authoring agent spelled the name out. Re-checked: the string
`GMG` now appears zero times anywhere in the document, and paragraph 18 reads
"…while Global Mining Guidelines Group (2022) places BEVs within mine
ventilation, charging and maintenance design", matching the reference entry
verbatim. Every in-text citation in the paper now resolves.

Two apparent mismatches were investigated and are **not** defects:

- `Elcin Eroglu et al. (2026)` — Crossref records the first author's family
  name as the compound "Elcin Eroglu", given name "Sultan". The in-text form
  and the list entry both match the registry. Correct as written.
- `Yantek and Brown (2024)` — maps to the `Yantek DS, Brown CB (2024)` entry.

Both were artifacts of a surname-extraction regex in the QA script, not of the
paper.

## 5. Post-fix re-verification of D1–D3

All three defects below were fixed and the package re-checked from scratch:

- D1 — the first heading now reads "VALIDATION REQUIREMENTS", followed by
  "CONCLUSIONS". No duplicate claim.
- D2 — the draft now states "a local ramp-segment design grade of 16%
  (θ = atan(0.16)), not the average grade of Route A or B".
- D3 — `02_APCOM_Methods_Draft.generated.docx` is gone (`Test-Path` False).

Re-run of the full contract check after the fixes: 9 pages, 153 paragraphs,
18 references, zero unexpected preserve-only part changes, and all traction,
energy and thermal values still reproduce to floating-point identity.

## 6. Defects D1–D3 as originally raised

**D1 — Duplicate conclusions sections.** The outline ends with LEVEL 1
"VALIDATION REQUIREMENTS AND CONCLUSIONS" (4 paragraphs, 262 words)
immediately followed by LEVEL 1 "CONCLUSIONS" (2 paragraphs, 136 words).
Two headings claim the conclusions. Rename the first to "VALIDATION
REQUIREMENTS".

**D2 — Grade of 16% is not reconcilable with the stated route geometry as
written.** The draft gives Route A as 1,500 m with 135 m rise and Route B as
1,700 m with 178 m rise — 9.0% and 10.5% average. The traction check uses
16%. These are reconcilable: a 16% ramp climbing 135 m has a horizontal run of
135/0.16 = 843.75 m and an inclined road length of 135/sin(atan 0.16) = 854.5 m,
leaving roughly 645 m of Route A near level if the 1,500 m is measured along the
road. (Corrected after review — the first draft of this report quoted 844 m as
the ramp length; that figure is the horizontal run, not the road distance.)
But the draft does not say so, and a reviewer who
divides 135 by 1,500 will read 16% as an error. Add one sentence declaring
0.16 as a ramp-segment design grade rather than a route average. Note that the
gravitational energy figures correctly use h = 135 m and are unaffected either
way.

**D3 — Stale duplicate in the delivered package.**
`02_APCOM_Methods_Draft.generated.docx` is an earlier build, three paragraphs
behind the final file and missing the `Coeur Mining (2026)` paragraph and
citation entirely. Shipping two near-identical `02_` files invites the
supervisor reviewing the wrong one. Delete it from the package or move it out
of the deliverable folder. `00_START_HERE.txt` does not mention it.

## 7. HAULSIM — separation from the APCOM package holds

`00_START_HERE.txt` states that no native model was modified and no simulation
run in this pass. That claim was tested rather than taken on trust.

**No new simulation output.** Every file under `results\haulsim\` is dated
9 October 2026 — the earlier Professor Pack work. Nothing in that tree has been
written during this pass.

**Those runs are a different study, and none of them leaked in.** The
9 October scenarios assume a 400 kWh pack (the CSV column is literally named
`battery_kwh_ASSUMED`) against this package's 354 kWh register value, with
300 m and 450 m lifts, four- and six-truck fleets and 600 kW chargers — none of
which matches the Route A/B geometry or the single-truck case here. Both
documents were scanned for every operational figure in
`results\haulsim\scenario_summary.csv`: throughputs 163.0 / 117.5 / 201.1 /
210.7 tph, tonnages 19,236 / 13,860 / 23,730 / 24,864, load counts, pack size,
lifts, fleet sizes and charger ratings. **Zero leakage.** The single apparent
hit was the digit string `19236` occurring inside the DOI
`10.1080/19236026.2023.2266351`.

Importing any of it would have been precisely the silent mixing
`00_START_HERE.txt` forbids, so this is a meaningful pass rather than a
technicality.

**Known problems are carried forward, not buried.** The 9 October runs are
stamped `PRELIMINARY_NATIVE_OPERATIONAL_OUTPUT; ENERGY_SOC_UNRECONCILED` in
their own summary. Paragraph 57 of the paper and paragraph 152 of the plan both
surface that unresolved energy/SOC reconciliation as a prerequisite before
native SOC or net energy may be used.

**Self-reported counts verified.** The claims in
`07_Verification_and_Status.json` were checked independently: matrix 25 rows,
parameter register 12, fire cases 6, operating scenarios 36 — and all 36 carry
`Status = PROPOSED - not executed`. PDF page counts read from the PDF page
trees are 15 and 9, matching the file's claim, with the paper inside the 8–10
page requirement.

**D5 — one wording overclaim.** `models\haulsim\demo\Demo_Underground_BEV.hsmdb`
was written today at 20:26 and its SHA-256 matches none of the three archived
9 October copies, which contradicts "No native model was modified" as literally
written. The evidence says this is benign rather than an edit: the file is
SQLite with a 4,096-byte page size and exactly 226 pages, making it exactly one
page larger than the 921,600-byte 9 October snapshot, and HAULSIM 3.8 was open
on the desktop at the time. That is the signature of the application opening
the database, not of a scenario change. The risk is presentational — a
supervisor who checks timestamps will see a model file modified during a pass
that claims none was. Raised with the authoring agent with a suggested
rewording.

**D5 — RESOLVED.** Settled by two independent methods that agree.

*This report's method — physical page diff.* Both files are SQLite with a
4,096-byte page size. Of the 225 pages present in both, **219 are byte-identical
and 6 differ**: pages 0, 46, 142, 223 and 224 (0-based), all of which are
`sqlite_master` pages carrying `CREATE TABLE/INDEX/VIEW/TRIGGER` text, plus page
141. Page 141 is not an edit — today's file lists it as the freelist head
(freelist count 1) and its former contents were relocated **byte-identical** to
the appended page 225 (0 differing bytes). So every page holding scenario or
result data is unchanged; the whole diff is a `sqlite_master` reorganisation
plus one relocated data page. The live object inventory is identical either way:
105 table names in both, none added or removed, and `HS_TruckType` has the same
30 columns in both.

*The authoring agent's method — logical row digests.* It independently published
`08_HAULSIM_File_State_Check.json`: read-only transactions, per-table SHA-256
over sorted serialized rows, 106 tables. It reports `same_schema = True` and
**zero changed tables** against both 9 October archives, and its file metrics
match this report's exactly — 925,696 bytes / 226 pages / freelist 1 today
versus 921,600 / 225 / freelist 0 archived.

The two methods cross-validate: a physical diff that finds no data page changed,
and a logical digest that finds no table's contents changed. The one loose end
this report had — a stray `HS_TruckType_1` string appearing only in today's copy,
which looks like an `ALTER TABLE` rebuild artifact — is resolved by the agent's
`same_schema = True`: it is stale residue in page free space, not a live object.

*Caveat carried forward, correctly.* Neither method establishes **what caused**
the rewrite. The agent states this limit explicitly rather than asserting the
HAULSIM-open explanation, which is the right call — that explanation remains an
inference from HAULSIM 3.8 being open at the time, not an observation.

*A third archive legitimately differs.* `Professor_Pack_2026-10-09` is a
different logical snapshot (2,281,472 bytes, 557 pages, 338 free) differing in
`HS_GeneralProperty`, `HS_Truck`, `HS_TruckType`, `NetworkScenario`, `TruckType`
and `sqlite_sequence`. The agent correctly declines to treat it as a baseline,
since differences against it date nothing.

*Wording fixed.* `00_START_HERE.txt` no longer claims "No native model was
modified". It now reads that no new native simulation was run, that the working
demo database has a newer timestamp and hash, that a read-only comparison
confirms schema and table contents match the two archives, that the extra page
is free space, and that the cause was not independently observed. That is a
claim the filesystem supports. **No paper number was ever affected.**

One residual nitpick, recorded for completeness and not raised: the file says
"The additional 4096-byte page is free space." Mechanically it is the *vacated*
page 141 that is free, while the appended page carries the relocated data. The
net statement — the file contains one page of free space — is true.

## Not checked

The HAULSIM scenario *content* was not opened or inspected — this audit
establishes only that the 9 October results are excluded from the APCOM
package, not whether those results were themselves correct. The APCOM paper
makes no claim that depends on them.

## Withdrawn findings

Two findings were raised and then withdrawn after the authoring agent pushed
back and the pushback checked out. Both were defects in the QA tooling, not the
package. They are recorded here rather than deleted, because a QA report that
hides its own false positives is not trustworthy.

- **Ramp geometry.** An early draft of §6/D2 quoted 844 m as the ramp length.
  That is the horizontal run; the inclined road length is 135/sin(atan 0.16) =
  854.5 m. Corrected in place.
- **Plan has no reference list.** This report previously stated that
  `01_New_Afton_Research_and_Modelling_Plan.docx` carried no bibliography and
  raised it as a question for the supervisor. It is wrong. The plan has a
  Heading1 "References and reading priorities" at paragraph 271 followed by
  **25 entries, case-insensitively alphabetical, all carrying a DOI or URL**,
  matching the evidence matrix exactly. The QA script keyed on Word's
  `References` paragraph style; these paragraphs use `Normal`, so the detector
  returned zero. No supervisor decision is needed.

## Scope limit — what "pass" does and does not mean

This report verifies that the package is internally consistent, conforms to the
template contract, cites real sources, and reproduces its own arithmetic. It
does **not** validate the underlying engineering:

- Whether a lumped single-`UA` thermal model is the right model is a modelling
  judgement, not an arithmetic one. The equation is solved correctly; that is
  all that was checked.
- Whether the input parameters describe the real New Afton operation is not
  established. The register marks most of them as assumptions or sensitivity
  values, which is the correct treatment.
- Nothing empirical was verified. No simulation was run and no measured
  telemetry exists in this package, so the thermal figures are illustrative.

The package states all three of these limits itself. Nothing here should be
read as validating performance, a fire probability, or detection capability.

## Method note

All checks are read-only. Word COM, where used, operated on temporary copies.
Nothing in `APCOM_Research_2026-10-15/` or `research/apcom_2026_10_15/` was
written by this QA pass — the authoring agent applied every fix itself, which
is why the package rebuilds visible in its timestamps are its own.
