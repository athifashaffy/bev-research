from pathlib import Path
import csv,json,hashlib,shutil,base64,zipfile,html
ROOT=Path(__file__).resolve().parent.parent
OUT=Path(__file__).resolve().parent
def read_json(p):return json.loads((ROOT/p).read_text(encoding='utf-8-sig'))
def read_csv(p):
    with (ROOT/p).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

streams=[
 {'id':'generic','name':'Generic charging & traffic','period':'9–16 Oct','category':'Native executed · energy unresolved','status':'limited',
  'question':'Can a generic underground BEV fleet haul, queue and recharge in HAULSIM?',
  'completed':'Four 120-hour native scenarios, plus a separate two-hour walkthrough with four trucks.',
  'result':'S1–S4: 163.017 / 117.458 / 201.102 / 210.712 t/h over 118 analysis hours. Walkthrough: 336 t in 2 h.',
  'assumptions':'42 t payload, 400 kWh assumed battery; generic network, four/six trucks. S2 changes both lift and charging trigger.',
  'limit':'ENERGY_SOC_UNRECONCILED. These production outputs do not validate battery consumption, reserves or temperature.',
  'source':'results/haulsim/scenario_summary.csv'},
 {'id':'newafton','name':'New Afton historical Z50 case','period':'9 Oct onward','category':'Native A executed · B pending','status':'limited',
  'question':'Can historical public route summaries support a clearly labeled underground case?',
  'completed':'Schematic Route A/B projects, corrected 45 t payload, independent Python study, native A run and software video.',
  'result':'Earlier native A: 225 t in 2 h. Independent Python baseline: A 945 t / B 855 t in 8 h under swap assumptions.',
  'assumptions':'A: 1,500 m / 135 m rise. B: 1,700 m / 178 m rise. Historical 354 kWh Z50, assumed 45 t operating payload.',
  'limit':'No surveyed alignment or mine-calibrated truck. Native B pending. Earlier A configuration differs from the later 391 kW road study.',
  'source':'New_Afton_Professor_Case/START_HERE.txt'},
 {'id':'road','name':'Road rolling-resistance experiment','period':'15 Oct','category':'Native executed & reconciled','status':'done',
  'question':'What changes when assumed road resistance alone goes from 2% to 4%?',
  'completed':'Three native 120-minute runs: RR02, RR03, RR04; one deterministic replication each.',
  'result':'Cycle 23.967 → 24.308 → 24.631 min. 2–4% resistance adds 2.77% cycle time and 6.04% loaded travel time.',
  'assumptions':'Same 1,500 m / 135 m route, 45 t payload, 391 kW wheel ceiling; ground structure and traction coefficient fixed.',
  'limit':'Assumed resistance, not measured ruggedness. All deliver 180 t at the cutoff. Battery energy/charging/regen disabled.',
  'source':'HAULSIM_Road_Surface_2026-10-15/results/scenario_comparison.csv'},
 {'id':'bulk','name':'One-feature bulk-temperature illustration','period':'15–16 Oct','category':'Analytical illustration','status':'assumed',
  'question':'For the same initial temperature and heat input, how does assumed mine air temperature affect the heat balance?',
  'completed':'Closed-form thermal curves and numerical checks. October 16 cases share the same 25°C initial condition.',
  'result':'At 120 min, air 25 / 35 / 40°C gives bulk temperature 31.416 / 36.548 / 39.114°C.',
  'assumptions':'C = 4 MJ/K, Q = 5 kW constant, UA = 400 W/K. This heat input is not extracted from HAULSIM.',
  'limit':'Uncalibrated illustrative pack parameters; no active cooling, local hotspot or runaway. Not a mine prediction.',
  'source':'BEV_Temperature_Feature_2026-10-16/00_READ_FIRST.txt'},
 {'id':'a123','name':'A123 laboratory model & coupling','period':'16 Oct','category':'Lab tested · external surrogate','status':'limited',
  'question':'Can a fitted cell-surface model predict separate laboratory records and be driven by a native duty-cycle surrogate?',
  'completed':'Fit periodic-pulse data; test two same-cell UDDS records using measured current and air; reuse RR03 events externally.',
  'result':'Held-out RMSE 0.109 / 0.117°C. Coupled surrogate final temperatures 25.070 / 35.070 / 40.070°C.',
  'assumptions':'2.5 Ah A123 cell, 85% drivetrain efficiency, 20 kW auxiliary load; 354 kWh nominal pack for equivalent C-rate only.',
  'limit':'Not Z50 cells/cooling. Coupled ~0.070°C rise is below held-out model error. Current is event averaged; unit confirmation pending.',
  'source':'APCOM_Coupled_Thermal_2026-10-16/00_START_HERE.txt'},
 {'id':'228','name':'228 Ah formula versus constant temperature','period':'16 Oct · latest','category':'Laboratory test · mixed result','status':'limited',
  'question':'Does current-driven temperature prediction beat holding the first temperature constant?',
  'completed':'Seven real HPPC records; 159.073 h; six-cell holdouts plus B1 later-record check; all 189 metric rows verified.',
  'result':'Six-cell RMSE 0.274 → 0.187°C (31.8% lower). Later B1 0.224 → 0.292°C (30.7% higher). 5 wins, 4 ties, 9 losses.',
  'assumptions':'Nominal ambient fixed at 25°C; three unmapped temperature-channel labels; seven of 55 HPPC records selected before fitting.',
  'limit':'Weak parameter identification and uneven transfer. No mine-duty, Z50 pack or early-warning validation.',
  'source':'APCOM_228Ah_Thermal_Test_2026-10-16/results/summary.json'},
 {'id':'research','name':'Literature, paper & independent QA','period':'9–15 Oct','category':'Draft & evidence reviewed','status':'limited',
  'question':'What is established, what belongs in APCOM, and what must be reserved for the journal?',
  'completed':'25-reference matrix, 12-row assumption register, 6 incident rows, 15-page plan, 9-page template-conforming draft and QA fixes.',
  'result':'18 manuscript references mapped to the evidence matrix; documented prior art includes HAULSIM/VentSim fire-risk work.',
  'assumptions':'Thirty-six operating scenarios remain proposed. Earlier illustrative equations are not empirical validation.',
  'limit':'New experiments are separate, not merged into the draft. Supervisor approval and submission are not recorded.',
  'source':'APCOM_Research_2026-10-15/07_Verification_and_Status.json'},
 {'id':'visuals','name':'Videos, vehicles & professor materials','period':'9 Oct onward','category':'Created · visual boundaries labeled','status':'limited',
  'question':'How can the operating concept be shown clearly to professors?',
  'completed':'Native HAULSIM recordings, separate detailed truck render/assets, eight-slide discussion and 15-slide approval decks.',
  'result':'Native clips show the software. The detailed vehicle is an approximate MT42-family illustration outside HAULSIM.',
  'assumptions':'Generic native truck graphics; schematic underground context.',
  'limit':'No custom Z50 graphic installed; no actual mine footage created. Older decks do not contain the latest 228 Ah results.',
  'source':'BEV_Professor_Materials/START_HERE.txt'}]

datasets=[
 {'name':'New Afton operator / historical Z50 OEM','kind':'Public summaries & specification','status':'Case context only','url':'https://www.mining.sandvik/globalassets/products/underground-loaders-and-trucks/pdf/artisan-z50-specification-sheet-english.pdf','finding':'Supports historical nominal inputs and route context; no measured current-temperature time series.'},
 {'name':'CanmetMINING MacLean cassette-truck study','kind':'Published field energy benchmark','status':'Not thermal validation','url':'https://doi.org/10.1080/19236026.2023.2266351','finding':'Battery temperature explicitly not measured; 92.5 kWh vehicle differs from Z50.'},
 {'name':'Shen abuse-test candidate','kind':'Laboratory abuse data','status':'Admission unresolved','url':'https://doi.org/10.17632/8zjttd77my.1','finding':'Timestamp, missing-temperature, channel-definition and onset-label gaps; no detector validated.'},
 {'name':'A123 2.5 Ah LFP','kind':'Laboratory current, surface & air','status':'Downloaded & tested','url':'https://doi.org/10.17632/p8kf893yv3.1','finding':'Same-cell calibration/holdout evaluation; CC BY 4.0. Not an underground pack.'},
 {'name':'228 Ah mining-oriented LFP cells','kind':'Laboratory calendar-aging / HPPC','status':'Downloaded & tested, mixed','url':'https://doi.org/10.17632/dhr726bk6z.2','finding':'55 current/temperature HPPC records; seven tested. Nominal 25°C test ambient; probe mapping unresolved. CC BY 4.0.'},
 {'name':'Wang et al. mining-vehicle study','kind':'Closed-road vehicle logs described','status':'Author-request lead','url':'https://doi.org/10.3390/en17235920','finding':'Current/voltage/temperature Excel logs described; no open download found; not established underground operation.'},
 {'name':'TUM passenger-EV sample CUP3','kind':'Road-EV measurements','status':'Inspected sample not suitable','url':'https://github.com/TUMFTM/electric-vehicle-uds-dataset','finding':'Battery temperature present; no identified chronological traction-current channel in the inspected sample; CC BY-NC 4.0.'},
 {'name':'Downloads/Dataset teaching files','kind':'Open Cut HAULSIM geometry','status':'Not battery telemetry','url':'','finding':'Terrain, road/location data and teaching model; no synchronized pack current and temperature.'}]

decisions=[
 {'priority':1,'action':'Agree the APCOM claim with supervisors','why':'Accepted AI early-warning title exceeds the completed normal-temperature evidence. Preserve journal novelty.','status':'Pending decision'},
 {'priority':2,'action':'Obtain identified ambient, cooling and probe data','why':'228 Ah transfer is uneven; nominal ambient and unmapped channels limit interpretation.','status':'Missing measurement metadata'},
 {'priority':3,'action':'Obtain vehicle-specific matched haul-cycle telemetry','why':'Neither A123 nor 228 Ah coefficients establish Z50 pack behavior; validate electrical and thermal links separately.','status':'Data not verified available'},
 {'priority':4,'action':'Close energy/SOC and export-unit questions','why':'Generic native energy/SOC is unreconciled; RR03 wheel-energy units are inferred by physics checks.','status':'Unresolved'},
 {'priority':5,'action':'Use fault labels before claiming detection','why':'No completed trained detector, event-onset benchmark, false-alarm result or warning lead time exists.','status':'Not executed'},
 {'priority':6,'action':'Integrate approved results and refresh documents','why':'The nine-page draft and older slides do not incorporate all later experiments. Rerender and re-QA after edits.','status':'Not yet integrated'}]

files=[
 ('APCOM_Research_2026-10-15/01_New_Afton_Research_and_Modelling_Plan.pdf','15-page research plan','research'),
 ('APCOM_Research_2026-10-15/02_APCOM_Methods_and_Preliminary_Calculations_Draft.pdf','9-page manuscript draft; earlier scope','research'),
 ('APCOM_Research_2026-10-15/03_Literature_Evidence_Matrix.csv','25-reference evidence matrix','research'),
 ('APCOM_Research_2026-10-15/04_Parameter_and_Assumption_Register.csv','12-row input register','research'),
 ('APCOM_Research_2026-10-15/05_Reported_Battery_Fire_Cases.csv','6 incident rows, includes grouped events','research'),
 ('APCOM_Research_2026-10-15/06_Proposed_Operating_Scenarios.csv','36 proposed cases, not executed','research'),
 ('APCOM_Research_2026-10-15/07_Verification_and_Status.json','Existing document/calculation verification','research'),
 ('QA_Independent_2026-10-15/QA_Report.md','Independent QA scope, fixes and withdrawn findings','research'),
 ('APCOM_Research_2026-10-15/calculations/calculation_audit.json','Analytical force and thermal checks','research'),
 ('HAULSIM_Road_Surface_2026-10-15/01_Experiment_Results.txt','Native road-condition results and limits','road'),
 ('HAULSIM_Road_Surface_2026-10-15/study_manifest.json','Executed cases and common assumptions','road'),
 ('HAULSIM_Road_Surface_2026-10-15/results/scenario_comparison.csv','Three reconciled native results','road'),
 ('APCOM_Coupled_Thermal_2026-10-16/01_HAULSIM_Thermal_Methods_Brief.pdf','A123 laboratory model and external coupling brief','a123'),
 ('APCOM_Coupled_Thermal_2026-10-16/results/record_metrics.json','A123 held-out predictions and baseline metrics','a123'),
 ('APCOM_Coupled_Thermal_2026-10-16/results/frozen_cell_model.json','A123-only fitted coefficients','a123'),
 ('APCOM_Coupled_Thermal_2026-10-16/results/coupling_audit.json','External native-event coupling assumptions','a123'),
 ('APCOM_Battery_Data_Search_2026-10-16/03_228Ah_Download_and_Validation_Assessment.txt','Confirmed 228 Ah channel audit; predates fitting','228'),
 ('APCOM_228Ah_Thermal_Test_2026-10-16/01_Thermal_Formula_Results.pdf','Latest four-page temperature experiment briefing','228'),
 ('APCOM_228Ah_Thermal_Test_2026-10-16/02_APCOM_Text_for_Supervisor_Review.txt','Latest proposed paper wording, not merged','228'),
 ('APCOM_228Ah_Thermal_Test_2026-10-16/00_ANALYSIS_PROTOCOL.txt','Pre-fitting evaluation protocol','228'),
 ('APCOM_228Ah_Thermal_Test_2026-10-16/results/summary.json','Latest aggregate thermal results','228'),
 ('APCOM_228Ah_Thermal_Test_2026-10-16/results/metrics.csv','All 189 evaluated metric rows','228'),
 ('APCOM_228Ah_Thermal_Test_2026-10-16/results/frozen_parameters.json','All 42 fitted formula/cooling models','228'),
 ('APCOM_228Ah_Thermal_Test_2026-10-16/results/verification.json','Numerical check outcomes','228'),
 ('APCOM_228Ah_Thermal_Test_2026-10-16/source_audit.json','Seven raw-clock and channel alignments','228'),
 ('BEV_Temperature_Feature_2026-10-16/00_READ_FIRST.txt','Assumed bulk-temperature demonstration','bulk'),
 ('BEV_Temperature_Feature_2026-10-16/temperature_cases.csv','Illustrative ambient sensitivity endpoints','bulk'),
 ('BEV_HAULSIM_Walkthrough_2026-10-16/Walkthrough.txt','Native generic-model walkthrough and caveats','generic'),
 ('BEV_HAULSIM_Walkthrough_2026-10-16/results/summary.json','Two-hour charging-demo outputs','generic'),
 ('results/haulsim/scenario_summary.csv','Legacy S1–S4 operational outputs; energy unresolved','generic'),
 ('New_Afton_Professor_Case/START_HERE.txt','Current case status, supersedes older brief pending wording','newafton'),
 ('New_Afton_Professor_Case/07_Verified_Native_Audit/audit_summary.json','Earlier verified native Route A run','newafton'),
 ('BEV_Professor_Materials/START_HERE.txt','Separated visual, model and presentation materials','visuals'),
 ('APCOM_Approval_2026-10-09/00_START_HERE.txt','Earlier approval-meeting package status','visuals'),
 ('APCOM_Approval_2026-10-09/01_APCOM_Professor_Approval_v2.pptx','15-slide earlier approval deck, not updated with latest test','visuals'),
 ('BEV_Professor_Materials/04_Presentation/Underground_BEV_Professor_Discussion.pptx','8-slide earlier professor discussion','visuals'),
 ('New_Afton_Professor_Case/08_Native_Video/New_Afton_HAULSIM_Demo.mp4','Edited native New Afton software recording','visuals'),
 ('New_Afton_Professor_Case/08_Native_Video/New_Afton_HAULSIM_Native_UI.mp4','Native New Afton UI recording','visuals'),
 ('BEV_Professor_Materials/03_Videos/BEV_Truck_Demo.mp4','Separate MT42-family illustration; not native HAULSIM','visuals'),
 ('BEV_Professor_Materials/03_Videos/HAULSIM_Native_Recording.mp4','Earlier generic native HAULSIM walkthrough','visuals'),
 ('BEV_HAULSIM_Walkthrough_2026-10-16/BEV_Walkthrough.hsm','Generic walkthrough project; pair with .hsmdb','generic'),
 ('BEV_HAULSIM_Walkthrough_2026-10-16/BEV_Walkthrough.hsmdb','Generic walkthrough native database','generic'),
 ('New_Afton_Professor_Case/02_Native_HAULSIM/New_Afton_Route_A.hsm','Historical A native project','newafton'),
 ('New_Afton_Professor_Case/02_Native_HAULSIM/New_Afton_Route_B.hsm','Historical B project, native run pending','newafton')]

catalog=[]
for rel,role,stream in files:
    p=ROOT/rel;assert p.is_file(),rel
    include=p.suffix.lower() in {'.pdf','.txt','.json','.csv','.md'} and p.stat().st_size<8_000_000
    packaged='evidence/'+rel if include else None
    digest=hashlib.sha256(p.read_bytes()).hexdigest() if include else None
    if include:
        dest=OUT/packaged;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
    catalog.append({'relative_path':rel,'absolute_path':p.as_posix(),'role':role,'workstream':stream,'bytes':p.stat().st_size,'included_in_bundle':include,'bundle_path':packaged,'sha256':digest})
for folder in ['APCOM_228Ah_Thermal_Test_2026-10-16/code','APCOM_Coupled_Thermal_2026-10-16/code']:
    for p in (ROOT/folder).glob('*.py'):
        dest=OUT/'evidence'/folder/p.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)

data={'snapshot':'2026-10-16','workspace':ROOT.as_posix(),'coverage':'Summary of existing local artifacts and recorded work; no new simulation or scientific fit in this handoff pass.',
      'conference':{'title':'Early Detection of Thermal Runaway in Underground Mining BEVs Using an AI-Based Sensor Fusion Framework','abstract_id':44,'review_due':'2026-10-30','pages':'8–10','final_and_registration_due':'2027-03-01','conference_dates':'2027-05-02 through 2027-05-05','location':'Montréal, Québec','source':'Acceptance email supplied by user; not newly checked'},
      'workstreams':streams,'datasets':datasets,'decisions':decisions,
      'road_results':read_csv('HAULSIM_Road_Surface_2026-10-15/results/scenario_comparison.csv'),
      'latest_228_summary':read_json('APCOM_228Ah_Thermal_Test_2026-10-16/results/summary.json'),
      'latest_228_metrics':read_json('APCOM_228Ah_Thermal_Test_2026-10-16/results/metrics.json'),
      'a123_metrics':read_json('APCOM_Coupled_Thermal_2026-10-16/results/record_metrics.json'),
      'a123_coupling':read_json('APCOM_Coupled_Thermal_2026-10-16/results/coupling_audit.json'),
      'literature':read_csv('APCOM_Research_2026-10-15/03_Literature_Evidence_Matrix.csv'),
      'incidents':read_csv('APCOM_Research_2026-10-15/05_Reported_Battery_Fire_Cases.csv'),
      'parameters':read_csv('APCOM_Research_2026-10-15/04_Parameter_and_Assumption_Register.csv'),
      'legacy_runs':read_csv('results/haulsim/scenario_summary.csv'),'files':catalog,
      'boundaries':['No independently validated Z50 pack-temperature model','No trained or validated AI detector','No thermal-runaway warning lead time','No fire probability from the road study','No custom Z50 animation installed','No recorded final supervisor approval or conference submission','No email or Claude message sent during this handoff'],
      'superseded':[{'older':'228 Ah archive/channels unverified','current':'Downloaded, hashed, channels confirmed; seven records tested'}, {'older':'Route A native execution pending in an earlier brief','current':'Earlier 45 t native A audit confirms 225 t in two hours'}, {'older':'All thermal work is assumed constant heat','current':'Later A123 and 228 Ah fits use measured laboratory data; mine/pack validation remains open'}, {'older':'36 proposed scenarios might look like executed results','current':'They remain proposed; only separately documented experiments count as executed'}]}
(OUT/'04_EVIDENCE_MAP.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
with (OUT/'05_FILE_CATALOG.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(catalog[0]));w.writeheader();w.writerows(catalog)

figures={
 'comparison':'APCOM_228Ah_Thermal_Test_2026-10-16/figures/01_Held_Out_Comparison.png',
 'chronological':'APCOM_228Ah_Thermal_Test_2026-10-16/figures/02_Chronological_Holdout.png',
 'channels':'APCOM_228Ah_Thermal_Test_2026-10-16/figures/03_All_Channel_Differences.png',
 'a123':'APCOM_Coupled_Thermal_2026-10-16/figures/01_laboratory_validation.png',
 'coupling':'APCOM_Coupled_Thermal_2026-10-16/figures/02_native_cycle_and_temperature.png',
 'bulk':'BEV_Temperature_Feature_2026-10-16/temperature_feature.png',
 'truck':'BEV_Professor_Materials/02_BEV_Truck/Truck_Exterior.png',
 'battery':'BEV_HAULSIM_Walkthrough_2026-10-16/Battery_Settings.png'}
data_images={}
for key,rel in figures.items():
    blob=(ROOT/rel).read_bytes();data_images[key]='data:image/png;base64,'+base64.b64encode(blob).decode()
    dest=OUT/'figures'/f'{key}.png';dest.parent.mkdir(exist_ok=True);dest.write_bytes(blob)
template=(OUT/'dashboard_template.html').read_text(encoding='utf-8')
full=template.replace('__PROJECT_DATA__',json.dumps(data,ensure_ascii=False).replace('</','<\/'))
full=full.replace('__IMAGE_DATA__',json.dumps(data_images))
full=full.replace('__HANDOFF_TEXT__',html.escape((OUT/'01_FULL_HANDOFF_FOR_CLAUDE.txt').read_text(encoding='utf-8')))
full=full.replace('__CLAUDE_PROMPT__',html.escape((OUT/'03_CLAUDE_START_PROMPT.txt').read_text(encoding='utf-8')))
(OUT/'02_VISUAL_OVERVIEW.html').write_text(full,encoding='utf-8')
(OUT/'00_READ_FIRST.txt').write_text('''CLAUDE HANDOFF — 16 OCTOBER 2026

1. Open 02_VISUAL_OVERVIEW.html in a browser for the interactive project overview.
   It works offline: data and figures are embedded. It is not a live HAULSIM model.
2. Upload 01_FULL_HANDOFF_FOR_CLAUDE.txt and 04_EVIDENCE_MAP.json to Claude.
3. Paste 03_CLAUDE_START_PROMPT.txt to request a visual artifact / research review.
4. Add selected PDFs or CSVs from evidence/ if Claude needs the underlying details.

The ZIP is a transfer bundle. If Claude will not accept ZIP, extract and upload
individual files. Large raw data, native databases, slide decks and videos are
not bundled; their verified locations are in 05_FILE_CATALOG.csv. The catalog
distinguishes included files from references that only exist in the workspace.
Some copied analysis scripts require original data and task-local packages;
this is an evidence handoff, not a complete portable execution environment.

The full text covers all documented workstreams, experimental results, formulas,
source limitations, literature, incident cases, visual materials, QA, missing
data and recommended supervisor decisions. Selected evidence was copied without
editing its content. Dates and older status statements belong to their original
packages; the full handoff explains what was superseded.

No files were uploaded or messages sent to Claude. No new simulation was run.
''',encoding='utf-8')
print(json.dumps({'workstreams':len(streams),'sources':len(data['literature']),'catalog_files':len(catalog),'included_evidence':sum(x['included_in_bundle'] for x in catalog),'dashboard_bytes':len(full.encode('utf-8'))},indent=2))
