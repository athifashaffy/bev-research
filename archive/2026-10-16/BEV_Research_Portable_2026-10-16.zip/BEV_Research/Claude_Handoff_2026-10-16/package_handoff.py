from pathlib import Path
import csv,hashlib,json,zipfile
OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
data=json.loads((OUT/'04_EVIDENCE_MAP.json').read_text(encoding='utf-8'))
for row in data['files']:
    assert Path(row['absolute_path']).is_file(),row['absolute_path']
    if row['included_in_bundle']:
        source=Path(row['absolute_path']);dest=OUT/row['bundle_path']
        assert source.read_bytes()==dest.read_bytes(),row['bundle_path']
        assert hashlib.sha256(dest.read_bytes()).hexdigest()==row['sha256']
assert len(data['literature'])==25
assert len(data['incidents'])==6
assert len(data['workstreams'])==8
assert len(data['latest_228_metrics'])==189
with (OUT/'evidence/APCOM_Research_2026-10-15/06_Proposed_Operating_Scenarios.csv').open(encoding='utf-8-sig') as f:
    scenarios=list(csv.DictReader(f))
assert len(scenarios)==36
assert all(r['Status']=='PROPOSED - not executed' for r in scenarios)
html=(OUT/'02_VISUAL_OVERVIEW.html').read_text(encoding='utf-8')
assert all(token not in html for token in ['__PROJECT_DATA__','__IMAGE_DATA__','__HANDOFF_TEXT__','__CLAUDE_PROMPT__'])
assert json.loads((OUT/'06_VISUAL_VERIFICATION.json').read_text())['passed']
selected=[p for p in OUT.iterdir() if p.is_file() and p.name[:2] in {'00','01','02','03','04','05','06'}]
selected+=sorted((OUT/'evidence').rglob('*'))+sorted((OUT/'figures').glob('*.png'))
selected=[p for p in selected if p.is_file()]
manifest={'snapshot':'2026-10-16','scope':'Evidence and visual handoff, not a complete reproducible environment',
          'checks':{'catalog_paths_exist':True,'included_source_copies_byte_identical':True,'native_road_cases_executed':3,
                    'proposed_matrix_cases_remain_proposed':36,'visual_interactions_checked':True,'full_handoff_word_count':len((OUT/'01_FULL_HANDOFF_FOR_CLAUDE.txt').read_text(encoding='utf-8').split())},
          'files':[{'path':p.relative_to(OUT).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in selected]}
mp=OUT/'07_BUNDLE_MANIFEST.json';mp.write_text(json.dumps(manifest,indent=2),encoding='utf-8');selected.append(mp)
target=ROOT/'Claude_Handoff_2026-10-16.zip'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in selected:z.write(p,OUT.name+'/'+p.relative_to(OUT).as_posix())
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(selected)
print(json.dumps({'archive':str(target),'bytes':target.stat().st_size,'files':len(selected),
                  'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'checks':manifest['checks']},indent=2))
