from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'research/haulsim_detail/tools'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
COLORS={'constant_initial':'#9b5b30','formula':'#007c83','cooling_only':'#8494a8'}
LABELS={'constant_initial':'Hold initial temperature','formula':'Current + cooling formula','cooling_only':'Cooling only'}
rows=json.loads((OUT/'results/metrics.json').read_text())
summary=json.loads((OUT/'results/summary.json').read_text())
(OUT/'figures').mkdir(exist_ok=True)

def group_rmse(rows,**criteria):
    q=[r for r in rows if all(r[k]==v for k,v in criteria.items())]
    return np.sqrt(np.mean([r['RMSE_C']**2 for r in q]))

fig,axes=plt.subplots(1,2,figsize=(12,5.6),sharey=True)
for ax,region,title in zip(axes,['all','active'],['Whole test, including rests','While current is flowing (|I| > 1 A)']):
    x=np.arange(6);width=.25
    for j,kind in enumerate(['constant_initial','formula','cooling_only']):
        values=[group_rmse(rows,test_record=f'B{k}_0D',region=region,model=kind) for k in range(1,7)]
        bars=ax.bar(x+(j-1)*width,values,width,color=COLORS[kind],label=LABELS[kind])
    ax.set_xticks(x,[f'B{k}' for k in range(1,7)])
    ax.set_xlabel('Held-out cell (all three temperature channels)')
    rb=group_rmse(rows,experiment='leave_one_cell_out',region=region,model='constant_initial')
    rf=group_rmse(rows,experiment='leave_one_cell_out',region=region,model='formula')
    ax.set_title(f'{title}\nCombined RMSE: constant {rb:.3f}°C | formula {rf:.3f}°C',fontsize=10,pad=14)
    ax.grid(axis='y',alpha=.17);ax.set_axisbelow(True)
axes[0].set_ylabel('Prediction error: RMSE (°C), lower is better')
axes[0].set_ylim(0,max(ax.get_ylim()[1] for ax in axes)*1.16)
handles,labels=axes[0].get_legend_handles_labels()
fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,.87),ncol=3,frameon=False)
fig.suptitle('Does the temperature formula beat a constant prediction?',x=.06,ha='left',fontsize=17,fontweight='bold')
fig.text(.06,.91,'228 Ah LFP laboratory cells • six-fold leave-one-cell-out evaluation • nominal 25°C ambient',fontsize=10,color='#405168')
fig.text(.06,.025,'Each bar combines three channel MSEs before taking the square root. Channels are correlated; six cells are the test units.',fontsize=9,color='#405168')
fig.tight_layout(rect=[0,.06,1,.78])
for ext in ['png','svg']:fig.savefig(OUT/'figures'/f'01_Held_Out_Comparison.{ext}',dpi=180)
plt.close(fig)

# Show all three channels for the predetermined chronological check.
d=dict(np.load(OUT/'predictions/B1_7D.npz'));t=d['time_s']/3600
fig,axes=plt.subplots(4,1,figsize=(11.5,9),sharex=True,gridspec_kw={'height_ratios':[.8,1,1,1]})
axes[0].plot(t,d['current_A'],color='#37465b',lw=.6)
axes[0].set_ylabel('Current (A)')
for ch,ax in enumerate(axes[1:],1):
    y=d['measured_C'][:,ch-1]
    ax.plot(t,y,color='#9da8b6',lw=.35,alpha=.65,label='Measured, original samples')
    ax.plot(t,d[f'constant_initial_T{ch}_C'],color=COLORS['constant_initial'],lw=1.5,ls='--',label=LABELS['constant_initial'])
    ax.plot(t,d[f'formula_T{ch}_C'],color=COLORS['formula'],lw=1.3,label=LABELS['formula'])
    ax.set_ylabel(f'T{ch} (°C)')
    f=next(r for r in rows if r['test_record']=='B1_7D' and r['channel']==ch and r['model']=='formula' and r['region']=='all')
    b=next(r for r in rows if r['test_record']=='B1_7D' and r['channel']==ch and r['model']=='constant_initial' and r['region']=='all')
    ax.text(.99,.92,f"RMSE: formula {f['RMSE_C']:.3f}°C | constant {b['RMSE_C']:.3f}°C",transform=ax.transAxes,ha='right',va='top',fontsize=9,bbox={'facecolor':'white','alpha':.85,'edgecolor':'none'})
for ax in axes:ax.grid(axis='y',alpha=.2)
axes[-1].set_xlabel('Elapsed time in held-out test (hours; original absolute timestamps)')
fig.suptitle('A separate test on the same cell',x=.085,ha='left',fontsize=17,fontweight='bold')
fig.text(.085,.94,'Calibrate on B1 at 0D; predict B1 at 7D without refitting. Initial temperature is supplied to both models.',fontsize=10,color='#405168')
handles,labels=axes[1].get_legend_handles_labels()
fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.53,.925),ncol=3,frameon=False,fontsize=9)
fig.text(.085,.02,'T1/T2/T3 probe locations are unconfirmed. "7D" is a nominal aging checkpoint, not seven elapsed calendar days.',fontsize=9,color='#405168')
fig.tight_layout(rect=[.01,.04,1,.88])
for ext in ['png','svg']:fig.savefig(OUT/'figures'/f'02_Chronological_Holdout.{ext}',dpi=180)
plt.close(fig)

# Report every channel rather than selecting the most favorable sensor.
delta=np.zeros((6,3))
for cell in range(1,7):
    for ch in range(1,4):
        f=next(r for r in rows if r['test_record']==f'B{cell}_0D' and r['channel']==ch and r['model']=='formula' and r['region']=='all')
        b=next(r for r in rows if r['test_record']==f'B{cell}_0D' and r['channel']==ch and r['model']=='constant_initial' and r['region']=='all')
        delta[cell-1,ch-1]=b['RMSE_C']-f['RMSE_C']
fig,ax=plt.subplots(figsize=(7.4,5.6));lim=max(abs(delta.min()),abs(delta.max()),.01)
im=ax.imshow(delta,cmap='BrBG',vmin=-lim,vmax=lim,aspect='auto')
for r in range(6):
    for c in range(3):ax.text(c,r,f'{delta[r,c]:+.3f}',ha='center',va='center',fontsize=12,color='white' if abs(delta[r,c])>.6*lim else '#162332')
ax.set_xticks(range(3),['Temperature 1','Temperature 2','Temperature 3']);ax.set_yticks(range(6),[f'B{k}' for k in range(1,7)])
fig.colorbar(im,ax=ax,label='Constant RMSE minus formula RMSE (°C)')
ax.set_title('Every held-out channel\nPositive = formula better; negative = constant better',loc='left',fontsize=13,pad=15)
fig.text(.13,.02,'Whole-record RMSE, nominal 25°C ambient. No channel selected after viewing results.',fontsize=9)
fig.tight_layout(rect=[0,.04,1,1])
for ext in ['png','svg']:fig.savefig(OUT/'figures'/f'03_All_Channel_Differences.{ext}',dpi=180)
print('Three figures exported as PNG and SVG.')
