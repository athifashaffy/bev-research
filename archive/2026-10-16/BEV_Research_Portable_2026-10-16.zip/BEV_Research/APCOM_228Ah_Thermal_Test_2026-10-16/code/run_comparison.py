"""Predetermined cross-cell and chronological thermal-model evaluation."""
from pathlib import Path
import sys,json,hashlib,csv,functools,os
os.environ['OPENBLAS_NUM_THREADS']='1'
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'research/coupled_thermal_2026_10_16/tools'))
import numpy as np
from scipy.optimize import minimize_scalar
AIR=25.0

def basis(t,i,b):
    dt=np.diff(t)
    decay=np.exp(-b*dt)
    gain=dt if b==0 else -np.expm1(-b*dt)/b
    forcing=gain*i[:-1]**2
    h=np.empty(len(t));h[0]=0
    for k in range(len(dt)):h[k+1]=decay[k]*h[k]+forcing[k]
    return np.exp(-b*t),h

def predict(t,i,initial,a,b,air=AIR):
    decay,h=basis(t,i,b)
    return air+(initial-air)*decay+a*h

def self_check():
    t=np.array([0.,.01,.5,1.,4.,40.,1000.]);i=np.full(len(t),220.)
    a=2e-7;b=.001;initial=23.
    exact=AIR+(initial-AIR)*np.exp(-b*t)+(a*i[0]**2/b)*(-np.expm1(-b*t))
    assert np.allclose(predict(t,i,initial,a,b),exact,rtol=1e-12,atol=1e-12)
    assert np.allclose(predict(t,i,initial,a,0),initial+a*i[0]**2*t,rtol=1e-12)
    assert np.allclose(predict(t,i,initial,0,b),AIR+(initial-AIR)*np.exp(-b*t),atol=1e-12)
    assert np.array_equal(predict(t,i,initial,0,0),np.full(len(t),initial))
    return {'constant_current_analytic_solution':True,'zero_cooling_limit':True,
            'cooling_only_analytic_solution':True,'constant_baseline_nested':True}

def load_records():
    records={}
    for p in sorted((OUT/'aligned').glob('*.npz')):
        d=dict(np.load(p));t=d['time_s'];dt=np.diff(t)
        assert (dt>0).all()
        d['weight']=dt/dt.sum()
        active=np.abs(d['current_A'][:-1])>1
        last_active_end=np.maximum.accumulate(np.where(active,t[1:],-np.inf))
        recovery=(t[:-1]-last_active_end)<=300
        d['masks']={'all':np.ones(len(dt),bool),'active':active,'active_plus_300s':recovery}
        records[p.stem]=d
    assert set(records)=={'B1_0D','B1_7D','B2_0D','B3_0D','B4_0D','B5_0D','B6_0D'}
    return records

def metric(d,p,y,mask):
    e=(p-y)[1:][mask];w=np.diff(d['time_s'])[mask]
    return {'RMSE_C':float(np.sqrt(np.average(e*e,weights=w))),
            'MAE_C':float(np.average(abs(e),weights=w)),
            'bias_C':float(np.average(e,weights=w)),
            'max_absolute_error_C':float(np.max(abs(e))),
            'duration_s':float(w.sum()),'interval_count':int(mask.sum())}

def fit_all(records):
    grid=np.r_[0.,np.logspace(-7,0,61)]
    @functools.lru_cache(maxsize=None)
    def stats(b):
        out={}
        for key,d in records.items():
            if key=='B1_7D':continue  # Chronological holdout is never used for fitting.
            decay,h=basis(d['time_s'],d['current_A'],b)
            y=d['temperature_C'];base=AIR+(y[0]-AIR)[None,:]*decay[:,None]
            residual=(y-base)[1:];w=d['weight'];hh=h[1:]
            out[key]=(float(np.dot(w,hh*hh)),
                      np.sum(w[:,None]*hh[:,None]*residual,axis=0),
                      np.sum(w[:,None]*residual*residual,axis=0))
        return out
    for idx,b in enumerate(grid):
        stats(float(b))
        if idx%10==0:print('Profile grid',idx+1,'/',len(grid),flush=True)
    models=[];profiles=[]
    ids=[f'B{k}_0D' for k in range(1,7)]
    folds=[('leave_one_cell_out',test,[k for k in ids if k!=test]) for test in ids]
    folds.append(('chronological','B1_7D',['B1_0D']))
    for experiment,test,train in folds:
        assert test not in train
        for channel in range(3):
            for kind in ['formula','cooling_only']:
                def evaluate(b):
                    ss=stats(float(b));hh=np.mean([ss[k][0] for k in train])
                    hy=np.mean([ss[k][1][channel] for k in train]);yy=np.mean([ss[k][2][channel] for k in train])
                    a=max(0.,hy/hh) if kind=='formula' and hh>0 else 0.
                    loss=max(0.,float(yy-2*a*hy+a*a*hh))
                    return loss,a
                losses=np.array([evaluate(float(b))[0] for b in grid])
                best=int(np.argmin(losses));candidates=[(losses[best],float(grid[best]))]
                for k in range(1,len(grid)):
                    left=losses[k-1];right=losses[k+1] if k+1<len(grid) else np.inf
                    strict=(losses[k]<left-1e-12 or (np.isfinite(right) and losses[k]<right-1e-12))
                    if losses[k]<=left and losses[k]<=right and strict:
                        low=np.log(grid[max(1,k-1)]);high=np.log(grid[min(len(grid)-1,k+1)])
                        if low<high:
                            sol=minimize_scalar(lambda x:evaluate(float(np.exp(x)))[0],bounds=(low,high),method='bounded',options={'xatol':1e-5})
                            assert sol.success
                            candidates.append((float(sol.fun),float(np.exp(sol.x))))
                loss,b=min(candidates);loss,a=evaluate(b)
                baseline_mse=np.mean([np.dot(records[k]['weight'],(records[k]['temperature_C'][1:,channel]-records[k]['temperature_C'][0,channel])**2) for k in train])
                assert loss<=baseline_mse+1e-10,'Fit worse than included constant solution'
                row={'experiment':experiment,'test_record':test,'train_records':train,
                     'channel':channel+1,'model':kind,'a_K_per_A2_s':float(a),'b_per_s':float(b),
                     'tau_s':float(1/b) if b>0 else None,'training_RMSE_C':float(np.sqrt(loss)),
                     'training_constant_RMSE_C':float(np.sqrt(baseline_mse)),
                     'a_is_zero_boundary':bool(a==0),'b_is_zero_boundary':bool(b==0),
                     'b_at_grid_boundary':bool(b>0 and (b<=1.001e-7 or b>=.999)),
                     'ambient_C':AIR}
                models.append(row)
                profiles.append({**{k:row[k] for k in ['experiment','test_record','channel','model']},'b_grid_per_s':grid.tolist(),'training_MSE_C2':losses.tolist()})
        print('Fitted and froze',experiment,test,flush=True)
    (OUT/'results/frozen_parameters.json').write_text(json.dumps(models,indent=2),encoding='utf-8')
    (OUT/'results/training_profiles.json').write_text(json.dumps(profiles,indent=2),encoding='utf-8')
    return models

def evaluate_all(records,models):
    rows=[]
    for test,d in records.items():
        experiment='chronological' if test=='B1_7D' else 'leave_one_cell_out'
        prediction={'time_s':d['time_s'],'current_A':d['current_A'],'measured_C':d['temperature_C']}
        for channel in range(3):
            y=d['temperature_C'][:,channel]
            for kind in ['constant_initial','cooling_only','formula']:
                if kind=='constant_initial':p=np.full(len(y),y[0])
                else:
                    model=next(m for m in models if m['test_record']==test and m['channel']==channel+1 and m['model']==kind)
                    p=predict(d['time_s'],d['current_A'],y[0],model['a_K_per_A2_s'],model['b_per_s'])
                prediction[f'{kind}_T{channel+1}_C']=p
                for region,mask in d['masks'].items():
                    rows.append({'experiment':experiment,'test_record':test,'channel':channel+1,
                                 'model':kind,'region':region,'initial_temperature_C':float(y[0]),
                                 'measured_range_C':float(np.ptp(y)),**metric(d,p,y,mask)})
        np.savez_compressed(OUT/'predictions'/f'{test}.npz',**prediction)
    (OUT/'results/metrics.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    with (OUT/'results/metrics.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    aggregates=[]
    for experiment in ['leave_one_cell_out','chronological']:
        for region in ['all','active','active_plus_300s']:
            for kind in ['constant_initial','cooling_only','formula']:
                subset=[r for r in rows if r['experiment']==experiment and r['region']==region and r['model']==kind]
                aggregates.append({'experiment':experiment,'region':region,'model':kind,
                                   'macro_RMSE_C':float(np.sqrt(np.mean([r['RMSE_C']**2 for r in subset]))),
                                   'macro_MAE_C':float(np.mean([r['MAE_C'] for r in subset])),
                                   'channel_record_count':len(subset)})
    wins=[]
    for experiment in ['leave_one_cell_out','chronological']:
        for region in ['all','active','active_plus_300s']:
            formula=[r for r in rows if r['experiment']==experiment and r['region']==region and r['model']=='formula']
            differences=[]
            for r in formula:
                base=next(x for x in rows if x['experiment']==experiment and x['region']==region and x['model']=='constant_initial' and x['channel']==r['channel'] and x['test_record']==r['test_record'])
                differences.append(base['RMSE_C']-r['RMSE_C'])
            wins.append({'experiment':experiment,'region':region,'improved':sum(v>1e-10 for v in differences),'tied':sum(abs(v)<=1e-10 for v in differences),'worse':sum(v< -1e-10 for v in differences)})
    summary={'source_doi':'10.17632/dhr726bk6z.2','formula':'dT/dt = a I^2 - b (T - 25 C)',
             'comparison':'T(t)=T(0)','primary_split':'six-fold leave-one-cell-out at checkpoint 0D',
             'secondary_split':'B1 0D calibration to B1 7D holdout','aggregates':aggregates,
             'wins_against_constant':wins,'fitted_parameter_count':len(models),
             'formula_a_zero_count':sum(m['a_is_zero_boundary'] for m in models if m['model']=='formula'),
             'formula_b_zero_count':sum(m['b_is_zero_boundary'] for m in models if m['model']=='formula'),
             'protocol_sha256':hashlib.sha256((OUT/'00_ANALYSIS_PROTOCOL.txt').read_bytes()).hexdigest()}
    (OUT/'results/summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':
    for name in ['results','predictions']:(OUT/name).mkdir(exist_ok=True)
    checks=self_check()
    (OUT/'results/analytic_checks.json').write_text(json.dumps(checks,indent=2))
    records=load_records()
    models=fit_all(records)
    evaluate_all(records,models)
