"""Recompute scores from saved arrays and verify every recurrence and split."""
from pathlib import Path
import json,hashlib,sys
import numpy as np
OUT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(Path(__file__).parent))
from run_comparison import predict,self_check

def main():
    models=json.loads((OUT/'results/frozen_parameters.json').read_text())
    metrics=json.loads((OUT/'results/metrics.json').read_text())
    summary=json.loads((OUT/'results/summary.json').read_text())
    audits=json.loads((OUT/'source_audit.json').read_text())
    records={a['record_id']:dict(np.load(OUT/'aligned'/f"{a['record_id']}.npz")) for a in audits}
    worst_recurrence=0.;worst_metric=0.;worst_training=0.
    for a in audits:
        path=OUT/'aligned'/f"{a['record_id']}.npz"
        assert hashlib.sha256(path.read_bytes()).hexdigest()==a['aligned_npz_sha256']
        assert a['five_numeric_channels_exactly_match_raw'] and a['strictly_increasing_absolute_time']
    for m in models:
        assert m['test_record'] not in m['train_records']
        assert 'B1_7D' not in m['train_records']
        if m['experiment']=='leave_one_cell_out':
            assert len(m['train_records'])==5
            assert all(x.split('_')[0]!=m['test_record'].split('_')[0] for x in m['train_records'])
        fit_mses=[]
        for key in m['train_records']:
            d=records[key];t=d['time_s'];dt=np.diff(t);y=d['temperature_C'][:,m['channel']-1]
            p=predict(t,d['current_A'],y[0],m['a_K_per_A2_s'],m['b_per_s'])
            fit_mses.append(float(np.sum(dt*(p[1:]-y[1:])**2)/sum(dt)))
        recomputed=float(np.sqrt(np.mean(fit_mses)))
        worst_training=max(worst_training,abs(recomputed-m['training_RMSE_C']))
        assert np.isclose(recomputed,m['training_RMSE_C'],rtol=1e-9,atol=1e-10)
    for key,d in records.items():
        saved=dict(np.load(OUT/'predictions'/f'{key}.npz'))
        t=d['time_s'];dt=np.diff(t);i=d['current_A'];temp=d['temperature_C']
        assert np.array_equal(saved['measured_C'],temp)
        active=abs(i[:-1])>1
        last_end=np.maximum.accumulate(np.where(active,t[1:],-np.inf))
        masks={'all':np.ones(len(dt),bool),'active':active,'active_plus_300s':t[:-1]-last_end<=300}
        for ch in range(1,4):
            for kind in ['formula','cooling_only','constant_initial']:
                p=saved[f'{kind}_T{ch}_C'];y=temp[:,ch-1]
                assert p[0]==y[0]
                if kind=='constant_initial':assert np.array_equal(p,np.full(len(t),y[0]))
                else:
                    m=next(x for x in models if x['test_record']==key and x['channel']==ch and x['model']==kind)
                    a=m['a_K_per_A2_s'];b=m['b_per_s']
                    forcing=a*i[:-1]**2*(dt if b==0 else -np.expm1(-b*dt)/b)
                    expected=25+np.exp(-b*dt)*(p[:-1]-25)+forcing
                    deviation=float(max(abs(p[1:]-expected)));worst_recurrence=max(worst_recurrence,deviation)
                    assert deviation<1e-10
                for region,mask in masks.items():
                    e=(p-y)[1:][mask];w=dt[mask];den=float(sum(w))
                    recomputed={'RMSE_C':float(np.sqrt(sum(w*e*e)/den)),
                                'MAE_C':float(sum(w*abs(e))/den),'bias_C':float(sum(w*e)/den),
                                'max_absolute_error_C':float(max(abs(e))),'duration_s':den}
                    row=next(x for x in metrics if x['test_record']==key and x['channel']==ch and x['model']==kind and x['region']==region)
                    for field,value in recomputed.items():
                        worst_metric=max(worst_metric,abs(value-row[field]))
                        assert np.isclose(value,row[field],rtol=1e-10,atol=1e-10)
    for group in summary['aggregates']:
        rows=[m for m in metrics if all(m[k]==group[k] for k in ['experiment','region','model'])]
        assert len(rows)==group['channel_record_count']
        rmse=float(np.sqrt(sum(x['RMSE_C']**2 for x in rows)/len(rows)))
        assert abs(rmse-group['macro_RMSE_C'])<1e-12
    assert len(audits)==7 and len(metrics)==189 and len(models)==42
    assert summary['protocol_sha256']==hashlib.sha256((OUT/'00_ANALYSIS_PROTOCOL.txt').read_bytes()).hexdigest()
    result={'passed':True,'records':7,'heldout_channel_records':21,'metrics_rows':len(metrics),
            'frozen_models':len(models),'source_alignment_hash_checks':7,
            'maximum_recurrence_discrepancy_C':worst_recurrence,'maximum_metric_discrepancy':worst_metric,
            'maximum_training_RMSE_recompute_difference_C':worst_training,
            'split_and_heldout_exclusion_checks':True,'analytic_checks':self_check(),
            'frozen_parameters_sha256':hashlib.sha256((OUT/'results/frozen_parameters.json').read_bytes()).hexdigest()}
    (OUT/'results/verification.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
