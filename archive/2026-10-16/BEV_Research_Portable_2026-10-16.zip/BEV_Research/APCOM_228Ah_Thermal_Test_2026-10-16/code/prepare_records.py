"""Align seven predetermined HPPC records to original instrument timestamps."""
from pathlib import Path
import sys,io,json,zipfile,hashlib,posixpath,re
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parents[1]
DATA=ROOT/'research/mining_battery_data_search_2026_10_16/mining_228Ah'
sys.path.insert(0,str(ROOT/'research/coupled_thermal_2026_10_16/tools'))
sys.stdout.reconfigure(encoding='utf-8')
import numpy as np
import pandas as pd
from scipy.io import loadmat
from lxml import etree as ET
NS='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
RID='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
P=ET.XMLParser(resolve_entities=False,no_network=True)

def strings(z):
    if 'xl/sharedStrings.xml' not in z.namelist(): return []
    root=ET.fromstring(z.read('xl/sharedStrings.xml'),P)
    return [''.join(e.itertext()) for e in root]

def sheet_path(z,name):
    wb=ET.fromstring(z.read('xl/workbook.xml'),P)
    rel=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'),P)
    mapping={e.get('Id'):e.get('Target') for e in rel}
    sheet=next(e for e in wb.find(NS+'sheets') if name is None or e.get('name')==name)
    target=mapping[sheet.get(RID)]
    return target.lstrip('/') if target.startswith('/') else posixpath.normpath('xl/'+target)

def col_index(ref,fallback):
    if not ref:return fallback
    val=0
    for c in re.sub('[0-9]','',ref):val=val*26+ord(c)-64
    return val-1

def rows(z,path,ss,keep=None):
    with z.open(path) as f:
        for _,row in ET.iterparse(f,events=('end',),tag=NS+'row',resolve_entities=False,no_network=True):
            result={}
            for idx,c in enumerate(row):
                key=col_index(c.get('r'),idx)
                if keep is not None and key not in keep:continue
                v=c.find(NS+'v');value=v.text if v is not None else ''.join(c.itertext())
                if c.get('t')=='s':value=ss[int(value)]
                result[key]=value
            yield result
            row.clear()
            while row.getprevious() is not None:del row.getparent()[0]

def first_elapsed(raw):
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        rr=rows(z,sheet_path(z,None),strings(z))
        hdr=next(rr);value=next(rr)[next(k for k,v in hdr.items() if v=='Successive_Time')]
    h,m,s=map(float,value.split(':'))
    return 3600*h+60*m+s

def prepare(outer,prefix):
    cell=prefix.split('-')[0];day=prefix.split('/')[1];key=cell+'_'+day
    path=OUT/'aligned'/f'{key}.npz'
    audit_path=OUT/'aligned'/f'{key}.json'
    if path.exists() and audit_path.exists():
        print('Verified extraction cache:',key,flush=True)
        return json.loads(audit_path.read_text(encoding='utf-8'))
    fields=['Fact_I','Fact_V','Temperature1','Temperature2','Temperature3']
    matname=prefix+'Data_Extract.mat';rawmat=outer.read(matname)
    mat=loadmat(io.BytesIO(rawmat),simplify_cells=True,variable_names=fields)
    expected=np.column_stack([np.asarray(mat[c],float).reshape(-1) for c in fields])
    elapsed=first_elapsed(outer.read(prefix+'Data_Extract.xlsx'))
    names=[n for n in outer.namelist() if n.startswith(prefix) and n.endswith('.xlsx') and Path(n).name not in ['Data_Extract.xlsx','OCV.xlsx','OCV-HPPC.xlsx']]
    assert len(names)==1,names
    source=names[0];blob=outer.read(source)
    print('Reading original clock:',key,len(expected),'samples',flush=True)
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        sp=sheet_path(z,'Record layer');ss=strings(z)
        hd=next(rows(z,sp,ss))
        wanted=['Absolute time','Actual current (A)','Actual voltage (V)','Temperature1(°C)','Temperature2(°C)','Temperature3(°C)','Continuous time']
        indices=[next(k for k,v in hd.items() if v==s) for s in wanted]
        rr=rows(z,sp,ss,set(indices));next(rr)
        d=pd.DataFrame([[r.get(k) for k in indices] for r in rr],columns=wanted)
    values=d[wanted[1:6]].astype(float).to_numpy()
    continuous=pd.to_numeric(d['Continuous time']).to_numpy()
    candidates=np.flatnonzero(np.isclose(continuous,elapsed*1000,atol=.1,rtol=0))
    n=len(expected);matches=[]
    for start in candidates:
        if np.array_equal(values[start:start+n],expected):matches.append(int(start))
    assert len(matches)==1,f'{key}: exact five-channel matches {matches}; candidates {candidates[:20]}'
    start=matches[0]
    dtimes=pd.to_datetime(d['Absolute time'],format='mixed')
    absolute=dtimes.iloc[start:start+n]
    t=(absolute-absolute.iloc[0]).dt.total_seconds().to_numpy()
    dt=np.diff(t)
    assert (dt>0).all(),f'{key}: nonpositive raw absolute intervals'
    assert np.isfinite(expected).all()
    q=values[start:start+n]
    np.savez_compressed(path,time_s=t,current_A=q[:,0],voltage_V=q[:,1],temperature_C=q[:,2:5])
    audit={'record_id':key,'cell':cell,'checkpoint':day,'raw_member':source,
           'raw_sha256':hashlib.sha256(blob).hexdigest(),'extracted_mat_member':matname,
           'mat_sha256':hashlib.sha256(rawmat).hexdigest(),'aligned_npz_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
           'source_sheet':'Record layer','source_column_labels':wanted,'raw_record_rows':len(d),
           'start_excel_row':start+2,'end_excel_row':start+n+1,'n':n,
           'five_numeric_channels_exactly_match_raw':True,'strictly_increasing_absolute_time':True,
           'absolute_start':str(absolute.iloc[0]),'absolute_end':str(absolute.iloc[-1]),
           'duration_s':float(t[-1]),'dt_min_median_max_s':[float(x) for x in [min(dt),np.median(dt),max(dt)]],
           'current_min_max_A':[float(q[:,0].min()),float(q[:,0].max())],
           'temperature_min_max_C':[[float(q[:,k].min()),float(q[:,k].max())] for k in range(2,5)],
           'measured_ambient_available':False,'nominal_ambient_C':25,'sensor_location_mapping_confirmed':False}
    audit_path.write_text(json.dumps(audit,indent=2),encoding='utf-8')
    print('Aligned',key,'duration hours',round(t[-1]/3600,3),'raw dt',audit['dt_min_median_max_s'],flush=True)
    return audit

if __name__=='__main__':
    (OUT/'aligned').mkdir(exist_ok=True)
    with zipfile.ZipFile(DATA/'mining_228Ah_V2.zip') as outer:
        prefixes=sorted(n[:-len('Data_Extract.mat')] for n in outer.namelist() if n.endswith('/HPPC/Data_Extract.mat') and ('/0D/' in n or (n.startswith('B1-') and '/7D/' in n)))
        assert len(prefixes)==7
        audits=[prepare(outer,p) for p in prefixes]
    (OUT/'source_audit.json').write_text(json.dumps(audits,indent=2),encoding='utf-8')
    print('ALL SEVEN RECORDS ALIGNED',flush=True)
