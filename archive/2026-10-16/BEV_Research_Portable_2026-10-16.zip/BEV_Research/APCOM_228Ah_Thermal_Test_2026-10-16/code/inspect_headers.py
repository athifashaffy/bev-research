from pathlib import Path
import io,sys,zipfile
from lxml import etree as ET
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parents[2]
DATA=ROOT/'research/mining_battery_data_search_2026_10_16/mining_228Ah'
NS={'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
P=ET.XMLParser(resolve_entities=False,no_network=True)
with zipfile.ZipFile(DATA/'mining_228Ah_V2.zip') as outer:
    names=[n for n in outer.namelist() if '/HPPC/' in n and n.endswith('.xlsx') and ('/0D/' in n or (n.startswith('B1-') and '/7D/' in n)) and 'Data_Extract' not in n and 'OCV' not in n]
    for name in names:
        with zipfile.ZipFile(io.BytesIO(outer.read(name))) as z:
            ss=ET.fromstring(z.read('xl/sharedStrings.xml'),P) if 'xl/sharedStrings.xml' in z.namelist() else []
            strings=[''.join(e.itertext()) for e in ss]
            wb=ET.fromstring(z.read('xl/workbook.xml'),P)
            print(name,flush=True)
            print([s.attrib for s in wb.findall('x:sheets/x:sheet',NS)],flush=True)
            for path in sorted(n for n in z.namelist() if n.startswith('xl/worksheets/sheet') and n.endswith('.xml')):
                with z.open(path) as f:
                    for _,row in ET.iterparse(f,events=('end',),tag='{'+NS['x']+'}row',resolve_entities=False,no_network=True):
                        vals=[]
                        for c in row:
                            v=c.find('x:v',NS);v=v.text if v is not None else ''.join(c.itertext())
                            if c.get('t')=='s':v=strings[int(v)]
                            vals.append((c.get('r'),v))
                        print(path,vals[:30],flush=True)
                        break
