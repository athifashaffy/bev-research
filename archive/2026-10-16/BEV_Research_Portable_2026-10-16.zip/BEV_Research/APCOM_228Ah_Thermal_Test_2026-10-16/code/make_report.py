"""Generate a concise supervisor report and paper-ready prose from verified results."""
from pathlib import Path
import json,sys,csv
from xml.sax.saxutils import escape
OUT=Path(__file__).resolve().parents[1]
sys.stdout.reconfigure(encoding='utf-8')
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,PageBreak
from reportlab.lib.utils import ImageReader

summary=json.loads((OUT/'results/summary.json').read_text())
metrics=json.loads((OUT/'results/metrics.json').read_text())
models=json.loads((OUT/'results/frozen_parameters.json').read_text())
audit=json.loads((OUT/'source_audit.json').read_text())
verify=json.loads((OUT/'results/verification.json').read_text())
assert verify['passed']
def score(experiment,region,model):
    return next(r['macro_RMSE_C'] for r in summary['aggregates'] if r['experiment']==experiment and r['region']==region and r['model']==model)
cross_c=score('leave_one_cell_out','all','constant_initial');cross_f=score('leave_one_cell_out','all','formula')
chrono_c=score('chronological','all','constant_initial');chrono_f=score('chronological','all','formula')
improve=(1-cross_f/cross_c)*100;worsen=(chrono_f/chrono_c-1)*100
hours=sum(a['duration_s'] for a in audit)/3600
observations=sum(a['n'] for a in audit)
SOURCE='https://data.mendeley.com/datasets/dhr726bk6z/2'

paper_methods=(
    'A reduced cell-temperature model, dT/dt = a I² - b(T - T_a), was evaluated using '
    'seven HPPC records from an open dataset of six 228 Ah LFP cells intended for mining-power applications '
    '(Mendeley Data, DOI 10.17632/dhr726bk6z.2). These were laboratory characterization tests, '
    'not underground vehicle measurements. The nominal characterization ambient T_a was fixed at 25°C '
    'from the dataset README; no independent ambient time series was available. The six initial (0D) '
    'records were evaluated using leave-one-cell-out calibration, with separate fits for each of three '
    'recorded temperature channels. A secondary chronological check calibrated on B1 0D and evaluated '
    'B1 7D. Original instrument absolute timestamps were used after exact alignment of current, voltage '
    'and temperature with the publisher-extracted arrays. Nonnegative a and b were fitted only to '
    'training records, with equal record weights and time-weighted squared error within each record. '
    'The model was propagated with left-held measured current and the measured initial temperature, '
    'without subsequent temperature feedback. Comparators were constant initial temperature and '
    'a separately calibrated cooling-only model. Reported aggregate RMSE is the square root of the '
    'mean of channel-record mean squared errors, with equal cell and channel weights.'
)
paper_results=(
    f'In the six-cell evaluation, aggregate whole-record RMSE decreased from {cross_c:.3f}°C '
    f'for constant initial temperature to {cross_f:.3f}°C for the current-and-cooling model '
    f'({improve:.1f}% lower). Active-current RMSE decreased from '
    f"{score('leave_one_cell_out','active','constant_initial'):.3f}°C to {score('leave_one_cell_out','active','formula'):.3f}°C. "
    'The aggregate benefit was uneven: five of 18 channel-record comparisons improved, four tied and '
    'nine worsened; large gains were concentrated in Temperature2 for cells B3 and B5. In the '
    f'separate B1 chronological check, whole-record RMSE increased from {chrono_c:.3f}°C to '
    f'{chrono_f:.3f}°C ({worsen:.1f}% higher). The cooling-only model achieved '
    f"{score('leave_one_cell_out','all','cooling_only'):.3f}°C in the cross-cell evaluation and "
    f"{score('chronological','all','cooling_only'):.3f}°C in the chronological check. "
    'These results support a limited feasibility assessment, but do not establish a temperature model '
    'that transfers reliably between cells and test occasions.'
)
paper_limits=(
    'The dataset provides no confirmed mapping from Temperature1-3 to individual terminal or surface '
    'locations, and these labels may not represent equivalent thermal states across cells. All '
    'characterization tests were nominally at 25°C; the 25/45/60°C folder labels refer to calendar-aging '
    'storage conditions. Small temperature excursions, approximately 0.1°C recorded steps, uncertain '
    'ambient conditions, and zero/boundary fitted coefficients limit physical parameter identification. '
    'The fitted parameters are effective ratios, a = R_eff/C_eff and b = UA_eff/C_eff, rather than '
    'independently measured resistance, heat capacity or heat transfer. The chronological check uses '
    'different training coverage from the cross-cell test; its poorer result cannot be attributed '
    'causally to aging. There are no thermal-runaway labels, detection lead times, or mine-duty cycles '
    'in this evaluation. These cell-level coefficients must not be presented as validated Z50 pack '
    'parameters or used to claim validated HAULSIM battery temperatures.'
)
paper_text='\n\n'.join([
    'PROPOSED APCOM METHODS / RESULTS TEXT — FOR SUPERVISOR REVIEW',
    'Generated from verified exploratory results on 2026-10-16. No existing manuscript was edited.',
    'METHODS\n'+paper_methods,'RESULTS\n'+paper_results,'LIMITATIONS\n'+paper_limits,
    'PROPOSED ROLE IN THE PAPER\nUse as a laboratory feasibility and validation-limits subsection within '
    'the practical underground BEV monitoring methodology. Keep HAULSIM duty-cycle and road-condition '
    'scenarios explicitly separate from this cell experiment. The contribution is an auditable comparison '
    'against a simple baseline plus a specification of what operational measurements are still needed. '
    'This is a proposed contribution, not a claim that the formula is novel. The accepted AI sensor-fusion '
    'and early-warning abstract is not substantiated by this temperature-only test; agree any scope '
    'change with the supervisors, or add properly labeled fault/sensor evidence before claiming detection.',
    'NEXT VALIDATION DATA\nFor the chosen underground truck: synchronized battery current, voltage, '
    'SOC, identified temperature probes, ambient temperature and cooling state; pack series/parallel '
    'topology; and matched haul-cycle timing. Calibrate on separate cycles and validate on complete '
    'held-out cycles/machines. Keep mining vehicle, laboratory cell and mine-route assumptions distinct.',
    'SOURCE / ATTRIBUTION\nContributor as displayed by the repository: 居强 封. (2026). '
    'Dataset of multi-dimensional electrical performance for large-capacity mining power lithium-ion '
    'batteries at early calendar aging under coupled temperature and soc conditions. '
    'Mendeley Data, version 2. DOI: 10.17632/dhr726bk6z.2. CC BY 4.0. '+SOURCE,
    'The bundled README still prints the version-1 DOI; the downloaded archive and this analysis use '
    'version 2. Temperature plots and model calculations are derived analysis, not publisher-validated outputs.'
])
(OUT/'02_APCOM_Text_for_Supervisor_Review.txt').write_text(paper_text,encoding='utf-8')

readme=f'''START HERE — 228 Ah thermal-model experiment, 2026-10-16

Conclusion: useful exploratory evidence, insufficient for a validated mine/truck-temperature claim.
Six-cell cross-validation: constant {cross_c:.3f} C RMSE; formula {cross_f:.3f} C ({improve:.1f}% lower).
Later test on B1: constant {chrono_c:.3f} C; formula {chrono_f:.3f} C ({worsen:.1f}% higher).
Only 5/18 initial-record channel comparisons improved; 4 tied; 9 worsened.

Read 01_Thermal_Formula_Results.pdf for the supervisor briefing.
Read 02_APCOM_Text_for_Supervisor_Review.txt for proposed paper wording and limits.
Figures contains presentation-ready PNG and editable SVG plots.
00_ANALYSIS_PROTOCOL.txt records the comparison rules fixed before fitting.
results/metrics.csv and metrics.json contain every model/channel/window result.
results/frozen_parameters.json has every training split and fitted coefficient.
results/verification.json records the completed numerical checks.
source_audit.json records seven exact raw/extracted five-channel matches and source hashes.
aligned/ contains verified input arrays; predictions/ contains full-resolution predictions.

{observations:,} observations across seven approximately 22.7-hour records ({hours:.2f} hours).
This is 7 of 55 HPPC records, six physical cells, not {observations:,} independent experiments.
No native HAULSIM simulation was run or edited; no manuscript, email or cloud document was modified.
The earlier A123 2.5 Ah coefficients were not reused.

Reproduce using the bundled Python executable in the workspace runtime:
1. code/prepare_records.py (reads the downloaded archive; caches verified aligned arrays)
2. code/run_comparison.py (fits and freezes all coefficients, then evaluates)
3. code/verify_results.py (recomputes metrics, recurrences and training objectives)
4. code/make_figures.py
5. code/make_report.py
Task-local scipy and matplotlib paths are declared in the scripts.
Source: {SOURCE}; DOI 10.17632/dhr726bk6z.2; CC BY 4.0.
Original archive: ../research/mining_battery_data_search_2026_10_16/mining_228Ah/mining_228Ah_V2.zip
'''
(OUT/'00_START_HERE.txt').write_text(readme,encoding='utf-8')

navy=colors.HexColor('#172a43');teal=colors.HexColor('#007c83');grey=colors.HexColor('#506176')
styles=getSampleStyleSheet()
styles.add(ParagraphStyle('TitleX',fontName='Helvetica-Bold',fontSize=24,leading=28,textColor=navy,spaceAfter=12))
styles.add(ParagraphStyle('Deck',fontName='Helvetica',fontSize=11,leading=16,textColor=grey,spaceAfter=12))
styles.add(ParagraphStyle('H',fontName='Helvetica-Bold',fontSize=13,leading=17,textColor=navy,spaceBefore=12,spaceAfter=6))
styles.add(ParagraphStyle('B',fontName='Helvetica',fontSize=10,leading=14,spaceAfter=8))
styles.add(ParagraphStyle('SmallX',fontName='Helvetica',fontSize=8.3,leading=11,textColor=grey,spaceAfter=6))
styles.add(ParagraphStyle('Formula',fontName='Helvetica-Bold',fontSize=14,leading=21,textColor=teal,spaceBefore=5,spaceAfter=10))
story=[]
def p(text,style='B'):story.append(Paragraph(text,styles[style]))
def graphic(name,width=490):
    path=OUT/'figures'/name;iw,ih=ImageReader(str(path)).getSize()
    story.append(Image(str(path),width=width,height=width*ih/iw))
def table(rows,widths):
    cells=[[Paragraph(str(v),styles['SmallX']) for v in r] for r in rows]
    t=Table(cells,colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e6eef4')),
                          ('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),6),
                          ('BOTTOMPADDING',(0,0),(-1,-1),5),('LINEBELOW',(0,0),(-1,0),.7,navy),
                          ('LINEBELOW',(0,1),(-1,-1),.3,colors.HexColor('#d4dde6'))]))
    story.append(t);story.append(Spacer(1,8))

p('Does the temperature<br/>formula help?', 'TitleX')
p('APCOM supervisor briefing | 228 Ah LFP laboratory evaluation | 16 October 2026','Deck')
p('<b>Mixed results:</b> the formula improves aggregate error across the six cells, but does not transfer reliably across channels or to a later test. This is a useful feasibility result; operational validation remains open.')
p('dT/dt = a I<super>2</super> - b(T - T<sub>a</sub>)', 'Formula')
p('Current contributes heat; cooling removes heat toward ambient. Here T<sub>a</sub> = 25°C is assumed from the test description. The comparator simply holds the first measured temperature constant.','SmallX')
table_rows=[['Held-out comparison','Constant<br/>RMSE (°C)','Formula<br/>RMSE (°C)','Cooling only<br/>RMSE (°C)']]
for ex,rg,label in [('leave_one_cell_out','all','Six cells: whole test'),('leave_one_cell_out','active','Six cells: active current'),('chronological','all','B1 later test: whole test'),('chronological','active','B1 later test: active current')]:
    table_rows.append([label,*[f'{score(ex,rg,k):.3f}' for k in ['constant_initial','formula','cooling_only']]])
table(table_rows,[220,90,90,90])
p(f'The {improve:.1f}% aggregate reduction is driven mainly by Temperature2 on B3 and B5. Only <b>5 of 18</b> channel comparisons improved; 4 tied and 9 worsened. The later B1 test became <b>{worsen:.1f}% worse</b>.')
graphic('01_Held_Out_Comparison.png')
p('RMSE is prediction error in degrees Celsius; lower is better. All metrics use original samples and actual time intervals. Three channels are correlated and are not independent replicates.','SmallX')

story.append(PageBreak())
p('What was tested', 'TitleX')
p(f'Seven predetermined records, six cells, {hours:.2f} hours of laboratory measurements. These are cell-level tests at nominal 25°C, not Z50 telemetry.','Deck')
p('Inputs and provenance','H')
p('All six initial (0D) HPPC records were selected, plus B1 at its earliest repeat (7D). Current, voltage and all three temperature arrays match their original instrument records exactly. Raw Absolute time is strictly increasing. The processed elapsed clock was not assumed correct.')
table([['Record','Samples','Hours','Recorded temperature range, T1 / T2 / T3 (°C)']]+[
    [a['record_id'],f"{a['n']:,}",f"{a['duration_s']/3600:.2f}",' / '.join(f'{x[0]:.1f}-{x[1]:.1f}' for x in a['temperature_min_max_C'])] for a in audit],
    [65,65,55,305])
p('Fitting and holdout rules','H')
p('For each initial-record fold, five whole cells calibrate the model and the sixth is held out. The later B1 test is a separate experiment trained only on B1 0D. Each of T1, T2 and T3 is fitted separately. Both predictors receive the same first temperature; no later test temperatures enter the model.')
p('The numerical update is exact for left-held current: T<sub>k+1</sub> = T<sub>a</sub> + (T<sub>k</sub> - T<sub>a</sub>)e<super>-b dt</super> + (a I<sub>k</sub><super>2</super>/b)(1 - e<super>-b dt</super>). Here dt is the elapsed interval. At b = 0 the final term becomes a I<sub>k</sub><super>2</super> dt.')
p('Nonnegative coefficients minimize time-weighted squared error, with equal weight per training record. A grid over b = 0 and 10<super>-7</super> to 1 s<super>-1</super> is refined at local minima; a is solved analytically at each b. Scores include whole-test, active-current and active-plus-300-second windows. All split parameters were saved before test metrics were generated.')
p('Parameter interpretation and verification','H')
p('Across the 21 formula fits, 9 selected a = 0 and 6 selected b = 0; some fitted cooling times exceed a test duration. These are effective coefficients with weak physical identification, not measured pack constants. Only the ratios R<sub>eff</sub>/C<sub>eff</sub> and UA<sub>eff</sub>/C<sub>eff</sub> are fitted.')
p('Verification passed: all 189 metric rows independently recomputed; training objectives reproduced; disjoint splits and input hashes checked; closed-form constant-current, cooling-only and zero-cooling cases passed. Maximum recurrence discrepancy: 7.11 × 10<super>-15</super>°C.','SmallX')

story.append(PageBreak())
p('The later test is the warning', 'TitleX')
p('A good calibration fit did not guarantee a good prediction on the next available B1 record.','Deck')
graphic('02_Chronological_Holdout.png')
p('Coefficients calibrated on B1 0D; then frozen','H')
pt=[['Channel','a (K A<super>-2</super> s<super>-1</super>)','b (s<super>-1</super>)','Calibration RMSE (°C)']]
for m in models:
    if m['experiment']=='chronological' and m['model']=='formula':
        pt.append([f"T{m['channel']}",f"{m['a_K_per_A2_s']:.4e}",f"{m['b_per_s']:.4e}",f"{m['training_RMSE_C']:.3f}"])
table(pt,[60,145,125,160])
p('The formula pulls T1 and T3 toward the nominal 25°C ambient, while the recorded values remain higher. Without measured ambient and identified probe locations, this mismatch cannot be assigned to one cause. The result does not prove aging caused a thermal change.')
p('Cooling-only RMSE on this later record is 0.148°C, compared with 0.224°C for constant initial temperature and 0.292°C for the current-and-cooling formula. The added current term therefore has no demonstrated stable benefit across the two evaluation designs.','SmallX')

story.append(PageBreak())
p('What APCOM can use', 'TitleX')
p('Use this as a transparent feasibility and validation-limits subsection in the underground BEV monitoring methodology.','Deck')
p('Suggested results paragraph','H')
p(escape(paper_results))
p('Claims supported by this experiment','H')
p('An open 228 Ah dataset contains usable synchronized current and temperature measurements. A reduced current-driven temperature model can be calibrated and compared reproducibly against constant temperature. Aggregate improvements coexist with failures on individual channels and a later test, so reporting only one pooled accuracy number would overstate reliability.')
p('Claims still unsupported','H')
p('Validated New Afton or Z50 battery temperatures; rugged-road or hot-mine effects; battery core temperature; thermal-runaway prediction; detection lead time; and AI sensor-fusion performance. The 45/60°C directory labels are aging storage settings, not the characterization ambient. B4 failure is not a labeled thermal-runaway event.')
p('How this connects to HAULSIM','H')
p('The proposed connection is from haul-cycle timing and road resistance to traction/battery power, then to cell current using known voltage and pack topology, and finally to temperature with measured ambient and cooling inputs. This experiment tests only the last step on laboratory cells. These coefficients are not validated Z50 pack data.')
p('Recommended supervisor decision','H')
p('Approve this limited laboratory comparison as supporting evidence, and keep any HAULSIM temperature outputs labeled as sensitivity scenarios until vehicle-specific data are available. The accepted early-warning / AI abstract needs separate fault and sensor evidence, or an explicitly agreed scope revision. A conventional thermal formula alone is not a demonstrated new scientific contribution.')
p('Source and reproducibility','H')
p(f'Mendeley Data, version 2; DOI <link href="https://doi.org/10.17632/dhr726bk6z.2" color="#007c83">10.17632/dhr726bk6z.2</link>; CC BY 4.0. <link href="{SOURCE}" color="#007c83">Open source record</link>. Full title and contributor attribution are in the accompanying proposed paper text.','SmallX')
p('Derived analysis of version 2; the source README still cites version 1. Full metrics, hashes, parameters, code and protocol accompany this report. Probe locations and measured ambient remain unresolved. Existing manuscript and HAULSIM files were not edited.','SmallX')

def footer(c,doc):
    c.saveState();c.setStrokeColor(colors.HexColor('#d3dce6'));c.line(48,43,564,43)
    c.setFont('Helvetica',8);c.setFillColor(grey)
    c.drawString(48,30,'APCOM | exploratory laboratory evaluation | 16 October 2026')
    c.drawRightString(564,30,str(doc.page));c.restoreState()
doc=SimpleDocTemplate(str(OUT/'01_Thermal_Formula_Results.pdf'),pagesize=(612,792),leftMargin=55,rightMargin=55,topMargin=42,bottomMargin=55,
                      title='228 Ah thermal formula: baseline comparison and APCOM implications',author='Athif - research working analysis')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print(json.dumps({'report':'01_Thermal_Formula_Results.pdf','observations':observations,'hours':hours,
                  'cross_cell_RMSE_reduction_percent':improve,'chronological_RMSE_increase_percent':worsen},indent=2))
