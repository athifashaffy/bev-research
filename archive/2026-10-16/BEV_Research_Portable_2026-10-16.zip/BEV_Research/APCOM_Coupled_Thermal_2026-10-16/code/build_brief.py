"""Build figures and a readable methods brief from saved, verified calculations."""
from pathlib import Path
import sys, json, csv, hashlib, math, importlib.metadata
PKG=Path(__file__).resolve().parents[1]
ROOT=PKG.parent
sys.path.insert(0,str(ROOT/'research/coupled_thermal_2026_10_16/tools'))
import numpy as np
sys.path.insert(0,str(ROOT/'research/haulsim_detail/tools'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import letter
from pypdf import PdfReader

RESULTS=PKG/'results'; FIG=PKG/'figures'; FIG.mkdir(exist_ok=True)
model=json.loads((RESULTS/'frozen_cell_model.json').read_text())
metrics=json.loads((RESULTS/'record_metrics.json').read_text())
audit=json.loads((RESULTS/'coupling_audit.json').read_text())
cases=audit['cases']; a=model['a_K_per_A2_s']; b=model['b_per_s']

def rows(name):
    with (RESULTS/name).open(newline='') as f:return list(csv.DictReader(f))
def numbers(data,key):return np.asarray([float(r[key]) for r in data])
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
    'axes.labelcolor':'#243746','text.color':'#243746','axes.titleweight':'bold',
    'savefig.dpi':220,'font.family':'DejaVu Sans'})
blue='#176B9D'; orange='#C85122'; green='#39866B'
fig,axes=plt.subplots(3,1,figsize=(10,7.5),layout='constrained')
for ax,m in zip(axes,metrics):
    data=rows(m['file'].replace('.mat','_prediction.csv')); t=numbers(data,'time_s')/60
    ax.plot(t,numbers(data,'measured_surface_C'),color=blue,lw=1.5,label='Measured surface')
    ax.plot(t,numbers(data,'predicted_surface_C'),color=orange,lw=1.25,ls='--',label='Frozen model')
    ax.plot(t,numbers(data,'air_C'),color=green,lw=1,label='Measured air')
    tag='Calibration: pulse record' if m['role']=='FIT' else 'Held out: '+m['file'].replace('.mat','')
    ax.set_title(f"{tag} | time-weighted RMSE {m['RMSE_C']:.3f} C",loc='left',fontsize=11)
    ax.set_ylabel('Temperature (C)');ax.set_xlabel('Elapsed time (min)');ax.grid(alpha=.2)
axes[0].legend(loc='upper right',ncol=3,fontsize=8)
fig.savefig(FIG/'01_laboratory_validation.png');fig.savefig(FIG/'01_laboratory_validation.svg');plt.close(fig)

events=rows('haulsim_event_load.csv');traces=rows('coupled_temperature_traces.csv')
fig,axes=plt.subplots(3,1,figsize=(10,8),layout='constrained',sharex=True)
edges=np.r_[numbers(events,'start_s'),7200.]/60
axes[0].stairs(numbers(events,'estimated_battery_power_kW'),edges,color=blue,lw=1.7)
for e in events:
    if e['state']=='TravelLoaded':
        axes[0].axvspan(float(e['start_s'])/60,(float(e['start_s'])+float(e['duration_s']))/60,color=blue,alpha=.07)
axes[0].set_title('Actual HAULSIM event schedule; estimated electrical power',loc='left',fontsize=11)
axes[0].set_ylabel('Battery power (kW)')
for air,color in [(25,blue),(35,orange),(40,green)]:
    data=[r for r in traces if float(r['ambient_C_assumed'])==air]
    t=numbers(data,'time_s')/60;temp=numbers(data,'surface_C_surrogate')
    axes[1].plot(t,temp,color=color,label=f'{air} C air'+(' (extrapolation)' if air==40 else ''))
    if air==25:axes[2].plot(t,temp-air,color=blue,lw=1.7,label='Predicted rise above 25 C air')
axes[1].set_title('Representative laboratory cell response; not a Z50 pack prediction',loc='left',fontsize=11)
axes[1].set_ylabel('Cell surface (C)');axes[1].legend(ncol=3,fontsize=8,loc='lower right')
axes[2].axhline(metrics[1]['RMSE_C'],ls='--',color=orange,lw=1.3,label='Held-out RMSE reference (not a confidence bound)')
axes[2].set_title('Cycle-driven warming is smaller than held-out model error',loc='left',fontsize=11)
axes[2].set_ylabel('Temperature rise (K)');axes[2].set_xlabel('Native simulation time (min)')
axes[2].set_ylim(0,.14);axes[2].legend(loc='upper right',fontsize=8)
for ax in axes:ax.grid(alpha=.2);ax.set_xlim(0,120)
fig.savefig(FIG/'02_native_cycle_and_temperature.png');fig.savefig(FIG/'02_native_cycle_and_temperature.svg');plt.close(fig)

fig=plt.figure(figsize=(10,2.3));fig.patch.set_facecolor('white')
equations=[r'$P_{b,k}=\frac{E^{+}_{w,k}}{\eta_d\,\Delta t_{k,\mathrm{h}}}+P_{aux}$',
    r'$I_{c,k}=Q_c\,\frac{P_{b,k}}{E_{pack}}$',
    r'$\frac{dT_s}{dt}=aI_c^2-b(T_s-T_a)$',
    r'$T_{s,k+1}=T_a+\frac{a I_{c,k}^2}{b}+\left(T_{s,k}-T_a-\frac{a I_{c,k}^2}{b}\right)e^{-b\Delta t_{k,\mathrm{s}}}$']
for y,eq in zip([.83,.60,.38,.12],equations):fig.text(.05,y,eq,fontsize=17)
fig.savefig(FIG/'03_equations.png',bbox_inches='tight');plt.close(fig)

methods=(
"A one-way coupling was developed between a previously executed native HAULSIM haul-cycle recording and a reduced laboratory-cell surface-temperature model. "
"The New Afton-informed RR03 case used one truck, a 45 t payload and assumed 3% rolling resistance. Its 29 contiguous equipment states cover 7,200 s; the final loaded leg is incomplete and was retained using its actual recorded duration and work. "
"Positive wheel work was interpreted as kWh and converted to event-average terminal power using 0.85 drive efficiency, a constant 20 kW auxiliary load and zero credited regeneration. "
"The energy scale was cross-checked against gravitational and approximate rolling work; independent confirmation of the native export-unit definition remains required. "
"Battery current was represented by C-rate equivalence, I_cell = Q_cell P_batt/E_pack, using a 2.5 Ah laboratory cell and the published Z50 nominal 354 kWh pack capacity. "
"No Z50 cell configuration or cooling parameters were inferred. The thermal model dTs/dt = a I_cell^2 - b(Ts-Tair) was fitted by time-weighted least squares to the A002 periodic-pulse record from the open A123 LFP dataset [1]. "
"Coefficients were frozen before evaluation on separate A002 UDDS records at nominal 25 and 35 C. Measured air temperature and current were inputs; measured surface temperature was used only at initialization. "
"The frozen model was then integrated exactly for each HAULSIM state under constant assumed ambient temperatures of 25, 35 and 40 C, with identical load histories and initial temperature of 25 C."
)
results=(
f"The fitted coefficients were a = {a:.8g} K/(A^2 s) and b = {b:.8g} s^-1, corresponding to a {1/b:.2f} s time constant. "
f"Full-record held-out time-weighted RMSEs were {metrics[1]['RMSE_C']:.3f} and {metrics[2]['RMSE_C']:.3f} C, compared with {metrics[1]['air_following_baseline_RMSE_C']:.3f} and {metrics[2]['air_following_baseline_RMSE_C']:.3f} C for an air-following baseline. "
"The test records belong to the same cell as the calibration record and include conditioning/rest intervals; these are record-level laboratory evaluations, not independent-cell or mine validation. "
f"The reconstructed native-cycle load consumed {audit['estimated_total_battery_terminal_energy_kWh']:.2f} kWh in 2 h under the stated assumptions; native battery/SOC accounting was disabled. "
"Representative-cell final surface temperatures were 25.07, 35.07 and 40.07 C for the three assumed air temperatures. "
"The largest modelled rise above air was approximately 0.070 K, smaller than either held-out RMSE. Consequently, these results do not establish a resolved haul-induced temperature rise in the real truck. "
"They demonstrate a reproducible coupling and a laboratory benchmark. Z50 pack calibration, mining-duty validation and early-warning performance remain untested."
)
(PKG/'02_APCOM_Methods_and_Results.txt').write_text(
"DRAFT METHODS AND RESULTS FOR SUPERVISOR REVIEW\n16 October 2026\n\n"
"Status: preliminary laboratory benchmark and HAULSIM-driven representative-cell sensitivity.\n"
"This is not a validated Z50 pack-temperature result or a completed APCOM paper.\n\nMETHODS\n"+methods+
"\n\nRESULTS AND INTERPRETATION\n"+results+
"\n\nPROPOSED PRACTICAL FOCUS\nEffect of assumed mine ambient temperature on a HAULSIM-driven representative LFP cell model.\n"
"The ambient response follows the assumed linear model; this is not by itself a novel physical discovery.\n"
"The accepted APCOM abstract promises AI-based early detection. This work supplies a normal-operation baseline and coupling method, but does not demonstrate that claim. Agree the paper scope with the supervisor before submission.\n\n"
"REFERENCES\n[1] Kawakita de Souza, Aloisio (2021). Lithium-ion Battery OCV and Dynamic Test Data of a LiFePO4 cylindrical cell. Mendeley Data, V1. https://doi.org/10.17632/p8kf893yv3.1 (CC BY 4.0). Data obtained from the author's repository at pinned commit 4fc9320c85f91317ace5d1bc9c40f53aaa2b1140.\n"
"[2] Sandvik (n.d.). Artisan Z50 specification sheet. Battery-capacity table, PDF page 5; LFP chemistry, pages 1 and 6. https://www.mining.sandvik/globalassets/products/underground-loaders-and-trucks/pdf/artisan-z50-specification-sheet-english.pdf\n"
"[3] Local native HAULSIM RR03 export and audit, 15 October 2026. Assumed road condition on a New Afton-informed geometry; not an actual-mine measurement. sources/native_RR03 in this package.\n",encoding='utf-8')

styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='BodyB',fontName='Helvetica',fontSize=10.1,leading=13.9,spaceAfter=7,textColor=colors.HexColor('#243746')))
styles.add(ParagraphStyle(name='SmallB',parent=styles['BodyB'],fontSize=8.4,leading=11.3,spaceAfter=5))
styles.add(ParagraphStyle(name='TitleB',fontName='Helvetica-Bold',fontSize=23,leading=28,spaceAfter=13,textColor=colors.HexColor('#16394C')))
styles.add(ParagraphStyle(name='HeadingB',fontName='Helvetica-Bold',fontSize=13.5,leading=18,spaceBefore=8,spaceAfter=8,textColor=colors.HexColor('#16394C')))
styles.add(ParagraphStyle(name='CellB',parent=styles['SmallB'],fontSize=8.7,leading=11.4,spaceAfter=0))
story=[]
def p(text,style='BodyB'):story.append(Paragraph(text,styles[style]))
def h(text):p(text,'HeadingB')
def page():story.append(PageBreak())
def img(name,width=468):
    from PIL import Image as PILImage
    with PILImage.open(FIG/name) as im:w,ht=im.size
    story.append(Image(str(FIG/name),width=width,height=width*ht/w))
def table(data,widths):
    data=[[Paragraph(str(x),styles['CellB']) for x in row] for row in data]
    t=Table(data,colWidths=widths,hAlign='LEFT',repeatRows=1)
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E9F0F4')),
       ('VALIGN',(0,0),(-1,-1),'TOP'),('BOTTOMPADDING',(0,0),(-1,-1),7),
       ('TOPPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#AABEC8')),
       ('LINEBELOW',(0,1),(-1,-1),.3,colors.HexColor('#DEE5E9'))]))
    story.append(t);story.append(Spacer(1,9))

p('HAULSIM cycle to battery temperature','TitleB')
p('A reproducible laboratory benchmark and underground-mine sensitivity study','HeadingB')
p('Professor review brief | 16 October 2026 | New Afton-informed RR03 scenario','SmallB')
p('<b>Completed:</b> a real native HAULSIM event schedule has been connected to a fitted thermal equation. Open measured LFP data were used for calibration and separate-record evaluation. No new native HAULSIM simulation was run in this pass; existing native results were postprocessed.')
table([['Evidence','What it supports'],
 ['Native HAULSIM RR03 recording','29 states over 2 h; four completed loads (180 t); assumed underground road condition.'],
 ['Measured A123 LFP laboratory recordings','A reduced cell-surface model tested on two held-out records. RMSE: 0.109 and 0.117 C.'],
 ['Published Z50 specification','LFP chemistry; nominal 354 kWh, 576 Ah and 480 kW continuous battery rating. It does not identify the dataset cell as a Z50 cell.'],
 ['Coupled temperature sensitivity','Representative-cell demonstration only. No mine-validated pack/core temperature or early-fire detection result.']], [144,324])
h('The connected formula')
img('03_equations.png')
p('P<sub>b</sub>: estimated terminal power (kW); E<sub>w</sub><super>+</super>: positive wheel work (kWh); eta<sub>d</sub> = 0.85; P<sub>aux</sub> = 20 kW; Q<sub>c</sub> = 2.5 Ah; E<sub>pack</sub> = 354 kWh. Thermal integration uses seconds; power conversion uses hours. T<sub>s</sub> is representative cell surface temperature and T<sub>a</sub> is surrounding air.','SmallB')
p('<b>Main finding:</b> the coupled model adds only about 0.070 C above air under the laboratory cooling fit. That is smaller than its held-out error. The defensible result is a tested modelling workflow; a resolved real-truck warming effect has not been established.')

page();h('1. Measured battery data and held-out checks')
p('Source [1]: A123 26650 m1b, 2.5 Ah LFP laboratory cell. Only the periodic-pulse file was used to fit a and b. The two UDDS files were evaluated after freezing those coefficients. Each prediction uses measured initial surface temperature once, then only measured current and air temperature as inputs.','SmallB')
img('01_laboratory_validation.png')
table([['Record / role','Measured mean air','RMSE','Air baseline RMSE'],
 ['Periodic pulse / fit','25.88 C','0.077 C','2.920 C'],
 ['UDDS nominal 25 C / held out','26.12 C','0.109 C','0.604 C'],
 ['UDDS nominal 35 C / held out','36.72 C','0.117 C','0.805 C']], [187,104,73,104])
p(f'a = {a:.8g} K/(A<super>2</super> s); b = {b:.8g} s<super>-1</super>; time constant 1/b = {1/b:.2f} s. These identify the ratios R<sub>eff</sub>/C<sub>eff</sub> and UA<sub>eff</sub>/C<sub>eff</sub>, not independent resistance, thermal mass and cooling conductance.','SmallB')
p('RMSE is weighted by elapsed time over the complete record, including conditioning and rest. Active-current sample RMSEs are 0.126 and 0.138 C for the two held-out files. All three files are for A002: this is not an independent-cell test. Nominal chamber labels differ from measured air temperatures. Sensor uncertainty was not quantified here.','SmallB')

page();h('2. Actual cycle input and illustrative temperature output')
p('RR03 keeps the native state order and durations, including the final partial loaded leg. Shade marks loaded travel. Electrical power is externally reconstructed; native battery/SOC simulation was disabled. Ambient temperature is the only varied input.','SmallB')
img('02_native_cycle_and_temperature.png')
table([['Assumed air','Initial cell','Final cell surrogate','Interpretation'],
 ['25 C','25 C','25.070 C','Near lower nominal test condition'],
 ['35 C','25 C','35.070 C','Near upper nominal test condition'],
 ['40 C','25 C','40.070 C','Extrapolation beyond held-out air range']], [88,83,132,165])
p('The 0.109 C line is an error-scale comparison, not a statistical uncertainty interval. All cases use the laboratory cooling response, fixed coefficients and the same 25 C initial condition. These are not predictions of Z50 pack or core temperatures.','SmallB')
p(f"Reconstructed terminal energy: {audit['estimated_total_battery_terminal_energy_kWh']:.2f} kWh in 2 h ({100*audit['fraction_of_nominal_energy']:.2f}% of nominal capacity). No SOC limits, charging, swapping or thermal derating are enforced, so this is not an endurance forecast.",'SmallB')

page();h('3. What the method assumes and what must be checked')
h('Native-cycle linkage')
p('The source is the already executed RR03 road-condition case [3]: 3% assumed rolling resistance, 45 t payload, one truck and a nominal 1,500 m / 135 m-rise New Afton-informed route. The actual recorded loaded travel distance is about 1.652 km. This workflow uses recorded state times and work; it does not substitute the nominal length for the native event history.')
p('EnergyToWheels and EnergyFromWheels are interpreted as kWh. Net work on each of four complete loaded legs is 46.721 kWh, versus approximately 46.849 kWh from m g (h + C<sub>r</sub> L), a 0.274% difference. This supports the scale but does not replace documentation of the export-unit definition. Unit metadata confirmation remains a prerequisite for a publication claim about electrical energy.')
p('The event-average load uses 85% drive efficiency, 20 kW constant auxiliaries and no regeneration credit. These are assumptions. They give an equivalent cell current range of 0.141 to 2.244 A. Within-state peaks are lost: squaring average current generally understates average squared current. A more detailed current trace is needed for peak heating.')
h('Meaning of the temperature feature')
p('For the same initial temperature and current history, the model gives Delta T<sub>s</sub>(t) = [1 - exp(-b t)] Delta T<sub>a</sub>. Thus a 10 C increase in air produces almost a 10 C change after 2 h in this fitted model. This relation follows from the assumed linear heat balance; it is not a new physical law or evidence of actual Z50 cooling behaviour.')
p('Current-to-heat conversion omits reversible heat, temperature/SOC-dependent resistance, ageing, thermal gradients, hotspots and cooling control. The selected laboratory cell is not established as the Z50 cell. Matching chemistry and equivalent C-rate does not establish equivalent thermal response. Nominal energy/Ah implies 614.6 V only as a derived bookkeeping ratio, not a verified operating voltage.')
h('Data needed for a defensible Z50 result')
p('Obtain synchronized voltage, current, SOC, battery temperature channels and ambient/coolant temperatures during a mine haul cycle, together with pack configuration, cooling control/flow information, usable energy and protection settings. Preserve payload, grade, road condition, speed, dwell and charging/swap timestamps. Fit on one set of trips and evaluate on separate trips; include more than one truck or battery when possible.')
p('The accepted APCOM abstract concerns AI-based early thermal-runaway detection. This package supplies a normal-operation baseline and coupling method only. No runaway data, classifier, detection lead time or false-alarm result has been produced. The conference scope should be agreed with the supervisor before submission. Core thesis/journal methods remain outside this brief.','SmallB')

page();h('4. Draft text for the paper and source trail')
h('Methods draft')
p(methods,'SmallB')
h('Results and interpretation draft')
p(results,'SmallB')
h('References and reproducibility')
p('[1] Kawakita de Souza, Aloisio (2021). <i>Lithium-ion Battery OCV and Dynamic Test Data of a LiFePO4 cylindrical cell.</i> Mendeley Data, V1. <link href="https://doi.org/10.17632/p8kf893yv3.1" color="#176B9D">doi:10.17632/p8kf893yv3.1</link>. CC BY 4.0. Original raw measurements are preserved unchanged; this package adds an independently fitted reduced model and derived predictions.','SmallB')
p('Author data repository: <link href="https://github.com/aloisiohks/A123_26650_m1b_LAB_Dataset/tree/4fc9320c85f91317ace5d1bc9c40f53aaa2b1140" color="#176B9D">pinned GitHub source</link>, commit 4fc9320c85f91317ace5d1bc9c40f53aaa2b1140. The author\'s separate CET/EKF implementation was not used.','SmallB')
p('[2] Sandvik (n.d.). <i>Artisan Z50 specification sheet.</i> Battery table on PDF page 5; chemistry on pages 1 and 6. <link href="https://www.mining.sandvik/globalassets/products/underground-loaders-and-trucks/pdf/artisan-z50-specification-sheet-english.pdf" color="#176B9D">Official OEM specification</link>. No TH550B successor specifications were substituted.','SmallB')
p('[3] Local HAULSIM road-condition experiment, RR03, 15 October 2026. Native equipment-state export, database and reconciliation audit preserved in sources/native_RR03. Database SHA-256 begins e3907c0695cbea72; full hash appears in results/coupling_audit.json. Assumed road conditions on New Afton-informed geometry; not mine survey or telemetry.','SmallB')
p('Reproduce in order: code/fit_model.py, code/couple_cycle.py, code/build_brief.py. Source hashes, fitted coefficients, all prediction rows, event loads and checks are included. Original mine models and the independently reviewed APCOM paper package were not edited. See 00_START_HERE.txt for run instructions and evidence limits.','SmallB')

def footer(canvas,doc):
    canvas.saveState();canvas.setStrokeColor(colors.HexColor('#C4D1D8'));canvas.setLineWidth(.5)
    canvas.line(54,43,558,43);canvas.setFont('Helvetica',8);canvas.setFillColor(colors.HexColor('#4B6574'))
    canvas.drawString(54,30,'APCOM working evidence | Representative cell, not validated truck temperature')
    canvas.drawRightString(558,30,str(doc.page));canvas.restoreState()
pdf=PKG/'01_HAULSIM_Thermal_Methods_Brief.pdf'
doc=SimpleDocTemplate(str(pdf),pagesize=letter,rightMargin=72,leftMargin=72,topMargin=43,bottomMargin=58,
    title='HAULSIM cycle to battery temperature',author='Research working package',pageCompression=1)
doc.build(story,onFirstPage=footer,onLaterPages=footer)
pages=len(PdfReader(pdf).pages)
assert pages==5,f'Unexpected pagination: {pages}'

sources=[]
for f in sorted((PKG/'sources').rglob('*')):
    if f.is_file():sources.append({'file':str(f.relative_to(PKG)).replace('\\','/'),
        'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(RESULTS/'package_source_hashes.json').write_text(json.dumps(sources,indent=2))
versions={name:importlib.metadata.version(name) for name in ['numpy','scipy','matplotlib','reportlab','pypdf']}
(PKG/'code/requirements.txt').write_text('\n'.join(f'{k}=={v}' for k,v in versions.items())+'\n')
verification={'pdf_pages':pages,'versions':versions,'source_file_count':len(sources),
    'fit_record':model['fit_record'],'held_out_records':model['test_records'],
    'holdout_RMSE_C':[m['RMSE_C'] for m in metrics[1:]],'native_event_count':audit['native_rows_used'],
    'native_runtime_s':audit['native_runtime_s'],'calculation_checks':audit['checks'],
    'publication_status':'Preliminary surrogate analysis; not validated Z50 pack temperature or early detection',
    'visual_review':'Pending final PDF page render inspection'}
(RESULTS/'verification_summary.json').write_text(json.dumps(verification,indent=2))
print(json.dumps({'pdf':str(pdf),'pages':pages,'figures':3,'versions':versions},indent=2))
