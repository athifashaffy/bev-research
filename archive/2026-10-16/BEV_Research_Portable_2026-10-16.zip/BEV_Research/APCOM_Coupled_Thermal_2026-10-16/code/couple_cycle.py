"""Couple actual native event timing/work to a data-fitted representative cell.

One-way postprocessing only. This is NOT an OEM pack electrothermal model.
"""
from pathlib import Path
import csv,json,math,hashlib,sys
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parents[1] if Path(__file__).parent.name=='code' else ROOT/'APCOM_Coupled_Thermal_2026-10-16'
RESULTS=OUT/'results'
NATIVE=OUT/'sources/native_RR03'
if not NATIVE.exists():
    NATIVE=ROOT/'HAULSIM_Road_Surface_2026-10-15/results/RR03'
model=json.loads((RESULTS/'frozen_cell_model.json').read_text())
a=model['a_K_per_A2_s'];b=model['b_per_s']
eta=.85;aux=20.;energy=354.;cell_Ah=2.5;T0=25.

def advance(T,air,I,dt):
    equilibrium=air+a/b*I**2
    return equilibrium+(T-equilibrium)*math.exp(-b*dt)

def integrate(events,air,dt_max):
    T=T0;output=[{'time_s':0.,'surface_C_surrogate':T,'ambient_C_assumed':air,'cell_current_A_equivalent':events[0]['equivalent_cell_current_A'],'power_kW_estimated':events[0]['estimated_battery_power_kW'],'state':events[0]['state']}]
    for e in events:
        n=math.ceil(e['duration_s']/dt_max);dt=e['duration_s']/n
        for j in range(n):
            T=advance(T,air,e['equivalent_cell_current_A'],dt)
            output.append({'time_s':e['start_s']+(j+1)*dt,'surface_C_surrogate':T,'ambient_C_assumed':air,'cell_current_A_equivalent':e['equivalent_cell_current_A'],'power_kW_estimated':e['estimated_battery_power_kW'],'state':e['state']})
    return output

def write_csv(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def run():
    raw=json.loads((NATIVE/'HS_EquipmentState.json').read_text())
    raw=sorted([r for r in raw if r['Equipment']=='T_1'],key=lambda r:r['SimulationTime'])
    assert abs(raw[0]['SimulationTime'])<1e-10
    events=[];energy_check=[]
    for k,r in enumerate(raw):
        dt=r['ElapsedTime']*60
        assert dt>0
        if k:assert abs(raw[k-1]['SimulationTime']+raw[k-1]['ElapsedTime']-r['SimulationTime'])<1e-7
        wheel=r['EnergyToWheels'];brake=r['EnergyFromWheels']
        assert wheel>=0 and brake>=0
        power=wheel/(dt/3600)/eta+aux
        events.append({'native_row_id':r['Id'],'state':r['State'],'start_s':r['SimulationTime']*60,
            'duration_s':dt,'positive_wheel_energy_kWh_interpreted':wheel,
            'braking_energy_kWh_not_credited':brake,'estimated_battery_power_kW':power,
            'equivalent_C_rate_per_h':power/energy,
            'equivalent_cell_current_A':cell_Ah*power/energy})
        if r['State']=='TravelLoaded' and r['SimulationTime']+r['ElapsedTime']<119.999:
            # Independent order/units cross-check: local slopes reduce the cos term;
            # using path length in its place is a small upper approximation here.
            estimate=93148*9.81*(135+.03*r['DistanceTravelled']*1000)/3.6e6
            net=wheel-brake
            discrepancy=abs(net-estimate)/estimate
            assert discrepancy<.01
            energy_check.append({'native_row_id':r['Id'],'net_wheel_work_kWh_interpreted':net,
                 'mgh_plus_rolling_work_kWh_approx':estimate,'relative_discrepancy':discrepancy})
    assert len(energy_check)==4
    assert abs(events[-1]['start_s']+events[-1]['duration_s']-7200)<1e-7
    assert max(e['estimated_battery_power_kW'] for e in events)<480
    write_csv(RESULTS/'haulsim_event_load.csv',events)
    cases=[];all_traces=[]
    for air in [25.,35.,40.]:
        trace=integrate(events,air,1.)
        coarse=integrate(events,air,20.)
        assert abs(trace[-1]['surface_C_surrogate']-coarse[-1]['surface_C_surrogate'])<1e-9
        all_traces.extend(trace)
        cases.append({'ambient_C_assumed':air,'initial_cell_C_fixed':T0,
            'final_cell_surface_C_surrogate':trace[-1]['surface_C_surrogate'],
            'peak_cell_surface_C_surrogate':max(r['surface_C_surrogate'] for r in trace),
            'maximum_cell_minus_air_K_surrogate':max(r['surface_C_surrogate']-air for r in trace),
            'temperature_domain_note':'Extrapolation beyond held-out measured chamber range' if air==40 else 'Ambient sensitivity level; held-out nominal setpoints had measured means 26.12 and 36.72 C'})
    write_csv(RESULTS/'coupled_temperature_traces.csv',all_traces)
    write_csv(RESULTS/'coupled_temperature_cases.csv',cases)
    n=len(all_traces)//3
    ref=all_traces[:n]
    for group,ambient_delta in [(all_traces[n:2*n],10.),(all_traces[2*n:],15.)]:
        assert all(abs((r['surface_C_surrogate']-r0['surface_C_surrogate'])-
            ambient_delta*(1-math.exp(-b*r['time_s'])))<1e-9 for r,r0 in zip(group,ref))
    # Unit/limiting tests. Do not use the fitted thermal response as validation of the mine.
    assert abs(advance(30,30,0,300)-30)<1e-12
    expected=30+(25-30)*math.exp(-b*100)
    assert abs(advance(25,30,0,100)-expected)<1e-12
    T=25.;h=.1
    for _ in range(1000):T+=h*(a*3**2-b*(T-35))
    assert abs(T-advance(25,35,3,100))<.001
    total=sum(e['estimated_battery_power_kW']*e['duration_s']/3600 for e in events)
    positive=sum(e['positive_wheel_energy_kWh_interpreted'] for e in events)
    assert abs(total-(positive/eta+aux*2))<1e-8
    frozen_native=json.loads((NATIVE/'audit_summary.json').read_text())
    db=NATIVE/'New_Afton_A_RR03.hsmdb'
    assert hashlib.sha256(db.read_bytes()).hexdigest()==frozen_native['archive_sha256']
    audit={'classification':'HAULSIM-driven representative laboratory-cell sensitivity; NOT Z50 pack validation',
      'coupling':'Native event times and positive wheel-energy exports -> event-average estimated battery power -> equivalent cell C-rate -> frozen laboratory surface-temperature model',
      'formulas':['P_batt,k = E_wheel_positive,k / (duration_k_hours * eta_drive) + P_aux',
         'I_cell,k = Q_cell_Ah * P_batt,k_kW / E_pack_nominal_kWh',
         'dTs/dt = a*I_cell^2 - b*(Ts-Tair)'],
      'assumptions':{'drive_efficiency':eta,'constant_auxiliary_power_kW':aux,'nominal_pack_energy_kWh':energy,
        'nominal_pack_Ah_OEM':576,'nominal_energy_over_capacity_voltage_V_derived':354000/576,
        'equivalent_cell_Ah':cell_Ah,'initial_cell_temperature_C':T0,'regeneration_fraction':0.,
        'within_state_current':'constant event average; not RMS or measured instantaneous current'},
      'mechanical_units':'EnergyToWheels/FromWheels interpreted as kWh; checked against loaded mgh + rolling work to <1%. Export field metadata does not independently document units; retain this as a verification prerequisite.',
      'native_energy_scale_crosscheck':energy_check,
      'native_rows_used':len(events),'native_runtime_s':7200,
      'native_source_sha256':hashlib.sha256(db.read_bytes()).hexdigest(),
      'estimated_total_battery_terminal_energy_kWh':total,
      'fraction_of_nominal_energy':total/energy,
      'equivalent_current_min_max_A':[min(e['equivalent_cell_current_A'] for e in events),max(e['equivalent_cell_current_A'] for e in events)],
      'checks':['PASS: contiguous native time, exact 7200 s','PASS: source database unchanged',
        'PASS: ambient sensitivity equals 1-exp(-b*t) at all output timestamps',
        'PASS: four complete loaded-leg energy scale cross-checks <1%',
        'PASS: all event-average terminal powers below 480 kW; instantaneous peak not verified',
        'PASS: positive-wheel-work plus auxiliaries reconciles estimated energy',
        'PASS: thermal step-partition invariance, zero-load equilibrium and independent Euler check'],
      'limitations':['Native battery-energy/SOC outputs are disabled; electrical load is external reconstruction, not measured pack current.',
        'State averaging loses load peaks; square of average current generally underestimates mean I squared. No peak-current or protection claim.',
        'No charge, swap, temperature derating or thermal feedback to HAULSIM. Nominal energy is not usable energy; no endurance prediction.',
        'The laboratory cell type and cooling are not identified as the cells/cooling used in Z50. No pack-scale C or UA is inferred.',
        'Nominal-voltage/C-rate equivalence ignores voltage sag, SOC dependence, series/parallel imbalance and cell ageing.',
        'Fitted coefficients held temperature independent; 40 C is thermal extrapolation beyond the measured held-out air temperatures.',
        'The one-node model predicts surface temperature, not pack bulk/core temperature, local hotspots, runaway, or detector performance.'],
      'cases':cases}
    (RESULTS/'coupling_audit.json').write_text(json.dumps(audit,indent=2))
    print(json.dumps(audit,indent=2))

if __name__=='__main__':run()
