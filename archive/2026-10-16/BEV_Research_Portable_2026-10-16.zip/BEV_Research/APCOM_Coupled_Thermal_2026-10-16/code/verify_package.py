"""Cross-check delivered tables, original-source hashes and rendered-brief status."""
from pathlib import Path
import sys,csv,json,math,hashlib,argparse
from pypdf import PdfReader
PKG=Path(__file__).resolve().parents[1]
def read_csv(p):
    with p.open(newline='') as f:return list(csv.DictReader(f))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
parser=argparse.ArgumentParser()
parser.add_argument('--confirm-visual-review',action='store_true',help='Use only after inspecting all five rendered PDF pages.')
args=parser.parse_args()
for item in json.loads((PKG/'results/package_source_hashes.json').read_text()):
    assert sha(PKG/item['file'])==item['sha256']
metrics=json.loads((PKG/'results/record_metrics.json').read_text())
record_counts={}
for m in metrics:
    rows=read_csv(PKG/'results'/m['file'].replace('.mat','_prediction.csv'))
    dt=[float(rows[j]['time_s'])-float(rows[j-1]['time_s']) for j in range(1,len(rows))]
    err=[float(r['predicted_surface_C'])-float(r['measured_surface_C']) for r in rows[1:]]
    rmse=math.sqrt(math.fsum(h*e*e for h,e in zip(dt,err))/math.fsum(dt))
    assert abs(rmse-m['RMSE_C'])<1e-12
    record_counts[m['file']]=len(rows)
events=read_csv(PKG/'results/haulsim_event_load.csv')
assert len(events)==29
assert abs(math.fsum(float(r['duration_s']) for r in events)-7200)<1e-7
native=PKG/'sources/native_RR03'
orig=PKG.parent/'HAULSIM_Road_Surface_2026-10-15/results/RR03'
original_check='Not available in this portable copy'
if orig.exists():
    for name in ['New_Afton_A_RR03.hsmdb','HS_EquipmentState.json','audit_summary.json']:
        assert sha(native/name)==sha(orig/name)
    original_check='PASS: packaged database, events and native audit match original files'
pdf=PKG/'01_HAULSIM_Thermal_Methods_Brief.pdf'
reader=PdfReader(pdf)
assert len(reader.pages)==5
assert all(len(p.extract_text())>400 for p in reader.pages)
status_path=PKG/'results/verification_summary.json'
status=json.loads(status_path.read_text())
status['table_metric_recalculation']='PASS: all three RMSEs recomputed from delivered prediction rows'
status['prediction_row_counts']=record_counts
status['original_source_comparison']=original_check
status['brief_sha256']=sha(pdf)
status['visual_review']='PASS: all five rendered pages inspected; no clipping, overlap or missing equation glyphs' if args.confirm_visual_review else 'Not confirmed by this verification invocation'
status_path.write_text(json.dumps(status,indent=2))
print(json.dumps(status,indent=2))
