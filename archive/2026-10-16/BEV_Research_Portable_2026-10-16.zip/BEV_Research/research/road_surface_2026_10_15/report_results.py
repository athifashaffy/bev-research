"""Write a professor-readable results note from audited native outputs only."""
from pathlib import Path
import json, html
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'HAULSIM_Road_Surface_2026-10-15'
rows=[json.loads((OUT/'results'/tag/'audit_summary.json').read_text()) for tag in ['RR02','RR03','RR04']]
assert all(r['status']=='EXECUTED_NATIVE_AND_RECONCILED' for r in rows)
cycle_delta=rows[-1]['mean_complete_cycle_min']-rows[0]['mean_complete_cycle_min']
travel_delta=rows[-1]['mean_complete_loaded_travel_min']-rows[0]['mean_complete_loaded_travel_min']
cycle_pct=100*cycle_delta/rows[0]['mean_complete_cycle_min']
travel_pct=100*travel_delta/rows[0]['mean_complete_loaded_travel_min']
lines=['NEW AFTON-INFORMED UNDERGROUND HAULAGE EXPERIMENT',
'Executed in native HAULSIM 3.8 build 585 on 15 October 2026. Preliminary sensitivity study.',
'', 'QUESTION', 'With the same truck, load and route, how does underground road rolling resistance affect haulage time?',
'', 'WHAT WAS RUN',
'Three separate 120-minute experiments; one replication each. One historical Z50-inspired truck proxy, 45 t payload, 1500 m road network and 135 m rise. Assumed alignment, not a surveyed mine model. Rolling resistance alone varies at 2%, 3%, 4%; these are assumed levels, not measured New Afton conditions.',
'Common inputs: 391 kW assumed wheel-traction ceiling; 300 kN low-speed force cap; 440 kW assumed retarder; loaded/empty caps 10/14 km/h; 4 min loading service including loader spotting, 1 min unloading plus separate dump spotting. Ground structure class 0 and traction coefficient 0.6 stay fixed.',
'', 'NATIVE RESULTS',
'Resistance | Complete cycle (min) | Loaded travel (min) | Delivered in 120 min',]
for r in rows: lines.append(f"{r['rolling_resistance_percent']}% | {r['mean_complete_cycle_min']:.4f} | {r['mean_complete_loaded_travel_min']:.4f} | {r['delivered_t']:.0f} t ({r['completed_loads']} loads)")
lines+=['',f'Increasing resistance from 2% to 4% increases complete cycle time by {cycle_delta:.4f} min ({cycle_pct:.2f}%) and loaded travel time by {travel_delta:.4f} min ({travel_pct:.2f}%).',
'Cycle time is the mean interval between successive completed unloads (three complete intervals per case), excluding startup. Loaded travel is the mean of complete TravelLoaded records associated with delivered loads; station spotting is separate.',
'All three runs deliver 180 t (90 t/h over this particular two-hour window). This equal tonnage does not imply equal performance: the finite cutoff masks the cycle-time difference. Each run loads 225 t; 45 t remains undelivered at cutoff. In RR02 the final unloading event is truncated at 0.98503 min, so its 45 t must not be counted as completed delivery.',
'', 'FORMULA AND INTERPRETATION',
'F = m*g*(sin(theta) + Cr*cos(theta)); P_wheel = F*v.',
'Cr is rolling resistance as a fraction (0.02, 0.03, 0.04), theta is local road angle, m is gross truck mass and v is speed. Increasing Cr increases force at the same speed; with a fixed power ceiling the truck may slow. This is a standard force balance, not a new scientific equation. Native HAULSIM also applies speed limits, acceleration, manoeuvres and retarding behaviour.',
'The 16% grade is a local ramp-segment design input, not the route-average grade. The model alignment is assumed and native station manoeuvre paths add distance outside the 1500 m road network.',
'', 'CHECKS AND LIMITS',
'PASS: each native database is readable; resistance and 391 kW traction inputs retained; 45 t payload and energy-disabled configuration retained; continuous truck timeline covers exactly 120 min; completed unload tonnes equal material movement tonnes and native experiment totals. Original source model hash is unchanged.',
'The raw material movement table has zero-valued time/distance fields: use it for quantity reconciliation only. Use HS_EquipmentState for timing.',
'No uncertainty interval: one deterministic replication per level, not three independent mine observations. Do not extrapolate these small differences to an annual production forecast without longer runs and calibration.',
'Native battery energy, charging and regeneration are disabled. Zero battery output fields mean disabled, not zero battery consumption. No temperature, fire probability, thermal-runaway detection or sensor-fusion accuracy has been demonstrated.',
'The earlier 440 kW traction baseline and older 400 kWh demo runs are not included in this comparison. This study uses 391 kW consistently across all three cases.',
'', 'WHAT TO TELL THE PROFESSOR',
'I ran three controlled native HAULSIM experiments on a New Afton-informed underground route. Higher assumed road resistance increased cycle time, while the short-run load count stayed unchanged. I propose using the duty-cycle outputs as operating context for a separately calibrated battery thermal model. These results do not yet demonstrate early thermal-runaway detection.',
'Ask the supervisor to approve the assumed resistance range, historical vehicle proxy, wheel-power assumptions and route representation, and to identify measurements for calibration. The accepted early-detection paper still needs a defensible connection to sensors; these haulage results alone do not satisfy that claim.',
'', 'FILES',
'results/scenario_comparison.csv: comparison table.',
'results/RR02, RR03, RR04: native database snapshots, raw CSV/JSON exports, audit summaries.',
'models/RR02, RR03, RR04: native runnable projects.',
'study_manifest.json: assumptions, provenance and executed status.',
'The previously QA-reviewed APCOM paper and research plan were not changed by this experiment.']
text='\n'.join(lines)+'\n'
(OUT/'01_Experiment_Results.txt').write_text(text,encoding='utf-8')
table=''.join(f"<tr><td>{r['rolling_resistance_percent']}%</td><td>{r['mean_complete_cycle_min']:.2f}</td><td>{r['mean_complete_loaded_travel_min']:.2f}</td><td>{r['delivered_t']:.0f} t</td></tr>" for r in rows)
body=''.join('<p>'+html.escape(line)+'</p>' for line in lines[16:] if line)
page=f'''<!doctype html><html lang="en"><meta charset="utf-8"><title>Underground road-condition experiment</title><style>body{{font:17px/1.6 system-ui,sans-serif;max-width:950px;margin:40px auto;padding:0 25px;color:#173040}}h1{{line-height:1.2}}.lead{{background:#eaf5f4;padding:20px;border-left:5px solid #167d8d}}table{{border-collapse:collapse;width:100%;margin:24px 0}}th,td{{text-align:left;padding:12px;border-bottom:1px solid #cbd6da}}th{{background:#173040;color:white}}p{{margin:14px 0}}@media print{{body{{font-size:11pt;margin:20px}}}}</style><h1>Underground road-condition experiment</h1><p>Native HAULSIM 3.8 • 15 October 2026 • New Afton-informed assumed route</p><div class="lead"><b>Higher rolling resistance increased cycle time by {cycle_pct:.2f}%.</b><br>Three completed native experiments. Same truck, route and payload; resistance varied from 2% to 4%.</div><table><thead><tr><th>Resistance</th><th>Cycle time, min</th><th>Loaded travel, min</th><th>Delivered / 2 h</th></tr></thead><tbody>{table}</tbody></table><p>One truck; 45 t payload; 1,500 m road network; 135 m rise; assumed 391 kW wheel traction; one 120-minute replication per case. Resistance levels are assumptions, not measured mine conditions.</p>{body}</html>'''
(OUT/'01_Experiment_Results.html').write_text(page,encoding='utf-8')
with (OUT/'00_START_HERE.txt').open('a',encoding='utf-8') as f:
    f.write('\nRUN STATUS: All three native experiments executed and reconciled. Read 01_Experiment_Results.html or .txt. Battery and thermal performance remain outside the validated scope.\n')
print(json.dumps({'cycle_increase_percent':cycle_pct,'loaded_travel_increase_percent':travel_pct,'report':str(OUT/'01_Experiment_Results.html')},indent=2))
