"""One-factor illustrative thermal calculation, not HAULSIM battery output.

Uses previously declared C, UA and Q assumptions. Ambient is the sole varied
input; initial battery temperature is fixed at 25 C for all three cases.
"""
from pathlib import Path
import csv, json, math, hashlib, sys

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'BEV_Temperature_Feature_2026-10-16'
OUT.mkdir(exist_ok=True)
C=4e6; UA=400.; Q=5000.; T0=25.; DURATION=7200.
native=ROOT/'HAULSIM_Road_Surface_2026-10-15/results/RR03/audit_summary.json'
native_summary=json.loads(native.read_text())
assert native_summary['runtime_min']==DURATION/60
source=ROOT/'APCOM_Research_2026-10-15/calculations/calculation_audit.json'
prior=json.loads(source.read_text())
assert prior['inputs']['thermal_C_J_per_K_assumed']==C
assert prior['inputs']['thermal_heat_W_assumed']==Q
assert UA in [r['UA_W_per_K'] for r in prior['thermal_timescales']]

def exact(t, air, initial=T0, heat=Q, conductance=UA, capacitance=C):
    if conductance==0:return initial+heat*t/capacitance
    eq=air+heat/conductance
    return eq+(initial-eq)*math.exp(-conductance*t/capacitance)

def euler(air, step):
    temp=T0
    for _ in range(round(DURATION/step)):
        temp+=step*(Q-UA*(temp-air))/C
    return temp

summary=[]; traces=[]; checks={}
for air in [25.,35.,40.]:
    end=exact(DURATION,air)
    errors=[abs(euler(air,dt)-end) for dt in [10.,1.]]
    assert errors[1]<errors[0] and errors[1]<0.001
    trace=[{'ambient_C_assumed':air,'time_s':t,'battery_bulk_C_illustrative':exact(t,air)} for t in range(0,7201,10)]
    traces.extend(trace)
    # Check the differential equation independently using a central difference.
    max_residual=0.
    for t in [1.,600.,3600.,7199.]:
        h=.1; derivative=(exact(t+h,air)-exact(t-h,air))/(2*h)
        residual=abs(C*derivative-(Q-UA*(exact(t,air)-air)))
        max_residual=max(max_residual,residual)
    assert max_residual<0.001
    summary.append({'ambient_C_assumed':air,'initial_battery_C_fixed':T0,
        'battery_bulk_C_at_120_min_illustrative':end,
        'battery_bulk_C_max_over_120_min_illustrative':max(r['battery_bulk_C_illustrative'] for r in trace),
        'equilibrium_C_if_assumptions_persist':air+Q/UA,
        'euler_10s_error_C':errors[0],'euler_1s_error_C':errors[1],
        'maximum_ODE_residual_W':max_residual})
assert exact(0,40)==T0
assert exact(7200,25,heat=0)==25
assert exact(7200,40,conductance=0)==34
sensitivity=1-math.exp(-UA*DURATION/C)
assert abs((summary[2]['battery_bulk_C_at_120_min_illustrative']-summary[0]['battery_bulk_C_at_120_min_illustrative'])/15-sensitivity)<1e-12
checks={'analytical_solution_vs_independent_euler':'PASS; all 1 s endpoint errors < 0.001 C and below 10 s errors',
        'differential_equation_residual':'PASS; central-difference energy-balance residual < 0.001 W',
        'fixed_initial_condition':'PASS; 25 C in all cases',
        'zero_heat_at_equilibrium':'PASS', 'insulated_limit':'PASS',
        'ambient_sensitivity_identity':'PASS', 'thermal_time_constant_s':C/UA,
        'dTb_dTair_at_120_min':sensitivity}
for filename,rows in [('temperature_cases.csv',summary),('temperature_traces.csv',traces)]:
    with (OUT/filename).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
report={'classification':'ILLUSTRATIVE_THERMAL_SOLVER_TEST; NOT FIELD VALIDATED; NOT HAULSIM BATTERY OUTPUT',
        'formula':'C_th*dTb/dt = Q_battery - UA*(Tb-Tair)',
        'analytical_solution':'Tb(t)=Tair+Q/UA+(T0-Tair-Q/UA)*exp(-UA*t/C_th)',
        'fixed_inputs':{'C_th_J_per_K_assumed':C,'UA_W_per_K_assumed':UA,'Q_battery_W_assumed_constant':Q,
                        'T0_C_fixed':T0,'duration_s':DURATION,'active_refrigeration_W':0},
        'varied_input':'Tair = 25, 35, 40 C; sensitivity levels, not measured New Afton conditions',
        'relationship_to_haulsim':'Uses the same 120-minute duration as native RR03 only. Q is NOT derived from its duty cycle. No thermal feedback to HAULSIM. Full workload coupling remains unimplemented pending heat-generation evidence.',
        'native_reference':str(native.relative_to(ROOT)),
        'prior_parameter_source':str(source.relative_to(ROOT)),
        'prior_parameter_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'checks':checks,'cases':summary}
(OUT/'verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')

# Standard scientific plotting library from the already installed project tools.
sys.path.insert(0,str(ROOT/'research/haulsim_detail/tools'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,ax=plt.subplots(figsize=(9,5.6),layout='constrained')
for air,color in zip([25.,35.,40.],['#176d9c','#b26a18','#a63e45']):
    data=[r for r in traces if r['ambient_C_assumed']==air]
    ax.plot([r['time_s']/60 for r in data],[r['battery_bulk_C_illustrative'] for r in data],label=f'Air {air:.0f} °C (assumed)',color=color,lw=2.2)
ax.set(xlabel='Elapsed time (min)',ylabel='Illustrative bulk battery temperature (°C)',xlim=(0,120),ylim=(24,42))
ax.grid(alpha=.2);ax.legend(loc='upper left');ax.spines[['top','right']].set_visible(False)
fig.suptitle('One varied feature: mine air temperature',fontsize=15,fontweight='bold')
ax.set_title('Fixed initial battery 25 °C • Q = 5 kW • C = 4 MJ/K • UA = 400 W/K\nAssumed thermal inputs; not HAULSIM battery output or a mine prediction',fontsize=10,pad=12)
fig.savefig(OUT/'temperature_feature.png',dpi=180);plt.close(fig)

text='''TEMPERATURE AS ONE RESEARCH FEATURE - 16 OCTOBER 2026

Research question: For an unchanged underground haul duty cycle, how does mine air temperature affect normal battery bulk temperature?

The sole varied feature is ambient mine air temperature: 25, 35 and 40 C.
Battery bulk temperature is the response, not another input being varied.

STANDARD EQUATION
C_th dTb/dt = Q_battery(t) - UA (Tb - Tair)
C_th: thermal capacitance [J/K]; Tb: bulk battery temperature [C].
Q_battery: internal battery heat generation [W]; UA: effective heat-transfer conductance [W/K].
Tair: surrounding air temperature [C]; time in seconds.
This is established energy conservation, not a novel equation. This simplified case has no separate active refrigeration and no cell-level hotspots or runaway reaction heat.

ACTUAL TEST EXECUTED HERE
Three analytical temperature trajectories with an independent numerical check. All start at the SAME 25 C. C=4 MJ/K, Q=5 kW constant and UA=400 W/K are illustrative assumptions from the existing research draft. They are not calibrated Z50 parameters. Only Tair changes.
The 120-minute duration matches the native HAULSIM RR03 experiment; the heat input does NOT come from HAULSIM. This tests the equation, not a completed coupling. No new HAULSIM run was necessary or performed for these calculations.

NEXT STEP TO CONNECT HAULSIM
1. Hold the native RR03 route, resistance, payload and truck fixed.
2. Export the loaded, empty, loading, dumping and idle schedule (already available).
3. Obtain/validate battery current or a battery electrical model for those states, then calculate heat generation. I(t)^2 R is a first resistive-heating approximation, with additional reversible and other heat terms assessed as appropriate. Driving losses are not automatically battery heat.
4. Feed that heat history into the equation and vary ONLY ambient temperature. If the real truck uses liquid cooling, use measured coolant conditions and cooling-control behaviour rather than assuming direct air cooling.
5. Compare predicted temperatures against separate measured normal-duty recordings. State the spatial limitation: bulk pack temperature may miss a local hotspot.
6. Only after validation, use the predicted normal-temperature baseline to investigate abnormal sensor behaviour. No fire probability or early-warning accuracy has been tested here.

WHY THE NUMBERS ARE NOT MINE TEMPERATURE PREDICTIONS
No measured battery heat generation, thermal capacitance, cooling map, or matched pack-temperature record is available for this native model. The plotted difference is a consequence of the assumed heat balance. For these fixed coefficients, dTb/dTair = 1-exp(-UA*t/C), so much of the trend is built into the equation. Quantifying that assumed trend alone is not a strong scientific novelty. If instead every case started at its own air temperature, the curves would simply be vertical shifts under the constant-Q model.

MINE CHOICE
Keep New Afton for the operational case unless another mine can provide better route and battery data. A reported fire by itself does not supply a calibration dataset.
Use Macassa and Onaping/Craig as separate incident evidence. Macassa's underground August 2022 event was a damaged battery connection and explicitly not thermal runaway; its other listed events were on surface. Do not reclassify those events as underground haul-cycle overheating or claim to reproduce them with this model.

SENSOR DATA STATUS
The existing Shen laboratory files have no explicit event-onset labels or independent normal-duty recordings. Earlier audits show repeated minute-resolution times in 24A and 447 missing temperature rows in 40A. The Downloads/Dataset folder is a HAULSIM Open Cut teaching dataset, not mine battery-temperature telemetry. No detector has been trained or validated in this pass.

SOURCES
NREL, Battery Lifetime Analysis: https://www.nrel.gov/docs/fy15osti/63246.pdf
NREL, Battery Pack Thermal Design: https://www.nrel.gov/docs/fy16osti/66960.pdf
Macassa operator report: https://www.workplacesafetynorth.ca/sites/default/files/2024-02/Agnico-Eagle-BEV-Equipment-Fires-Case-Studies-2024.pdf
Onaping incident presentation landing page: https://www.workplacesafetynorth.ca/en/resource/incident-summary-onaping-depth-bev-fire
Laboratory dataset: https://data.mendeley.com/datasets/8zjttd77my/1

FILES
temperature_feature.png: assumed temperature trajectories.
temperature_cases.csv and temperature_traces.csv: calculated endpoints and traces.
verification.json: inputs, limitations and mathematical checks.
The existing APCOM documents and native HAULSIM models were not edited.
'''
(OUT/'00_READ_FIRST.txt').write_text(text,encoding='utf-8')
print(json.dumps(report,indent=2))
