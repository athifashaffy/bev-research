"""Prepare isolated native road-resistance cases; never fabricate native results."""
from pathlib import Path
import hashlib, json, math, shutil, sqlite3, uuid
from lxml import etree as ET

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'HAULSIM_Road_Surface_2026-10-15'
SOURCE=ROOT/'models/haulsim/new_afton/ready_to_run/New_Afton_Route_A.hsmdb'
BASE_HASH=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
POWER_KW=(480-20)*0.85
GUID=str(uuid.uuid5(uuid.NAMESPACE_URL,'new-afton-route-a-road-resistance-391kw-2026-10-15'))
OUT.mkdir(exist_ok=True)
cases=[]
def set_text(root,path,value):
    node=root.find(path)
    assert node is not None,path
    node.text=str(value)

for rr in (2,3,4):
    tag=f'RR{rr:02d}'
    folder=OUT/'models'/tag
    folder.mkdir(parents=True,exist_ok=True)
    dest=folder/f'New_Afton_A_{tag}.hsmdb'
    if dest.exists():raise RuntimeError(f'Preserve existing scenario: {dest}')
    with sqlite3.connect(SOURCE.as_uri()+'?mode=ro',uri=True) as source:
        with sqlite3.connect(dest) as target:source.backup(target)
    shutil.copy2(SOURCE.with_suffix('.hsm'),dest.with_suffix('.hsm'))
    with sqlite3.connect(dest) as con:
        con.row_factory=sqlite3.Row
        con.execute('UPDATE NetworkArc SET RollingResistance=?',(rr,))
        row=con.execute('SELECT * FROM TruckType WHERE TruckTypeId=1').fetchone()
        xml=ET.fromstring(row['XmlContent'].encode('utf-8'))
        truck=xml.find('.//truck');truck.set('guid',GUID)
        for path,value in {
            'model':'New Afton Z50 road-study proxy',
            'desc':'45 t operating load; 391 kW wheel-power assumption; no battery-energy outputs',
            'specs':'480 kW battery limit, 20 kW auxiliaries and 0.85 drive efficiency imply 391 kW traction. Retarder remains a separate 440 kW proxy. Not OEM calibrated.',
            'engines/engine/name':'Assumed 391 kW wheel-power proxy',
            'engines/engine/gross_power':POWER_KW,
            'engines/engine/net_power':POWER_KW,
        }.items():set_text(truck,path,value)
        # Native library force ordinate is kilogram-force; use standard g for unit conversion.
        curve=','.join(f'{v:.1f} {min(300000,POWER_KW*1000/max(v/3.6,1e-9))/9.80665:.8f}' for v in [i/10 for i in range(141)])
        set_text(truck,'rimpulls/graph/linestring',curve)
        con.execute('UPDATE TruckType SET XmlContent=?,EquipmentGuid=?,Description=? WHERE TruckTypeId=1',
                    (ET.tostring(xml,encoding='unicode'),GUID,'New Afton Z50 road-study proxy - 391 kW assumption'))
        con.execute('UPDATE HS_TruckType SET MotorPower=?,EquipmentReferenceGuid=? WHERE ID=1',(POWER_KW,GUID))
        con.execute('UPDATE HS_ExperimentDetail SET RunTime=120,Replications=1,Description=?',(f'New Afton underground Route A {tag} - 120 minutes',))
        con.execute('UPDATE HS_ExperimentScenario SET Haulers=1,SpeedFactor=1,LoadTimeFactor=1,DumpTimeFactor=1,Description=?',(f'{tag} road resistance only',))
        assert con.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        tables=[r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        result_counts={t:con.execute('SELECT count(*) FROM "'+t.replace('"','""')+'"').fetchone()[0] for t in tables if any(x in t.lower() for x in ['result','equipmentstate','materialmovement','simulationrun','replication'])}
        assert all(n==0 for n in result_counts.values()),result_counts
        arcs=list(con.execute('SELECT * FROM NetworkArc'))
        assert len(arcs)==51 and all(a['RollingResistance']==rr and a['GroundStructure']==0 for a in arcs)
        assert abs(sum(a['Length'] for a in arcs)-1500)<1e-7
        assert con.execute('SELECT count(*) FROM HS_Truck').fetchone()[0]==1
        assert con.execute('SELECT Payload FROM HS_Truck').fetchone()[0]==45
        assert con.execute('SELECT LastPassPercent FROM HS_LoaderType').fetchone()[0]==0
        cfg=ET.fromstring(row['ConfigurationXml'].encode())
        assert cfg.findtext('UserDefinedCapacity')=='true'
        assert cfg.findtext('EquipmentEnergyProperty/EnableElectricEnergy')=='false'
        assert float(cfg.findtext('EquipmentEnergyProperty/EnergyCapacity'))==0
        con.commit()
    cases.append({'case':tag,'rolling_resistance_percent':rr,'model_hsm':str(dest.with_suffix('.hsm').relative_to(ROOT)),
                  'model_database':str(dest.relative_to(ROOT)),'input_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),
                  'status':'PREPARED - native run pending','pre_run_result_table_counts':result_counts})

assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==BASE_HASH
# Across cases, physical inputs must differ only in rolling resistance.
allowed={'NetworkArc','HS_ExperimentDetail','HS_ExperimentScenario','sqlite_sequence'}
connections=[sqlite3.connect((ROOT/c['model_database']).as_uri()+'?mode=ro',uri=True) for c in cases]
for (table,) in connections[0].execute("SELECT name FROM sqlite_master WHERE type='table'"):
    q='"'+table.replace('"','""')+'"'
    if table in allowed:continue
    values=[c.execute('SELECT * FROM '+q+' ORDER BY rowid').fetchall() for c in connections]
    assert values[0]==values[1]==values[2],table
for con in connections:con.close()

manifest={'study':'New Afton-informed underground road rolling-resistance sensitivity',
 'source_model':str(SOURCE.relative_to(ROOT)),'source_sha256':BASE_HASH,
 'cases':cases,'common_inputs':{'route_length_m':1500,'rise_m':135,'nominal_steep_grade':0.16,'empty_mass_kg':48148,
 'payload_t':45,'duration_min':120,'replications':1,'load_min':4,'dump_min':1,'loaded_speed_cap_kmh':10,
 'empty_speed_cap_kmh':14,'wheel_traction_power_kw_assumed':POWER_KW,'low_speed_force_cap_kN_assumed':300,
 'battery_continuous_power_kw_from_historical_spec':480,'auxiliaries_kw_assumed':20,'drive_efficiency_assumed':0.85,
 'retarder_power_kw_assumed':440,'traction_coefficient_assumed':0.6,'ground_structure_class':0},
 'source_limitations':['Route aggregates are public; alignment is assumed, not surveyed.',
 'Rolling resistances 2/3/4 percent are sensitivity levels, not measured New Afton road conditions.',
 'Ground structure (roughness-related speed restriction) is fixed at 0 to isolate resistance; vibration and impacts are not simulated.',
 'Wheel traction ceiling is derived with assumed efficiency/auxiliaries; no OEM torque-speed or retarder validation.',
 'Native battery energy, regeneration and recharging remain disabled. Outputs cannot establish battery endurance, temperature or detection accuracy.',
 'Native station manoeuvre paths can add travel distance beyond the 1500 m road network.'],
 'native_help':['HAULSIM 3.8 Help/en/Content/Haul Route Analysis/HaulRoute.htm','HAULSIM 3.8 Help/en/Content/General Concepts/GroundStructure.htm'],
 'preflight':'PASS - integrity, common-input identity, payload policy, preserved source, and empty result tables'}
(OUT/'study_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
(OUT/'00_START_HERE.txt').write_text('NEW AFTON UNDERGROUND ROAD-CONDITION STUDY\n\nThree native model copies vary rolling resistance at 2%, 3% and 4%.\nEach case is a two-hour, one-truck haulage experiment with a 45 t payload scenario.\nA common assumed 391 kW wheel-traction ceiling replaces the earlier 440 kW proxy.\nNo measured road class is assigned to these assumed percentages.\nGround-structure speed restrictions, traction coefficient and route geometry are held fixed.\nNative battery energy is disabled: no battery endurance, temperature, runaway or detection result is implied.\nSee study_manifest.json for inputs and run status. Original models and October 9 results are preserved.\n',encoding='utf-8')
print(json.dumps({'prepared':len(cases),'power_kw':POWER_KW,'preflight':manifest['preflight'],'output':str(OUT)},indent=2))
