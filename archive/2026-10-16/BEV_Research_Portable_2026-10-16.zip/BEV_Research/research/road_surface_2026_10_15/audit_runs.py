"""Archive and independently reconcile completed native HAULSIM experiments."""
from pathlib import Path
import csv, hashlib, json, sqlite3, statistics, shutil, sys
from lxml import etree as ET

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'HAULSIM_Road_Surface_2026-10-15'
manifest=json.loads((OUT/'study_manifest.json').read_text())
summaries=[]
for case in manifest['cases']:
    tag=case['case']
    if len(sys.argv)>1 and tag not in sys.argv[1:]: continue
    source=ROOT/case['model_database']
    folder=OUT/'results'/tag
    with sqlite3.connect(source.as_uri()+'?mode=ro',uri=True) as con:
        assert con.execute('select count(*) from HS_ExperimentResult').fetchone()[0]==1, f'{tag}: no single completed run'
        folder.mkdir(parents=True,exist_ok=True)
        archive=folder/source.name
        if not archive.exists():
            with sqlite3.connect(archive) as dest: con.backup(dest)
            shutil.copy2(source.with_suffix('.hsm'),archive.with_suffix('.hsm'))
    con=sqlite3.connect(archive);con.row_factory=sqlite3.Row
    assert con.execute('pragma integrity_check').fetchone()[0]=='ok'
    arcs=list(con.execute('select * from NetworkArc'))
    assert len(arcs)==51 and all(r['RollingResistance']==case['rolling_resistance_percent'] and r['GroundStructure']==0 for r in arcs)
    assert abs(sum(r['Length'] for r in arcs)-1500)<1e-7
    truck=con.execute('select * from TruckType where TruckTypeId=1').fetchone()
    cfg=ET.fromstring(truck['ConfigurationXml'].encode())
    assert cfg.findtext('UserDefinedCapacity')=='true'
    assert cfg.findtext('EquipmentEnergyProperty/EnableElectricEnergy')=='false'
    assert con.execute('select MotorPower from HS_TruckType').fetchone()[0]==391
    xml=ET.fromstring(truck['XmlContent'].encode())
    native_truck=xml.find('.//truck')
    assert float(native_truck.findtext('engines/engine/net_power'))==391
    for point in native_truck.findtext('rimpulls/graph/linestring').split(','):
        speed,force_kgf=map(float,point.split())
        assert abs(force_kgf*9.80665-min(300000,391000/max(speed/3.6,1e-9)))<1e-4
    assert con.execute('select Payload from HS_Truck').fetchone()[0]==45
    detail=con.execute('select * from HS_ExperimentDetail').fetchone()
    assert detail['RunTime']==120 and detail['Replications']==1
    records={}
    for table in ['HS_EquipmentState','HS_MaterialMovement','HS_ExperimentResult']:
        rows=[dict(r) for r in con.execute('select * from '+table)]
        assert rows,table
        records[table]=rows
        (folder/(table+'.json')).write_text(json.dumps(rows,indent=2))
        with (folder/(table+'.csv')).open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    events=sorted((r for r in records['HS_EquipmentState'] if r['Equipment']=='T_1'),key=lambda r:r['SimulationTime'])
    unload_events=[r for r in events if r['State']=='Unloading']
    # HAULSIM records full payload on an unload truncated by the runtime cutoff.
    # Delivery is counted only after the configured 1-minute unload finishes.
    unloads=[r for r in unload_events if abs(r['ElapsedTime']-manifest['common_inputs']['dump_min'])<1e-7]
    assert unloads and all(r['Quantity']==45 for r in unloads)
    total=sum(r['Quantity'] for r in unloads)
    assert total==sum(r['Quantity'] for r in records['HS_MaterialMovement'])==records['HS_ExperimentResult'][0]['DumpedAtDestinations']
    assert abs(events[0]['SimulationTime'])<1e-8
    for a,b in zip(events,events[1:]): assert abs(a['SimulationTime']+a['ElapsedTime']-b['SimulationTime'])<1e-7
    assert abs(events[-1]['SimulationTime']+events[-1]['ElapsedTime']-120)<1e-7
    times=[r['SimulationTime']+r['ElapsedTime'] for r in unloads]
    cycles=[b-a for a,b in zip(times,times[1:])]
    assert cycles
    # Only complete loaded travel legs ending before a recorded unload are included.
    loaded=[r['ElapsedTime'] for r in events if r['State']=='TravelLoaded' and r['SimulationTime']+r['ElapsedTime']<times[-1]]
    assert loaded
    state_totals={}
    for r in events:state_totals[r['State']]=state_totals.get(r['State'],0)+r['ElapsedTime']
    summary={'case':tag,'rolling_resistance_percent':case['rolling_resistance_percent'],
        'status':'EXECUTED_NATIVE_AND_RECONCILED','runtime_min':120,'replications':1,
        'completed_loads':len(unloads),'delivered_t':total,'finite_run_tph':total/2,
        'mean_complete_cycle_min':statistics.mean(cycles),'complete_cycle_intervals_min':cycles,
        'mean_complete_loaded_travel_min':statistics.mean(loaded),
        'complete_unload_times_min':times,'state_time_totals_min':state_totals,
        'loaded_from_source_t':records['HS_ExperimentResult'][0]['LoadedFromSources'],
        'undelivered_at_cutoff_t':records['HS_ExperimentResult'][0]['LoadedFromSources']-total,
        'truncated_unload_events':[r for r in unload_events if r not in unloads],
        'mass_balance':'PASS: completed truck unloads = material movements = experiment delivered tonnes; unfinished unloads excluded',
        'time_coverage':'PASS: contiguous truck timeline from 0 to 120 minutes',
        'battery_energy':'DISABLED; no battery consumption, temperature or fire-detection result',
        'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
    (folder/'audit_summary.json').write_text(json.dumps(summary,indent=2))
    case['status']=summary['status'];case['result_audit']=str((folder/'audit_summary.json').relative_to(OUT))
    summaries.append(summary)
    con.close()
assert hashlib.sha256((ROOT/manifest['source_model']).read_bytes()).hexdigest()==manifest['source_sha256']
(OUT/'study_manifest.json').write_text(json.dumps(manifest,indent=2))
if len(summaries)==3:
    keys=['case','rolling_resistance_percent','completed_loads','delivered_t','finite_run_tph','mean_complete_cycle_min','mean_complete_loaded_travel_min','undelivered_at_cutoff_t']
    with (OUT/'results/scenario_comparison.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader();w.writerows(summaries)
print(json.dumps(summaries,indent=2))
