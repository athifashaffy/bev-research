# Dataset: Multi‑Dimensional Electrical Performance Characterization of Large‑Capacity Mining Power Lithium‑Ion Batteries in Early Calendar Aging under Temperature‑SOC Coupling
DOI: 10.17632/dhr726bk6z.1

## 1. Dataset Overview
This dataset presents multi‑dimensional experimental measurements for six commercial 228 Ah prismatic lithium‑iron‑phosphate (LFP) mining‑power cells subjected to early‑stage calendar‑aging storage under combined temperature and state‑of‑charge (SOC) conditions.
The experiment simulates real‑world idle‑storage, transportation and standby scenarios for batteries deployed in underground mining equipment.

- **Overall experimental calendar span**: 20 Sep 2024 – 16 May 2025
- **Total wall‑clock calendar duration of test campaign**: 234 days
- **Fixed calendar‑aging storage per cycle**: 7‑day constant‑temperature static storage
- **Cumulative actual constant‑temperature storage time across the whole campaign**: ~70 days
- **Remaining time**: consumed by periodic electrochemical characterization tests at 25 °C
- **All characterization tests (capacity, HPPC, OCV, EIS, resistance) performed at constant ambient temperature**: 25 °C
- **Nominal aging check‑points**: 0D, 7D, 14D, 21D, 28D, 35D, 42D, 49D, 56D, 63D (10 characterization rounds in total)

> Important time‑definition note:
> The labels “0D‑63D” are **nominal checkpoint markers**, not real‑world calendar days of storage. For fully completed cells, the nominal 0D‑63D sequence corresponds to actual calendar days ranging from 231 to 235 days.
> Six cells were not tested synchronously; individual cells have slightly different real timestamps and total accumulated charge‑discharge cycles.
> For precise per‑cell timestamps, total calendar duration, cumulative storage exposure under target temperature‑SOC, and time occupied by 25 °C characterization tests, please refer to the metadata file: `metadata_time.xlsx`.

During periodic characterization, approximately 60 full charge‑discharge cycles were cumulatively introduced for completed cells. The rated cycle life of these 228 Ah cells is 2500 cycles; therefore, the contribution from cycle aging is minor. This dataset targets calendar‑aging behaviour, while cycle‑aging effects can be extracted and analysed separately from raw measurement files.

## 2. Test hardware specifications
| Measurement item | Instrument | Key accuracy / range |
|---|---|---|
| Main battery cycler | NEBULA battery test system (Xingyun Electronics, China) | Voltage & current accuracy ±0.05 %; sampling interval = 1 s |
| Temperature chamber | Harding TXHL‑D28E | −40 ~ 150 °C; stability ±1.0 °C |
| AC internal resistance | HIOKI BT3562 | 0–3 mΩ; resolution 0.1 μΩ |
| EIS workstation | Solartron‑9300R‑20 | Frequency scan range: 0.001 Hz ~ 1000 Hz |
| Cell thickness expansion | Vernier caliper | 0.01 mm resolution, five‑point thickness measurement |
| Cell mass | Electronic balance | 0.01 g resolution |
| Temperature monitoring | K‑type thermocouple | ±0.1 °C, attached to cell terminals and surface |

HPPC pulse tests strictly follow the FreedomCar 30‑second pulse standard. EIS fitting is performed in ZView using the physically‑equivalent electrical‑circuit (PEEC) model.

## 3. Cell information & aging conditions
One single cell was tested for each temperature‑SOC coupled condition. See `metadata_time.xlsx` and Table 4 in the associated Data‑in‑Brief manuscript for full cell barcode, start‑stop timestamps and notes.

| Cell ID | Barcode | Storage Temperature | Storage SOC | Nominal aging range | Notes |
|---|---|---|---|---|---|
| B1 | L162318B0008 | 45 °C | 30% | 0D‑63D | Completed full test sequence |
| B2 | L162318A0001 | 25 °C | 50% | 0D‑63D | 28D EIS data missing |
| B3 | L162318C0003 | 45 °C | 50% | 0D‑63D | Completed full test sequence |
| B4 | L162318D0008 | 60 °C | 50% | 0D‑28D | Premature irreversible failure at nominal 35D; 28D EIS missing; only physical‑deformation data retained after failure point; no electrochemical tests conducted after failure for safety |
| B5 | L162318E0007 | 45 °C | 80% | 0D‑63D | Completed full test sequence |
| B6 | 00GCB7B1633002C9K0000140 | 45 °C | 100% | 0D‑63D | Completed full test sequence |

Temperature levels: 25 °C, 45 °C, 60 °C
SOC levels: 30 %, 50 %, 80 %, 100 %

## 4. Experimental workflow for each aging cycle
For every aging‑test cycle, the procedure was executed in the following order:
1. Capacity & AC‑/DC‑internal‑resistance measurement at 25 °C
2. 30‑s HPPC pulse characterization at 25 °C
3. Segmented static OCV‑SOC test at 25 °C
4. Full‑frequency EIS impedance scan at 25 °C
5. Adjust cell SOC back to target storage SOC
6. Return cell to target‑temperature chamber for **fixed 7‑day constant‑temperature calendar‑aging storage**

After the 7‑day storage phase, the next characterization cycle begins.

## 5. Repository folder‑level structure
Total files within dataset: **260 files**
